<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "\r\n               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>公告管理</h1>\r\n                                <div class=\"options\">\r\n                                <a href=\"add_gg.php\" class=\"btn btn-info btn-single\">添加公告</a>\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n                           ";
$please = $DB->count('SELECT count(*) from `app_gg` WHERE 1');
if ($_GET['act'] == 'del') {
    $id = $_POST['id'];
    $sql = $DB->query('DELETE FROM `app_gg` WHERE id=\'' . $id . '\'');
    if ($sql) {
        exit(json_encode(array('status' => 'success')));
    } else {
        exit(json_encode(array('status' => 'error')));
    }
} elseif ($_GET['act'] == 'show') {
    $show = $_POST['show'] == '1' ? '1' : '0';
    $id = $_POST['id'];
    $sql = $DB->query('update `app_gg` set `show`=\'' . $show . '\' where `id`=\'' . $id . '\'');
    if ($sql) {
        exit(json_encode(array('status' => 'success')));
    } else {
        exit(json_encode(array('status' => 'error')));
    }
} else {
    echo '                    ';
    if ($please == 0) {
        echo "\r\n                          <div class=\"panel panel-default\">\r\n                                <div class=\"panel-heading\">\r\n                                    <h3>暂无公告，请前往【 <a href=\"add_gg.php\" >添加公告</a>】添加</h3>\r\n                                </div>\r\n                             </div>";
    } else {
        echo "<div class=\"panel panel-default\">\r\n                                <div class=\"panel-heading\">\r\n                                    <h3 class=\"panel-title\">当前平台共 ";
        echo $please;
        echo " 条公告</h3>\r\n                                </div>\r\n                             </div>\r\n<div class=\"tile-body color transparent-black rounded-corners\">\r\n    <ul class=\"list-group\">\r\n    ";
        $list = $DB->query('SELECT * FROM `app_gg` order by id desc');
        while ($vo = $DB->fetch($list)) {
            echo ' <li class="list-group-item line-id-' . $vo['id'] . "\">\r\n        <span class=\"badge\">" . date('Y/m/d H:i:s', $vo['time']) . "</span>\r\n        ID:" . $vo['id'] . ':' . $vo['name'] . "<br>\r\n        <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"window.location.href='add_gg.php?act=mod&id=" . $vo['id'] . '\'">编辑</button>&nbsp;';
            echo '<button type="button" class="btn btn-danger btn-xs" onclick="delLine(\'' . $vo['id'] . "')\">删除</button>\r\n    </li>";
        }
        echo "   \r\n</ul>\r\n</div>\r\n";
    }
    echo "    <script>\r\nfunction qiyong(id){\r\n    var doc = \$('.line-id-'+id+' .showstatus');\r\n    if(doc.attr('data') == \"1\"){\r\n        doc.html(\"已禁用\").attr({'data':'0'});\r\n    }else{\r\n        doc.html(\"已启用\").attr({'data':'1'});\r\n    }\r\n    var url = \"list_gg.php?act=show\";\r\n        var data = {\r\n            \"id\":id,\r\n            \"show\":doc.attr('data')\r\n        };\r\n        \$.post(url,data,function(data){\r\n            if(data.status == \"success\"){\r\n\r\n            }else{\r\n                alert(\"操作失败\");\r\n            }\r\n        },\"JSON\");\r\n}\r\nfunction delLine(id){\r\n    if(confirm('确认删除吗？删除后不可恢复哦！')){\r\n        \$('.line-id-'+id).slideUp();\r\n        var url = \"list_gg.php?act=del\";\r\n        var data = {\r\n            \"id\":id\r\n        };\r\n        \$.post(url,data,function(data){\r\n            if(data.status == \"success\"){\r\n\r\n            }else{\r\n                alert(\"删除失败\");\r\n            }\r\n        },\"JSON\");\r\n    }\r\n}\r\n</script>\r\n </div> ";
}
echo "                            </div> \r\n                        </div>\r\n                    </div>\r\n";
include 'copy.php';