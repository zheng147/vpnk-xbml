<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "\r\n               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>添加节点</h1>\r\n                                <div class=\"options\">\r\n                                <div class=\"btn-group\">\r\n                                    <a href=\"#\" class=\"btn btn-primary\"><i class=\"fa fa-cog\"></i></a>\r\n\r\n                                    \r\n                                    <a href=\"#\" class=\"btn btn-primary dropdown-toggle\" data-toggle=\"dropdown\"><span class=\"caret\"></span></a>\r\n                                    <ul class=\"dropdown-menu\" role=\"menu\">\r\n                                        <li><a data-target=\"#tjjd\" data-toggle=\"modal\">添加</a></li>\r\n                                        <li>   <a data-target=\"#gn\" data-toggle=\"modal\">节点功能介绍</a></li>\r\n                                         <li>   <a data-target=\"#qb\" data-toggle=\"modal\">节点填写域名和IP的区别</a></li>\r\n                                    </ul>\r\n                                </div>\r\n</div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\t\t\t\t\t\t\r\n                            ";
$my = isset($_GET['my']) ? $_GET['my'] : null;
if ($my == 'del') {
    echo '<div class="alert';
    $id = daddslashes($_GET['id']);
    $sql = $DB->query('DELETE FROM `note` WHERE id=\'' . $id . '\'');
    if ($sql) {
        echo " alert-success\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=tjjd.php\">";
    } else {
        echo " alert-danger\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除失败！";
    }
    echo '</div>';
} else {
    if (!empty($_GET['kw'])) {
        $sql = ' `name`=\'' . $_GET['kw'] . '\'';
        $numrows = $DB->count('SELECT count(*) from `note` WHERE' . $sql);
        $con = '共有 ' . $numrows . ' 个节点';
    } else {
        $numrows = $DB->count('SELECT count(*) from `note` WHERE 1');
        $sql = ' 1';
        $con = '平台共' . $numrows . '个节点';
    }
    echo "<div class=\"row\">\r\n    <div class=\"col-md-12\">\r\n        <div class=\"panel panel-default\">\r\n            <div class=\"panel-heading\">\r\n                <h2>";
    echo $con;
    echo "</h2>\r\n                <div class=\"panel-ctrls\"><form action=\"tjjd.php\">\r\n                <label class=\"panel-ctrls-center\"> <input type=\"text\" class=\"form-control\" size=\"10\" name=\"kw\" placeholder=\"搜索（名称）\"></label>\r\n                 </form></div>\r\n            </div>\r\n            <div class=\"panel-body panel-no-padding\">\r\n            <div class=\"table-responsive\">\r\n                <table id=\"example\" class=\"table table-bordered table-fixed-header m0\" cellspacing=\"0\" width=\"100%\">\r\n                    <thead>\r\n                        <tr>\r\n                            <th>序号</th>\r\n                            <th>名称</th>\r\n                            <th>地址</th>\r\n                            <th>描述</th>\r\n                            <th>添加时间</th>\r\n                            <th>满载人数</th>\r\n                            <th>在线人数</th>\t\t\t\t\t\t\t\t\r\n                            <th>操作</th>\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n                      ";
    $pagesize = 10;
    $pages = intval($numrows / $pagesize);
    if ($numrows % $pagesize) {
        ($pages += 1) + -1;
    }
    if (isset($_GET['page'])) {
        $page = intval($_GET['page']);
    } else {
        $page = 1;
    }
    $offset = $pagesize * ($page - 1);
    $rs = $DB->query('SELECT * FROM `note` WHERE' . $sql . ' order by id desc limit ' . $offset . ',' . $pagesize);
    while ($res = $DB->fetch($rs)) {
        $str = file_get_contents('http://' . $res['ipport'] . '/res/tcp.txt', false, stream_context_create(array('http' => array('method' => 'GET', 'timeout' => 1))));
        $str2 = file_get_contents('http://' . $res['ipport'] . '/udp/udp.txt', false, stream_context_create(array('http' => array('method' => 'GET', 'timeout' => 1))));
        $onlinenum_tcp = (substr_count($str, date('Y')) - 1) / 2;
        $onlinenum_udp = (substr_count($str2, date('Y')) - 1) / 2;
        $onlinenum = $onlinenum_tcp + $onlinenum_udp;
        if (!($onlinenum >= 0)) {
            $onlinetext = '<span style="color:red;">超时</span>';
        } else {
            $onlinetext = '<a href="online.php?id=' . $res['id'] . '">' . $onlinenum . '</a>';
        }
        $onlinetext2 = '<a class="btn btn-xs btn-success" href="online.php?id=' . $res['id'] . '">在线人数</a>';
        echo "                                          <tr>\r\n                                          <th><span class=\"co-name\">";
        echo $res['id'];
        echo "</span></th>\r\n                                          <td>";
        echo $res['name'];
        echo "</td>\r\n                                          <td>";
        echo $res['ipport'];
        echo "</td>\r\n\t\t\t\t\t\t\t\t\t\t  <td>";
        echo $res['description'];
        echo "</td>\t\t\t\t\t\t\t\t\t  \r\n                                          <td>";
        echo $res['time'];
        echo "</td>\t\t\t\t\t\t\t\t\t  \r\n                                          <td>";
        echo $res['count'];
        echo "</td>\r\n                                          <td>";
        echo $onlinetext;
        echo "</td>\t\t\t\t\t\t\t\t\t\t  \r\n                                          <td>";
        echo $onlinetext2;
        echo '&nbsp;<a href="./tjjd.php?my=del&id=';
        echo $res['id'];
        echo "\" class=\"btn btn-xs btn-danger\" onclick=\"if(!confirm('你确实要删除此记录吗？')){return false;}\">删除</a></td>\r\n                                          </tr>\r\n                                          ";
    }
    echo "                                      </tbody>\r\n                                  </table>\r\n                       </div>\r\n                      \r\n                      <div class=\"panel-footer\">\r\n                      <div class=\"row\">\r\n                      <div class=\"col-sm-12\">\r\n                      <div class=\"dataTables_paginate paging_bootstrap\" id=\"example_paginate\">\r\n                       ";
    echo '<ul class="pagination pull-right m0">';
    $first = 1;
    $prev = $page - 1;
    $next = $page + 1;
    $last = $pages;
    if ($page > 1) {
        echo '<li class="previous disabled"><a href="tjjd.php?page=' . $first . $link . '">首页</a></li>';
    } else {
        echo '<li class="previous disabled"><a>首页</a></li>';
    }
    $i = 1;
    while (!($i >= $page)) {
        echo '<li class="active"><a href="tjjd.php?page=' . $i . $link . '">' . $i . '</a></li>';
        ($i += 1) + -1;
    }
    echo '<li  class="active"><a>' . $page . '</a></li>';
    $i = $page + 1;
    while (!($i > $pages)) {
        echo '<li><a href="tjjd.php?page=' . $i . $link . '">' . $i . '</a></li>';
        ($i += 1) + -1;
    }
    echo '';
    if (!($page >= $pages)) {
        echo '<li class="next disabled"><a href="tjjd.php?page=' . $last . $link . '">尾页</a></li>';
    } else {
        echo '<li class="next disabled"><a>尾页</a></li>';
    }
    echo '</ul>';
}
echo "                      </div>\r\n                      </div>\r\n                      </div>\r\n                      </div>\r\n\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>                                      <td>";
echo $res['description'];
echo "</td>\r\n                                          <td>";
echo $res['time'];
echo "</td>\r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n                      ";
if ($_POST['name']) {
    $id = daddslashes($_POST['id']);
    $name = daddslashes($_POST['name']);
    $ipport = daddslashes($_POST['ipport']);
    $description = daddslashes($_POST['description']);
    $count = daddslashes($_POST['count']);
    if (!$DB->get_row('select * from `note` where `name`=\'' . $name . '\' limit 1')) {
        $sql = 'insert into `note` (`id`,`name`,`ipport`,`description`,`count`) values (\'' . $id . '\',\'' . $name . '\',\'' . $ipport . '\',\'' . $description . '\',\'' . $count . '\')';
        if ($DB->query($sql)) {
            exit('<script language=\'javascript\'>alert(\'成功添加一个节点！\');window.location.href=\'./tjjd.php\';</script>');
        } else {
            exit('<script language=\'javascript\'>alert(\'添加失败\');window.location.href=\'./tjjd.php\';</script>');
        }
    } else {
        exit('<script language=\'javascript\'>alert(\'该节点已存在！\');window.location.href=\'./tjjd.php\';</script>');
    }
}
echo "\t<script>\r\n\tfunction checkStr(){\r\n\t\tvar id = \$('[name=\"id\"]').val();\t\t\r\n\t\tvar name = \$('[name=\"name\"]').val();\r\n\t\tvar ip = \$('[name=\"ipport\"]').val();\r\n\t\tvar description = \$('[name=\"description\"]').val();\r\n\t\tvar count = \$('[name=\"count\"]').val();\t\t\t\r\n\r\n\t\tif(name == \"\" || ip ==　\"\"){\r\n\t\t\talert(\"参数填写不完整，请正确填写再尝试添加\");\r\n\t\t\treturn false;\r\n\t\t}\r\n\t\treturn true;\r\n\t}\r\n\t</script>\t\t\t\t\t  \r\n<div class=\"modal fade\" id=\"tjjd\" role=\"dialog\" tabindex=\"-1\" aria-labelledby=\"tjjd\" aria-hidden=\"true\">\r\n<div class=\"modal-dialog\">\r\n<div class=\"modal-content\">\r\n<div class=\"modal-header\">\r\n<form action=\"./tjjd.php\" method=\"POST\" class=\"form-inline\" onsubmit=\"return checkStr()\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"modal\"><i class=\"pci-cross pci-circle\" ></i></button>\r\n<h4 class=\"modal-title\">节点添加</h4>\r\n</div>\r\n<br>\r\n<div class=\"panel-body\">\r\n   <div class=\"col-md-2\"><label>节点名称</label></div>\r\n   <div class=\"col-md-12\">\r\n<div class=\"form-group\">\r\n <input type=\"text\" class=\"form-control\" id=\"field-1\" placeholder=\"哎呦！我操你妈这节点6\" name=\"name\" data-validate=\"required\">\r\n</div>\r\n</div>\r\n</br>\r\n  <div class=\"col-md-2\"><label>节点描述</label></div>\r\n   <div class=\"col-md-12\">\r\n  <div class=\"form-group\">\r\n <input type=\"text\" class=\"form-control\" id=\"field-1\" placeholder=\"不限速/看视频/聊天/刷网页/youtube\" name=\"description\" data-validate=\"required\">\r\n  </div>\r\n</div>\r\n</br>\r\n  <div class=\"col-md-2\"><label>满载人数限制</label></div>\r\n   <div class=\"col-md-12\">\r\n  <div class=\"form-group\">\r\n <input type=\"text\" class=\"form-control\" id=\"field-1\" placeholder=\"比如100-200\" name=\"count\" data-validate=\"required\">\r\n  </div>\r\n</div>\r\n</br>\r\n  <div class=\"col-md-2\"><label>IP:端口</label></div>\r\n   <div class=\"col-md-12\">\r\n  <div class=\"form-group\">\r\n <input type=\"text\" class=\"form-control\" id=\"field-1\" placeholder=\"127.0.0.1:80\" name=\"ipport\" data-validate=\"required\">\r\n  </div>\r\n</div>\r\n</br>\r\n  <div class=\"col-md-2\"><label>节点序号（越大越靠前）</label></div>\r\n   <div class=\"col-md-12\">\r\n  <div class=\"form-group\">\r\n <input type=\"text\" class=\"form-control\" id=\"field-1\" placeholder=\"0~999+\" name=\"id\" data-validate=\"required\">\r\n  </div>\r\n</div>\r\n</br>\r\n  <div class=\"col-md-12\">\r\n<div class=\"modal-footer\">\r\n<input type=\"submit\" value=\"添加节点\" class=\"btn btn-primary\"/>\r\n</div></div>\r\n</form>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"modal fade\" id=\"gn\" role=\"dialog\" tabindex=\"-1\" aria-labelledby=\"gn\" aria-hidden=\"true\">\r\n<div class=\"modal-dialog\">\r\n<div class=\"modal-content\">\r\n<div class=\"modal-header\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"modal\"><i class=\"pci-cross pci-circle\" ></i></button>\r\n<h4 class=\"modal-title\">节点功能介绍</h4>\r\n</div>\r\n<br>\r\n<div class=\"alert alert-success\">节点功能介绍：</div>\r\n\t<div class=\"alert alert-success\">在传统的负载方式中，客户请求会以DNS解析的方式被随机分配到不同的服务器，以实现负载。这类请求在总体上会似的每个服务器的负载近乎均衡，但是同时也带来了另一个问题，因为采取的单纯的DNS轮询，而不会去判断地域，就近选择，就会出现北京的用户明明可以有更加优质的北京服务器，却被分配到了广东服务器，那么这两个直接的延迟差距就是显而易见的。<br>\r\n\t通过本功能，添加节点可以实现根据地区负载。<br></div>\r\n\t<div class=\"alert alert-warning\">例如，现在有 北京服务器 A B C三台，广东服务器  D E F三台。注册有域名 test.com<br>\t</div>\r\n\t<div class=\"alert alert-danger\">传统方式 完全请求随机分配，用户可能分配到任何一台服务器，那么，如果通过节点解决呢？<br>\t</div>\r\n\t<div class=\"alert alert-info\">我们首先可以在域名解析中，添加 beijing.test.com  解析 A B C三个IP 。添加 guangdong.test.com添加D E F 三个IP。这样就形成了两个小的地区分组。北京的域名只解析北京服务器，广告只解析广东。\t</div>\r\n\t\t<div class=\"alert alert-success\">然后分别添加两个节点:北京集群 域名beijing.test.com 广东集群 guangdong.test.com 。<br>\t</div>\r\n\t\t<div class=\"alert alert-warning\">这样，用户就可以选择离自己近的集群连接，同一地域内的请求又可以均衡负载。<br>\t</div>\r\n\t\t<div class=\"alert alert-danger\">当然，本功能适合 用户分布广泛，服务器众多的，小中用户完全可以关闭节点功能，以便于节省资源！\r\n\t\t<br>\t</div>\r\n\t<div class=\"alert alert-info\">使用方法，将线路中的服务器IP或者域名替换成[domain]（例如 http-proxy [domian]:8080），安装时，会自动替换为节点域名。当然，如果关闭节点功能，则会被替换为 [证书管理]中的域名。\r\n\t</p>\t</div>\r\n\t</div>\r\n\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"modal fade\" id=\"qb\" role=\"dialog\" tabindex=\"-1\" aria-labelledby=\"qb\" aria-hidden=\"true\">\r\n<div class=\"modal-dialog\">\r\n<div class=\"modal-content\">\r\n<div class=\"modal-header\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"modal\"><i class=\"pci-cross pci-circle\" ></i></button>\r\n<h4 class=\"modal-title\">节点填写域名和IP的区别</h4>\r\n</div>\r\n<div class=\"alert alert-success\">节点填写域名和IP的区别</b>\r\n因为用户的登录信息是以IP为标记，所以如果填写域名（无论域名你是否负载）都将无法统计单个节点的负载信息（也就是系统无法判断一个节点在线多少人）</b></div>\r\n<div class=\"alert alert-info\">但是其他功能一切正常！</b></div>\r\n<div class=\"alert alert-warning\">满载人数什么意思？</b></div>\r\n<div class=\"alert alert-info\">满载人数是为了计算节点负荷显示给用户使用的。默认140。此数值只是为了线路页面统计使用，计算规则如下:<br></div>\r\n<div class=\"alert alert-danger\">负荷百分比=在线人数/满载人数*100</b>最大为100%，最低为1%（即便是一个人在线也是1%）。例如当140或者更多人在线时，140/140*100  = 100。即为100%负荷。再如70人在线，即为70/140*100=50，即为负荷程序为50%。0人在线或者没有数据即为[空闲]。</div>\r\n\t<br>\r\n\t<div class=\"alert alert-info\"><b>人数设置为0则关闭负载计算。推荐节点填写域名时关闭负载计算。不影响正常使用！</b></div>\r\n\t</p>\r\n\t</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n";
include 'copy.php';