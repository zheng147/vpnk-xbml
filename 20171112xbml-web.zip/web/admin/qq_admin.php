<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "\r\n               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>高级设置</h1>\r\n                                <div class=\"options\">\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n                            ";
if ($_GET['act'] == 'update') {
    file_put_contents('../app_api/data/default.txt', $_POST['name']);
    file_put_contents('../app_api/data/content.txt', $_POST['content']);
    file_put_contents('../app_api/data/max_limit.txt', $_POST['max_limit']);
    file_put_contents('../app_api/data/reg_type.txt', $_POST['reg_type']);
    success_go('修改成功', 'qq_admin.php?act=mod&id=' . $_GET['id']);
} else {
    $action = '?act=update';
    $info['name'] = @file_get_contents('../app_api/data/default.txt');
    $info['content'] = @file_get_contents('../app_api/data/content.txt');
    $info['max_limit'] = @file_get_contents('../app_api/data/max_limit.txt');
    $info['reg_type'] = @file_get_contents('../app_api/data/reg_type.txt');
    echo " <link rel=\"stylesheet\" href=\"/app_api/Core/KE/themes/default/default.css\" />\r\n    <link rel=\"stylesheet\" href=\"/app_api/Core/KE/plugins/code/prettify.css\" />\r\n    <script charset=\"utf-8\" src=\"/app_api/js/jquery.js\"></script>\r\n    <script charset=\"utf-8\" src=\"/app_api/Core/KE/kindeditor.js\"></script>\r\n    <script charset=\"utf-8\" src=\"/app_api/Core/KE/lang/zh_CN.js\"></script>\r\n    <script charset=\"utf-8\" src=\"/app_api/Core/KE/plugins/code/prettify.js\"></script>\r\n    <script>\r\n        KindEditor.ready(function(K) {\r\n            var editor1 = K.create('textarea[name=\"content\"]', {\r\n                cssPath : '/app_api/Core/KE/plugins/code/prettify.css',\r\n                uploadJson : '/app_api/Core/KE/php/upload_json.php',\r\n                fileManagerJson : '/app_api/Core/KE/php/file_manager_json.php',\r\n                allowFileManager : true,\r\n                afterCreate : function() {\r\n                    var self = this;\r\n                    K.ctrl(document, 13, function() {\r\n                        self.sync();\r\n                        K('form[name=add]')[0].submit();\r\n                    });\r\n                    K.ctrl(self.edit.doc, 13, function() {\r\n                        self.sync();\r\n                        K('form[name=add]')[0].submit();\r\n                    });\r\n                }\r\n            });\r\n            prettyPrint();\r\n        });\r\n    </script>\r\n<div class=\"main\">\r\n<div style=\"clear:both;height:10px;\"></div>\r\n <form class=\"form-horizontal\" role=\"form\" method=\"POST\" action=\"";
    echo $action;
    echo "\" onsubmit=\"return checkStr()\"><div class=\"form-group\">\r\n <div class=\"col-sm-12\"><div class=\"alert alert-success\">为了安全起见、短信接口请您于 sms.config.php中配置、切记。无使用记事本。电脑请使用<a href=\"http://sw.bos.baidu.com/sw-search-sp/software/4adc9ccbdd40a/npp_7.1_Installer.exe\">notepad++</a>&nbsp;&nbsp;&nbsp;注册通道<select name=\"reg_type\">\r\n                <option value=\"default\">普通注册</option>\r\n                <option value=\"sms\" ";
    echo $info['reg_type'] == 'sms' ? 'selected' : '';
    echo ">短信注册</option>\r\n                <option value=\"link\" ";
    echo $info['reg_type'] == 'link' ? 'selected' : '';
    echo ">使用跳转连接（请勿选择 开发中）</option>\r\n            </select></div> </div>\r\n <div class=\"col-sm-6\">\r\n                    <div class=\"panel panel-success\">\r\n                    <div class=\"panel-heading\">\r\n                      <h2\">QQ列表 多个请用 换行 区分。显示名字用|区分</h2>\r\n                      </div><textarea class=\"form-control\" rows=\"10\" name=\"name\">";
    echo $info['name'];
    echo "</textarea>\r\n        </div>\r\n    </div>\r\n    \r\n    <div class=\"col-sm-6\">\r\n                    <div class=\"panel panel-success\">\r\n                    <div class=\"panel-heading\">\r\n                      <h2\">请设置无限套餐封底(流量达到这个数值自动识别为无限/单位：GB)</h2>\r\n                      </div>\r\n   <textarea class=\"form-control\" rows=\"10\" name=\"max_limit\">";
    echo $info['max_limit'];
    echo "</textarea></div>\r\n        </div>\r\n    <div class=\"col-sm-12\">\r\n                    <div class=\"panel panel-info\">\r\n                    <div class=\"panel-heading\">\r\n                      <h2\">说明性文字可以写一些简单介绍（支持HTML）</h2>\r\n                      </div>\r\n            <textarea class=\"form-control\" rows=\"10\" name=\"content\" id=\"myEditor\">";
    echo $info['content'];
    echo "</textarea>\r\n            <script>UE.getEditor('myEditor');</script>\r\n    </div></div></div>\r\n      <div class=\"form-group\">\r\n        <div class=\"col-sm-12\">\r\n            <button type=\"submit\" class=\"btn btn-block btn-md btn-primary\">提交数据</button>\r\n    </div> </div>\r\n</form> \r\n    </div>\r\n    <script>\r\n    function checkStr(){\r\n        var title = \$('[name=\"title\"]').val();\r\n        var content = \$('[name=\"content\"]').val();\r\n        if(title == \"\" || content ==　\"\"){\r\n            alert(\"标题与内容不得为空\");\r\n            return false;\r\n        }\r\n        return true;\r\n    }\r\n    </script>\r\n";
}
echo "                            </div> \r\n                        </div>\r\n                    </div>\r\n";
include 'copy.php';
function success_go($msg, $url)
{
    echo "<div class=\"alert alert-success alert-dismissable\">\r\n            <button type=\"button\" class=\"close\" data-dismiss=\"alert\"\r\n                    aria-hidden=\"true\">\r\n                &times;\r\n            </button>\r\n            " . $msg . ',系统将在3秒后跳转。<a href="' . $url . "\">等不及了！</a>\r\n        </div> ";
    echo "<script>setTimeout(function(){\r\n            window.location.href=\"" . $url . "\";\r\n        },3000)</script>";
    return null;
}
function error_go($msg, $url)
{
    echo "<div class=\"alert alert-danger alert-dismissable\">\r\n            <button type=\"button\" class=\"close\" data-dismiss=\"alert\"\r\n                    aria-hidden=\"true\">\r\n                &times;\r\n            </button>\r\n            " . $msg . ',系统将在3秒后跳转。<a href="' . $url . "\">等不及了！</a>\r\n        </div> ";
    echo "<script>setTimeout(function(){\r\n            window.location.href=\"" . $url . "\";\r\n        },3000)</script>";
    return null;
}