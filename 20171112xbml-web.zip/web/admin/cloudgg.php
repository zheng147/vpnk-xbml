<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "\r\n               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>滚动公告管理</h1>\r\n                                <div class=\"options\">\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n                           ";
$appfile = '../app_api/dl.php';
$appconn = file_get_contents($appfile);
$appconn = str_replace('rn', '<br/>', file_get_contents($appfile));
$app1file = '../app_api/ngg.php';
$app1conn = file_get_contents($app1file);
$app1conn = str_replace('rn', '<br/>', file_get_contents($app1file));
if ($_GET['type'] == 'app') {
    $myfile = fopen('../app_api/dl.php', 'w');
    if (!(bool) fopen('../app_api/dl.php', 'w')) {
        exit('Unable to open file!');
    }
    fwrite($myfile, $_POST['appcontent']);
    fclose($myfile);
    echo '<script language=JavaScript>history.go(-1);location.reload();</script>';
} elseif ($_GET['type'] == 'app1') {
    $myfile = fopen('../app_api/ngg.php', 'w');
    if (!(bool) fopen('../app_api/ngg.php', 'w')) {
        exit('Unable to open file!');
    }
    fwrite($myfile, $_POST['app1content']);
    fclose($myfile);
    echo '<script language=JavaScript>history.go(-1);location.reload();</script>';
}
echo "<div class=\"row\">\r\n<div class=\"col-md-6\">\r\n    <div class=\"panel panel-success\">\r\n        <div class=\"panel-heading\"><h2>APP登陆界面公告</h2></div>\r\n            <div class=\"panel-body\">\r\n                   <form action=\"cloudgg.php?type=app\" method=\"post\" class=\"form-horizontal\" role=\"form\">\r\n                   <div class=\"form-group\"><label>&nbsp;&nbsp;公告内容：</label>\r\n                   <textarea class=\"form-control diff-textarea\" placeholder=\"输入公告内容\" name=\"appcontent\" rows=\"10\">";
echo $appconn;
echo "</textarea>\r\n                   </div>\r\n                  <input type=\"submit\" value=\"保存\" class=\"btn btn-info btn-block\">\r\n                  </form>\r\n            </div>\r\n        </div>\r\n    </div>\r\n              \r\n                  \r\n            <div class=\"col-md-6\">\r\n                    <div class=\"panel panel-success\">\r\n                    <div class=\"panel-heading\">\r\n                      <h2\">APP安装线路后界面公告</h2>\r\n                      </div>\r\n               <div class=\"panel-body\">\r\n          <form action=\"cloudgg.php?type=app1\" method=\"post\" class=\"form-horizontal\" role=\"form\">\r\n              <div class=\"form-group\"><label>&nbsp;&nbsp;公告内容：</label>\r\n              <textarea class=\"form-control diff-textarea\" placeholder=\"输入公告内容\" name=\"app1content\" rows=\"10\">";
echo $app1conn;
echo "</textarea>\r\n             </div>\r\n            <input type=\"submit\" value=\"保存\" class=\"btn btn-info btn-block\">\r\n          </form>\r\n        </div>   </div>  \r\n</div>\r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n";
include 'copy.php';