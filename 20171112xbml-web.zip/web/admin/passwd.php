<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>修改密码</h1>\r\n                                <div class=\"options\">\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n <div class=\"row\">\r\n                <div class=\"col-sm-12\">\r\n                    \r\n                  <div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">修改管理员账号和密码\r\n                    </div>\r\n                    <div class=\"panel-body\">\r\n";
if (isset($_POST['newname']) && isset($_POST['newpasswd'])) {
    $newname = $_POST['newname'];
    $newpasswd = $_POST['newpasswd'];
    if ($newname == '' || $newpasswd == '') {
        exit('<script language=\'javascript\'>alert(\'用户名和密码不能为空！\');history.go(-1);</script>');
    } else {
        $newpasswd = md5($newpasswd);
        $sql = 'update `admin` set `username` = \'' . $newname . '\', `password` = \'' . $newpasswd . '\'';
        $result = $DB->query($sql);
        if ($result) {
            exit('<script language=\'javascript\'>alert(\'密码修改成功！\');history.go(-1);</script>');
        } else {
            exit('<script language=\'javascript\'>alert(\'密码修改失败！\');history.go(-1);</script>');
        }
    }
}
echo "              <form id=\"myform\" action=\"./passwd.php\" method=\"post\" role=\"form\" class=\"form-horizontal validate\">     \r\n                <div class=\"form-group\">        \r\n                \r\n                  <label class=\"col-sm-2 control-label\">新账号</label>\r\n                  <div class=\"col-sm-10\">\r\n                    <input type=\"text\" class=\"form-control\" id=\"field-1\" name=\"newname\" data-validate=\"required\">\r\n                  </div>\r\n                </div>\r\n                \r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\">新密码</label>\r\n                  <div class=\"col-sm-10\">\r\n                    <input type=\"text\" class=\"form-control\" id=\"field-1\" name=\"newpasswd\" data-validate=\"required\">\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\"></label>\r\n                  <div class=\"col-sm-6\">\r\n                    <button type=\"submit\" type=\"button\" class=\"btn btn-info\">修改</button>\r\n                  </div>\r\n                </div>\r\n                \r\n              </form> \r\n                      \r\n                    </div>\r\n                  \r\n                  </div>\r\n                    \r\n                </div>\r\n            </div>\r\n   \r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n";
include 'copy.php';