<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "\r\n               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>商品列表</h1>\r\n                                <div class=\"options\">\r\n                                <div class=\"btn-group\">\r\n                                    <a href=\"#\" class=\"btn btn-primary\"><i class=\"fa fa-cog\"></i></a>\r\n                                    <a href=\"#\" class=\"btn btn-primary dropdown-toggle\" data-toggle=\"dropdown\"><span class=\"caret\"></span></a>\r\n                                    <ul class=\"dropdown-menu\" role=\"menu\">\r\n                                        <li><a data-target=\"#addkm\" data-toggle=\"modal\">快速生成卡密</a></li>\r\n                                        <li> <a href=\"kmlist.php?my=qk\" onclick=\"return confirm(\\'你确实要清空清空已使用的卡密吗？\\');\">清空已用卡密</a></li>\r\n                                        <li>   <a href=\"kmlist.php?my=qk3\" onclick=\"return confirm('你确实要清空清空所有的卡密吗？');\">清空所有卡密</a></li>\r\n                                    </ul>\r\n                                </div>\r\n                       \r\n</div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n";
$kind = 1;
$my = isset($_GET['my']) ? $_GET['my'] : null;
if ($my == 'add') {
    $kind = 1;
    $num = intval($_POST['num']);
    $value = intval($_POST['value']);
    $values = intval($_POST['values']);
    $kmtype_id = intval($_POST['kmtype_id']);
    echo '<li class="list-group-item list-group-item-success">成功生成以下商品</li>';
    $i = 0;
    while (!($i >= $num)) {
        $km = getkm(18);
        $sql = $DB->query('insert into `auth_kms` (`kind`,`km`,`value`,`values`,`money`,`addtime`,`kmtype_id`) values (\'' . $kind . '\',\'' . $km . '\',\'' . $value . '\',\'' . $values . '\',\'0.00\',\'' . $date . '\',\'' . $kmtype_id . '\')');
        if ($sql) {
            echo '<li class=\'list-group-item\'>' . $km . '</li>';
        }
        ($i += 1) + -1;
    }
    echo '<a href="./kmlist.php" class="list-group-item active"><i class="fa fa-mail-reply"></i> 返回商品列表</a>';
} elseif ($my == 'del') {
    echo '<div class="alert';
    $id = daddslashes($_GET['id']);
    $sql = $DB->query('DELETE FROM auth_kms WHERE id=\'' . $id . '\'');
    if ($sql) {
        echo " alert-success\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=kmlist.php\"";
    } else {
        echo " alert-danger\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除失败！";
    }
    echo '</div>';
} elseif ($my == 'qk') {
    echo "<div class=\"alert alert-warning\">\r\n                                        <button type=\"button\" class=\"close\" data-dismiss=\"alert\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span></button>\r\n您确认要清空所有商品吗？清空后无法恢复！</div><a href=\"./kmlist.php?my=qk2\" class=\"btn btn-danger\">确定</a><a href=\"javascript:history.back();\" class=\"btn btn-success\">返回</a></div></div>";
} elseif ($my == 'qk3') {
    echo '<div class="alert';
    if ($DB->query('DELETE FROM auth_kms') == true) {
        echo " alert-success\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>清空成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=kmlist.php\"";
    } else {
        echo " alert-danger\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>清空失败！";
    }
    echo '</div>';
} elseif ($my == 'qk2') {
    echo '<div class="alert';
    if ($DB->query('DELETE FROM auth_kms WHERE isuse=1') == true) {
        echo " alert-success\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>清空成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=kmlist.php\"";
    } else {
        echo " alert-danger\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>清空失败！";
    }
    echo '</div>';
} else {
    $form = "<form action=\"kmlist.php?my=add\" method=\"POST\" class=\"form-inline validate\">\r\n<a href=\"kmlist.php?my=qk\" class=\"btn btn-danger\" onclick=\"return confirm('你确实要清空清空已使用的卡密吗？');\">清空已使用</a>\r\n<div class=\"form-group pull-right\">\r\n  <div class=\"form-group\">\r\n    <input type=\"text\" class=\"form-control\" name=\"num\" placeholder=\"商品数量\" data-validate=\"required,number,min[1]\">\r\n  </div>\r\n  <div class=\"form-group\">\r\n    <input type=\"text\" class=\"form-control\" name=\"value\" placeholder=\"使用天数\" data-validate=\"required,number,min[1]\">\r\n  </div>\r\n  <div class=\"form-group\">\r\n    <input type=\"text\" class=\"form-control\" name=\"values\" placeholder=\"流量（GB）\" data-validate=\"required,number,min[1]\">\r\n  </div>\r\n  <button type=\"submit\" class=\"btn btn-secondary btn-single\">生成</button>\r\n</div>\r\n</form>";
    if (isset($_GET['kw'])) {
        if ($_GET['type'] == 1) {
            $sql = ' `km`=\'' . $_GET['kw'] . '\' and kind=1';
            $numrows = $DB->count('SELECT count(*) from auth_kms WHERE' . $sql);
            $con = '包含 ' . $_GET['kw'] . ' 的共有 ' . $numrows . ' 个商品';
        } elseif ($_GET['type'] == 2) {
            $sql = ' `user`=\'' . $_GET['kw'] . '\' and kind=1';
            $numrows = $DB->count('SELECT count(*) from auth_kms WHERE' . $sql);
            $con = '包含 ' . $_GET['kw'] . ' 的共有 ' . $numrows . ' 个商品';
        }
    } else {
        $numrows = $DB->count('SELECT count(*) from auth_kms WHERE kind=1');
        $sql = ' kind=1';
        $con = '平台共' . $numrows . '个商品';
    }
    echo "<div class=\"row\">\r\n    <div class=\"col-md-12\">\r\n        <div class=\"panel panel-default\">\r\n            <div class=\"panel-heading\">\r\n                <h2>";
    echo $con;
    echo "</h2>\r\n                <div class=\"panel-ctrls\"><form action=\"kmlist.php\">\r\n                <label class=\"panel-ctrls-center\"> <input type=\"text\" class=\"form-control\" size=\"10\" name=\"kw\" placeholder=\"搜索\"></label>\r\n                 </form></div>\r\n            </div>\r\n            <div class=\"panel-body panel-no-padding\"> <div class=\"table-responsive\">\r\n                <table id=\"example\" class=\"table table-bordered table-fixed-header m0\" cellspacing=\"0\" width=\"100%\">\r\n                    <thead>\r\n                        <tr>\r\n                            <th>序号</th>\r\n                            <th>卡密</th>\r\n                            <th>商品信息</th>\r\n                            <th>状态</th>\r\n                            <th>代理ID</th>\r\n                            <th>套餐ID</th>\r\n                            <th>添加时间</th>\r\n                            <th>使用时间</th>\r\n                            <th>操作</th>\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n                     \t";
    $pagesize = 20;
    $pages = intval($numrows / $pagesize);
    if ($numrows % $pagesize) {
        ($pages += 1) + -1;
    }
    if (isset($_GET['page'])) {
        $page = intval($_GET['page']);
    } else {
        $page = 1;
    }
    $offset = $pagesize * ($page - 1);
    $rs = $DB->query('SELECT * FROM auth_kms WHERE' . $sql . ' order by id desc limit ' . $offset . ',' . $pagesize);
    while ($res = $DB->fetch($rs)) {
        if ($res['isuse'] == 1) {
            $isuse = '<span class="badge badge-info">使用者:' . $res['user'] . '</span>';
        } elseif ($res['isuse'] == 0) {
            $isuse = '<span class="badge badge-secondary">未使用</span>';
        }
        if ($res['isuse'] == 1) {
            $del = '<button class="btn btn-xs btn-gray disabled">已经使用</button>';
        } elseif ($res['isuse'] == 0) {
            $del = '<a href="./kmlist.php?my=del&id=' . $res['id'] . '" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要删除此卡密吗？\');">删除</a>';
        }
        echo '<tr><th><span class="co-name">' . $res['id'] . '</span></th><td>' . $res['km'] . '</td><td>' . $res['value'] . '天/' . $res['values'] . 'GB/￥' . $res['money'] . '</td><td>' . $isuse . '</td><td>' . ($res['daili'] ? $res['daili'] : '管理员') . '</td><td>' . $res['kmtype_id'] . '</td><td>' . $res['addtime'] . '</td><td>' . $res['usetime'] . '</td><td>' . $del . '</td></tr>';
    }
    echo "                                      </tbody>\r\n                                  </table>\r\n                      \r\n                       </div>\r\n                      <div class=\"panel-footer\">\r\n                      <div class=\"row\">\r\n                      <div class=\"col-sm-6\">\r\n           \r\n         \r\n                      </div>\r\n                      <div class=\"col-sm-6\">\r\n                      <div class=\"dataTables_paginate paging_bootstrap\" id=\"example_paginate\">\r\n                       ";
    echo '<ul class="pagination pull-right m0">';
    $first = 1;
    $prev = $page - 1;
    $next = $page + 1;
    $last = $pages;
    if ($page > 1) {
        echo '<li class="previous disabled"><a href="kmlist.php?page=' . $first . $link . '">首页</a></li>';
    } else {
        echo '<li class="previous disabled"><a>首页</a></li>';
    }
    $i = 1;
    while (!($i >= $page)) {
        echo '<li class="active"><a href="kmlist.php?page=' . $i . $link . '">' . $i . '</a></li>';
        ($i += 1) + -1;
    }
    echo '<li  class="active"><a>' . $page . '</a></li>';
    $i = $page + 1;
    while (!($i > $pages)) {
        echo '<li><a href="kmlist.php?page=' . $i . $link . '">' . $i . '</a></li>';
        ($i += 1) + -1;
    }
    echo '';
    if (!($page >= $pages)) {
        echo '<li class="next disabled"><a href="kmlist.php?page=' . $last . $link . '">尾页</a></li>';
    } else {
        echo '<li class="next disabled"><a>尾页</a></li>';
    }
    echo '</ul>';
}
echo "                      </div>\r\n                      </div>\r\n                      </div>\r\n                      </div>\r\n\r\n            </div>\r\n        </div><div class=\"modal fade\" id=\"addkm\" role=\"dialog\" tabindex=\"-1\" aria-labelledby=\"addkm\" aria-hidden=\"true\">\r\n<div class=\"modal-dialog\">\r\n<div class=\"modal-content\">\r\n<div class=\"modal-header\">\r\n<form action=\"kmlist.php?my=add\" method=\"POST\" class=\"form-inline\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"modal\"><i class=\"pci-cross pci-circle\"></i></button>\r\n<h4 class=\"modal-title\">生成卡密</h4>\r\n</div>\r\n<br>\r\n<div class=\"panel-body\">\r\n   <div class=\"col-md-2\"><label>生成数量：</label></div>\r\n   <div class=\"col-md-12\">\r\n<div class=\"form-group\">\r\n<input type=\"text\" class=\"form-control\" name=\"num\" placeholder=\"卡密数量\">\r\n</div>\r\n</div>\r\n</br>\r\n  <div class=\"col-md-2\"><label>有效时间：</label></div>\r\n   <div class=\"col-md-12\">\r\n\r\n  <div class=\"form-group\">\r\n    <input type=\"text\" class=\"form-control\" name=\"value\" placeholder=\"单位(天)\">\r\n  </div>\r\n</div>\r\n  </br>\r\n  <div class=\"col-md-2\"><label>流量数量：</label></div>\r\n   <div class=\"col-md-12\">\r\n  <div class=\"form-group\">\r\n    <input type=\"text\" class=\"form-control\" name=\"values\" placeholder=\"单位(GB)\">\r\n  </div></div></br>\r\n  <div class=\"col-md-12\">\r\n\r\n<div class=\"modal-footer\">\r\n<input type=\"submit\" value=\"生成\" class=\"btn btn-primary\"/>\r\n</div></div>\r\n</form>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n    </div>\r\n                            </div> <!-- .container-fluid -->\r\n                        </div> <!-- #page-content -->\r\n                    </div>\r\n";
include 'copy.php';
function getkm($len = 18)
{
    $str = '1234567890';
    $strlen = strlen($str);
    $randstr = '';
    $i = 0;
    while (true) {
        if ($i >= $len) {
            return $randstr;
        }
        $randstr .= $str[mt_rand(0, $strlen - 1)];
        ($i += 1) + -1;
    }
}