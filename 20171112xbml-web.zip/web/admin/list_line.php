<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "\r\n               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>线路管理</h1>\r\n                                <div class=\"options\">\r\n                                <a href=\"add_line.php\" class=\"btn btn-info btn-single\">添加线路</a>\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n\r\n                            <div class=\"row\">\r\n                            <div class=\"col-md-12\">\r\n                           <div class=\"panel panel-default\">\r\n                                <div class=\"panel-heading\">\r\n                                    <h3 class=\"panel-title\">\r\n                                    ";
if ($_POST['search']) {
    echo "                                    \t搜索'";
    echo $_POST['name'];
    echo "'线路\r\n                                    ";
} else {
    echo '                                    共';
    $please = $DB->count('SELECT count(*) from `line` WHERE 1');
    echo $please;
    echo '条线路';
}
echo "\r\n                                     <div class=\"panel-ctrls\"><form action=\"./list_line.php\" method=\"post\" role=\"form\" >\r\n                                     <input type=\"hidden\" name=\"search\" value=\"search\">\r\n\t\t\t\t                    <input type=\"text\" class=\"form-control\" size=\"5\" placeholder=\"线路名称\" name=\"name\" data-validate=\"required\">\r\n\t\t\t\t               \r\n\t\t\t\t                </form>\r\n</div></h3>\r\n                                </div>\r\n                             </div> \r\n";
if (!($islogin2 == 1)) {
    exit('<script language=\'javascript\'>window.location.href=\'./login.php\';</script>');
}
if ($_GET['act'] == 'del') {
    $id = $_POST['id'];
    $sql = $DB->query('DELETE FROM `line` WHERE id=\'' . $id . '\'');
    if ($sql) {
        exit(json_encode(array('status' => 'success')));
    } else {
        exit(json_encode(array('status' => 'error')));
    }
} elseif ($_GET['act'] == 'show') {
    $show = $_POST['show'] == '1' ? '1' : '0';
    $id = $_POST['id'];
    $sql = $DB->query('update `line` set `show`=\'' . $show . '\' where `id`=\'' . $id . '\'');
    if ($sql) {
        exit(json_encode(array('status' => 'success')));
    } else {
        exit(json_encode(array('status' => 'error')));
    }
} else {
    echo " <hr>\r\n";
    $gid = $_GET['gid'];
    if ($_GET['gid'] == '') {
        $numrows = $DB->count('SELECT count(*) from `line`');
    } else {
        $numrows = $DB->count('SELECT count(*) from `line` WHERE `group`=' . $gid);
    }
    $pagesize = 20;
    $pages = intval($numrows / $pagesize);
    if ($numrows % $pagesize) {
        ($pages += 1) + -1;
    }
    if (isset($_GET['page'])) {
        $page = intval($_GET['page']);
    } else {
        $page = 1;
    }
    $offset = $pagesize * ($page - 1);
    $list = 1;
    if ($_GET['gid'] == '') {
        echo '&nbsp;<span class="label label-info" ><a href="?' . $t_str . '" style="color:#fff">全部</a></span>';
        $list = $DB->query('SELECT * FROM `line` order by id desc limit ' . $offset . ',' . $pagesize);
    } else {
        echo '&nbsp;<span ><a href="?' . $t_str . '" >全部</a></span>';
        $list = $DB->query('SELECT * FROM `line` WHERE `group`=' . $gid . ' order by id desc limit ' . $offset . ',' . $pagesize);
    }
    $rs = $DB->query('SELECT * FROM `line_grop`');
    while ($res = $DB->fetch($rs)) {
        if ($res['id'] == $_GET['gid']) {
            echo '&nbsp;&nbsp;&nbsp;&nbsp;<span class="label label-info" ><a href="?gid=' . $res['id'] . '" style="color:#fff">' . $res['name'] . '</a></span>';
        } else {
            echo '&nbsp;&nbsp;&nbsp;&nbsp;<span><a href="?gid=' . $res['id'] . '">' . $res['name'] . '</a></span>';
        }
    }
    echo "<hr>\r\n    <ul class=\"list-group\">\r\n    ";
    if ($_POST['search']) {
        $name = $_POST['name'];
        $list = $DB->query('SELECT * FROM `line` WHERE name LIKE \'%' . $name . '%\'');
    }
    while ($vo = $DB->fetch($list)) {
        echo ' <li class="list-group-item line-id-' . $vo['id'] . "\">\r\n        <span class=\"badge badge-pink\">" . $vo['type'] . "</span>\r\n        ID:" . $vo['id'] . '<br>名称:' . $vo['name'] . "\r\n        <p>标签：" . $vo['label'] . "</p>\r\n        <button type=\"button\" class=\"btn btn-warning btn-xs\" onclick=\"window.location.href='line_set.php?act=mod&id=" . $vo['id'] . '\'">编辑</button>&nbsp;';
        echo $vo['show'] == '1' ? '<button type="button" class="btn btn-primary btn-xs showstatus" onclick="qiyong(\'' . $vo['id'] . '\')" data="1">已启用</button>&nbsp;' : '<button type="button" class="btn btn-primary btn-xs showstatus" onclick="qiyong(\'' . $vo['id'] . '\')" data="0">已禁用</button>&nbsp;';
        echo '<button type="button" class="btn btn-danger btn-xs" onclick="delLine(\'' . $vo['id'] . "')\">删除</button>\r\n    </li>";
    }
    if (!$_POST['search']) {
        echo '</ul>';
        echo '<ul class="pagination">';
        $first = 1;
        $prev = $page - 1;
        $next = $page + 1;
        $last = $pages;
        if ($page > 1) {
            echo '<li><a href="?page=' . $first . $link . '&gid=' . $gid . '">首页</a></li>';
            echo '<li><a href="?page=' . $prev . $link . '&gid=' . $gid . '">&laquo;</a></li>';
        } else {
            echo '<li class="disabled"><a>首页</a></li>';
            echo '<li class="disabled"><a>&laquo;</a></li>';
        }
        $i = 1;
        while (!($i >= $page)) {
            echo '<li><a href="?page=' . $i . $link . '&gid=' . $gid . '">' . $i . '</a></li>';
            ($i += 1) + -1;
        }
        echo '<li class="disabled"><a>' . $page . '</a></li>';
        $i = $page + 1;
        while (!($i > $pages)) {
            echo '<li><a href="?page=' . $i . $link . '&gid=' . $gid . '">' . $i . '</a></li>';
            ($i += 1) + -1;
        }
        echo '';
        if (!($page >= $pages)) {
            echo '<li><a href="?page=' . $next . $link . '&gid=' . $gid . '">&raquo;</a></li>';
            echo '<li><a href="?page=' . $last . $link . '&gid=' . $gid . '">尾页</a></li>';
        } else {
            echo '<li class="disabled"><a>&raquo;</a></li>';
            echo '<li class="disabled"><a>尾页</a></li>';
        }
        echo '</ul>';
    }
}
echo " </div>  </div> \r\n<script>\r\nfunction qiyong(id){\r\n    var doc = \$('.line-id-'+id+' .showstatus');\r\n    if(doc.attr('data') == \"1\"){\r\n        doc.html(\"已禁用\").attr({'data':'0'});\r\n    }else{\r\n        doc.html(\"已启用\").attr({'data':'1'});\r\n    }\r\n    var url = \"list_line.php?act=show\";\r\n        var data = {\r\n            \"id\":id,\r\n            \"show\":doc.attr('data')\r\n        };\r\n        \$.post(url,data,function(data){\r\n            if(data.status == \"success\"){\r\n\r\n            }else{\r\n                alert(\"操作失败\");\r\n            }\r\n        },\"JSON\");\r\n}\r\nfunction delLine(id){\r\n    if(confirm('确认删除吗？删除后不可恢复哦！')){\r\n        \$('.line-id-'+id).slideUp();\r\n        var url = \"list_line.php?act=del\";\r\n        var data = {\r\n            \"id\":id\r\n        };\r\n        \$.post(url,data,function(data){\r\n            if(data.status == \"success\"){\r\n\r\n            }else{\r\n                alert(\"删除失败\");\r\n            }\r\n        },\"JSON\");\r\n    }\r\n}\r\n</script>\r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n";
include 'copy.php';
function success_go($msg, $url)
{
    echo "<div class=\"alert alert-success alert-dismissable\">\r\n            <button type=\"button\" class=\"close\" data-dismiss=\"alert\"\r\n                    aria-hidden=\"true\">\r\n                &times;\r\n            </button>\r\n            " . $msg . ',系统将在3秒后跳转。<a href="' . $url . "\">等不及了！</a>\r\n        </div> ";
    echo "<script>setTimeout(function(){\r\n            window.location.href=\"" . $url . "\";\r\n        },3000)</script>";
    return null;
}
function error_go($msg, $url)
{
    echo "<div class=\"alert alert-danger alert-dismissable\">\r\n            <button type=\"button\" class=\"close\" data-dismiss=\"alert\"\r\n                    aria-hidden=\"true\">\r\n                &times;\r\n            </button>\r\n            " . $msg . ',系统将在3秒后跳转。<a href="' . $url . "\">等不及了！</a>\r\n        </div> ";
    echo "<script>setTimeout(function(){\r\n            window.location.href=\"" . $url . "\";\r\n        },3000)</script>";
    return null;
}