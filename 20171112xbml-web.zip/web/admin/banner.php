<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
$bn = $DB->get_row('SELECT * FROM banner');
$img1 = $bn['img1'];
$img2 = $bn['img2'];
$img3 = $bn['img3'];
$img4 = $bn['img4'];
echo "               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>大图设置</h1>\r\n                                <div class=\"options\">\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n                            ";
$my = $_POST['my'];
if ($my == 'config') {
    echo '<div class="alert';
    $img1_c = daddslashes($_POST['img1']);
    $img2_c = daddslashes($_POST['img2']);
    $img3_c = daddslashes($_POST['img3']);
    $img4_c = daddslashes($_POST['img4']);
    $sql = $DB->query('UPDATE `banner` SET `img1` = \'' . $img1_c . '\',`img2` = \'' . $img2_c . '\',`img3` = \'' . $img3_c . '\',`img4` = \'' . $img4_c . '\' WHERE `banner`.`id` = 0');
    if ($sql) {
        echo ' alert-success">保存成功！ - 3秒后自动跳转<meta http-equiv="refresh" content="3;URL=banner.php">';
    } else {
        echo ' alert-danger">保存失败！';
    }
    echo '</div>';
    echo '<style>#banner{display: none;}</style>';
}
echo " <div id=\"banner\" class=\"row\">\r\n                <div class=\"col-sm-12\">\r\n                  <div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">请输入内容进行更新\r\n                    </div>\r\n                    <div class=\"panel-body\">\r\n<div class=\"alert alert-info\">\r\n图片和软件都是通过第三方平台上传后，复制文件地址粘贴至文本框即可\r\n<br><br>\r\n<span class=\"input-group-btn\" style=\"display: inline-table;\">\r\n  <button type=\"button\" class=\"btn btn-purple dropdown-toggle\" data-toggle=\"dropdown\">\r\n    图片上传平台 <span class=\"caret\"></span>\r\n  </button>\r\n  <ul class=\"dropdown-menu dropdown-purple no-spacing\">\r\n    <li><a target=\"_blank\" href=\"https://www.niupic.com/\">牛图网</a></li>\r\n    <li><a target=\"_blank\" href=\"http://img.hoop8.com/index.php\">Hoop8</a></li>\r\n    <li><a target=\"_blank\" href=\"http://chuantu.biz/\">Chuantu.biz</a></li>\r\n  </ul>\r\n</span>\r\n<span class=\"input-group-btn\" style=\"display: inline-table;\">\r\n  <button type=\"button\" class=\"btn btn-red dropdown-toggle\" data-toggle=\"dropdown\">\r\n    APP上传平台 <span class=\"caret\"></span>\r\n  </button>\r\n  <ul class=\"dropdown-menu dropdown-red no-spacing\">\r\n    <li><a target=\"_blank\" href=\"http://fir.im/\">fir.im</a></li>\r\n    <li><a target=\"_blank\" href=\"http://pre.im/\">pre.im</a></li>\r\n    <li><a target=\"_blank\" href=\"https://www.pgyer.com/\">蒲公英</a></li>\r\n  </ul>\r\n</span>\r\n</div>\r\n\r\n              <form  action=\"./banner.php\" method=\"post\" role=\"form\" class=\"form-horizontal validate\">\r\n                <div class=\"form-group-separator\"></div>\r\n                <div class=\"form-group\">\r\n                  <input type=\"hidden\" name=\"my\" value=\"config\"/>\r\n                  <label class=\"col-sm-2 control-label\">首页大图链接</label>\r\n                  <div class=\"col-sm-10\">\r\n                    <div class=\"input-group\">\r\n                      <span class=\"input-group-addon\">1920px*1282px</span>\r\n                      <input type=\"text\" class=\"form-control\" value=\"";
echo $img1;
echo "\" name=\"img1\" data-validate=\"required,url\">\r\n                      <span class=\"input-group-addon\"><a target=\"_blank\" href=\"";
echo $img1;
echo "\"><i class=\"linecons-search\"></i></a></span>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group\">\r\n                  <input type=\"hidden\" name=\"my\" value=\"config\"/>\r\n                  <label class=\"col-sm-2 control-label\">后台登录背景链接</label>\r\n                  <div class=\"col-sm-10\">\r\n                    <div class=\"input-group\">\r\n                      <span class=\"input-group-addon\">1920px*1282px</span>\r\n                      <input type=\"text\" class=\"form-control\" value=\"";
echo $img2;
echo "\" name=\"img2\" data-validate=\"required,url\">\r\n                      <span class=\"input-group-addon\"><a target=\"_blank\" href=\"";
echo $img2;
echo "\"><i class=\"linecons-search\"></i></a></span>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group-separator\"></div>\r\n                <div class=\"form-group\">\r\n                  <input type=\"hidden\" name=\"my\" value=\"config\"/>\r\n                  <label class=\"col-sm-2 control-label\">代理登陆注册背景链接</label>\r\n                  <div class=\"col-sm-10\">\r\n                    <div class=\"input-group\">\r\n                      <span class=\"input-group-addon\">1920px*1282px</span>\r\n                      <input type=\"text\" class=\"form-control\" value=\"";
echo $img3;
echo "\" name=\"img3\" data-validate=\"required,url\">\r\n                      <span class=\"input-group-addon\"><a target=\"_blank\" href=\"";
echo $img3;
echo "\"><i class=\"linecons-search\"></i></a></span>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group-separator\"></div>\r\n                <div class=\"form-group\">\r\n                  <input type=\"hidden\" name=\"my\" value=\"config\"/>\r\n                  <label class=\"col-sm-2 control-label\">用户登陆注册背景链接</label>\r\n                  <div class=\"col-sm-10\">\r\n                    <div class=\"input-group\">\r\n                      <span class=\"input-group-addon\">1920px*1282px</span>\r\n                      <input type=\"text\" class=\"form-control\" value=\"";
echo $img4;
echo "\" name=\"img4\" data-validate=\"required,url\">\r\n                      <span class=\"input-group-addon\"><a target=\"_blank\" href=\"";
echo $img4;
echo "\"><i class=\"linecons-search\"></i></a></span>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\"></label>\r\n                  <div class=\"col-sm-6\">\r\n                    <button type=\"submit\" type=\"button\" class=\"btn btn-info\">保存</button>\r\n                  </div>\r\n                </div>\r\n                \r\n              </form> \r\n                      \r\n                    </div>\r\n                  \r\n                  </div>\r\n                    \r\n                </div>\r\n            </div>\r\n   \r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n";
include 'copy.php';