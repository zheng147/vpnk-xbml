<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
$rs = $DB->get_row('SELECT * FROM xbml_token WHERE id=2');
$token = $rs['token'];
$rs1 = $DB->get_row('SELECT * FROM xbml_link WHERE id=3');
$gw = $rs1['url'];
$rs2 = $DB->get_row('SELECT * FROM xbml_link WHERE id=4');
$sm = $rs2['url'];
$rs3 = $DB->get_row('SELECT * FROM xbml_link WHERE id=2');
$km = $rs3['url'];
$rs4 = $DB->get_row('SELECT * FROM xbml_link WHERE id=1');
$lk = $rs4['url'];
$rs5 = $DB->get_row('SELECT * FROM xbml_gg WHERE id=1');
$gg1 = $rs5['1'];
$gg2 = $rs5['2'];
echo "               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>云端基本设置</h1>\r\n                                <div class=\"options\">\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n                            ";
$my = $_POST['my'];
if ($my == 'config') {
    echo '<div class="alert';
    $token = $_POST['token'];
    $lk = $_POST['lk'];
    $gw = $_POST['gw'];
    $sm = $_POST['sm'];
    $km = $_POST['km'];
    $gg1 = $_POST['gg1'];
    $gg2 = $_POST['gg2'];
    $sq = $DB->query('UPDATE `xbml_token` SET `token` = \'' . $token . '\' WHERE `id` = 2');
    $sq1 = $DB->query('UPDATE `xbml_link` SET `url` = \'' . $lk . '\' WHERE `id` = 1');
    $sq1 = $DB->query('UPDATE `xbml_link` SET `url` = \'' . $gw . '\' WHERE `id` = 3');
    $sq2 = $DB->query('UPDATE `xbml_link` SET `url` = \'' . $sm . '\' WHERE `id` = 4');
    $sq3 = $DB->query('UPDATE `xbml_link` SET `url` = \'' . $km . '\' WHERE `id` = 2');
    $sq4 = $DB->query('UPDATE `xbml_gg` SET `1` = \'' . $gg1 . '\',`2` = \'' . $gg2 . '\' WHERE `id` = 1');
    if (!$sq) {
        $yes = 0;
    }
    if (!$sq1) {
        $yes = 0;
    }
    if (!$sq2) {
        $yes = 0;
    }
    if (!$sq3) {
        $yes = 0;
    }
    if (!$sq4) {
        $yes = 0;
    } else {
        $yes = 1;
    }
    if ($yes == 1) {
        echo " alert-success\">\r\n                    <button type=\"button\" class=\"close\">\r\n                      <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>保存成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=openset.php\">";
    } else {
        echo " alert-danger\">\r\n                    <button type=\"button\" class=\"close\">\r\n                      <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>保存失败！";
    }
    echo '</div>';
    echo '<style>#openset{display: none;}</style>';
}
echo "<div  id=\"openset\" class=\"row\">\r\n                <div class=\"col-sm-12\">\r\n                    \r\n                  <div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">请输入内容进行更新\r\n                    </div>\r\n                    <div class=\"panel-body\">\r\n\r\n              <form action=\"./openset.php\" method=\"post\" role=\"form\" class=\"form-horizontal validate\">     \r\n              \r\n              \r\n                <div class=\"form-group\">        \r\n                  <input type=\"hidden\" name=\"my\" value=\"config\"/> \r\n                \r\n                  <label class=\"col-sm-2 control-label\">接口key</label>\r\n                  <div class=\"col-sm-10\">\r\n                    <input type=\"text\" class=\"form-control\" id=\"field-1\" value=\"";
echo $token;
echo "\" name=\"token\" data-validate=\"required\">\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group-separator\"></div>\r\n                \r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\">流控地址</label>\r\n                  <div class=\"col-sm-10\">\r\n                    <input type=\"text\" class=\"form-control\" id=\"field-1\" value=\"";
echo $lk;
echo "\" name=\"lk\" data-validate=\"required\">\r\n                  </div>\r\n                </div>\r\n                \r\n                \r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\">官网地址</label>\r\n                  <div class=\"col-sm-10\">\r\n                    <input type=\"text\" class=\"form-control\" id=\"field-1\" value=\"";
echo $gw;
echo "\" name=\"gw\" data-validate=\"required\">\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\">使用说明</label>\r\n                  <div class=\"col-sm-10\">\r\n                    <input type=\"text\" class=\"form-control\" id=\"field-1\" value=\"";
echo $sm;
echo "\" name=\"sm\">\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\">卡密地址</label>\r\n                  <div class=\"col-sm-10\">\r\n                    <input type=\"text\" class=\"form-control\" id=\"field-1\" value=\"";
echo $km;
echo "\" name=\"km\">\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\">公告1</label>\r\n                  <div class=\"col-sm-10\">\r\n                    <input type=\"text\" class=\"form-control\" id=\"field-1\" value=\"";
echo $gg1;
echo "\" name=\"gg1\">\r\n                  </div>\r\n                </div>\r\n                \r\n                \r\n                \r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\">公告2</label>\r\n                  <div class=\"col-sm-10\">\r\n                    <input type=\"text\" class=\"form-control\" id=\"field-1\" value=\"";
echo $gg2;
echo "\" name=\"gg2\">\r\n                  </div>\r\n                </div>\r\n                \r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\"></label>\r\n                  <div class=\"col-sm-6\">\r\n                    <button type=\"submit\" type=\"button\" class=\"btn btn-info\">保存</button>\r\n                  </div>\r\n                </div>\r\n                \r\n              </form> \r\n                      \r\n                    </div>\r\n                  \r\n                  </div>\r\n                    \r\n                </div>\r\n            </div>\r\n   \r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n";
include 'copy.php';