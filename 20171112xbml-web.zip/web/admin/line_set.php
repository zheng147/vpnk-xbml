<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "\r\n               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>线路编辑</h1>\r\n                                <div class=\"options\">\r\n                                <a href=\"list_line.php\" class=\"btn btn-info btn-single\">线路列表</a>\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n                            <div class=\"col-sm-12\">\r\n                    <div class=\"panel panel-success\">\r\n                    <div class=\"panel-heading\">\r\n                      <h2>线路编辑</h2>\r\n                      </div>\r\n        <div class=\"panel-body\">\r\n";
$id = $_GET['id'];
$name = $_POST['name'];
$type = $_POST['type'];
$label = $_POST['label'];
$content = $_POST['content'];
$group = $_POST['group'];
$show = $_POST['show'] == '1' ? '1' : '0';
if ($_GET['act'] == 'update') {
    $sql = $DB->query('update `line` set `name`=\'' . $name . '\',`type`=\'' . $type . '\',`label`=\'' . $label . '\',`content`=\'' . $content . '\',`group`=\'' . $group . '\',`show`=\'' . $show . '\' where `id`=\'' . $id . '\'');
    if ($sql) {
        success_go('修改线路【' . $_POST['name'] . '】成功！ </div> ', 'add_line.php?act=mod&id=' . $_GET['id']);
    } else {
        error_go('十分抱歉修改失败', 'add_line.php?act=mod&id=' . $_GET['id']);
    }
} elseif ($_GET['act'] == 'add') {
    $sql = 'insert into `line` (`name`,`type`,`label`,`content`,`group`,`time`,`show`) values (\'' . $name . '\',\'' . $type . '\',\'' . $label . '\',\'' . $content . '\',\'' . $group . '\',\'' . time() . ('\',\'' . $show . '\')');
    if ($DB->query($sql)) {
        success_go('新增线路【' . $_POST['name'] . '】成功！ </div> ', 'add_line.php');
    } else {
        error_go('十分抱歉添加失败', 'add_line.php');
    }
} else {
    $action = '?act=add';
    if ($_GET['act'] == 'mod') {
        $rs = $DB->query('SELECT * FROM `line` WHERE `id`=' . $id);
        $info = $DB->fetch($rs);
        $action = '?act=update&id=' . $_GET['id'];
    }
    echo "\r\n\r\n    <form class=\"form-horizontal validate\" role=\"form\" method=\"POST\" action=\"";
    echo $action;
    echo "\">\r\n    <div class=\"form-group\">\r\n        <label for=\"firstname\" class=\"col-sm-2 control-label\">线路名称</label>\r\n       <div class=\"col-sm-10\">\r\n            <input type=\"text\" class=\"form-control\" name=\"name\" placeholder=\"线路名称\" value=\"";
    echo $info['name'];
    echo "\">\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"form-group\">\r\n        <label for=\"lastname\" class=\"col-sm-2 control-label\">线路类型</label>\r\n        <div class=\"col-sm-10\">\r\n            <input type=\"text\" class=\"form-control\" name=\"type\" placeholder=\"线路类型\" value=\"";
    echo $info['type'];
    echo "\">\r\n        </div>\r\n    </div>\r\n\r\n      <div class=\"form-group\">\r\n        <label for=\"lastname\" class=\"col-sm-2 control-label\">显示标签</label>\r\n        <div class=\"col-sm-10\">\r\n            <input type=\"text\" class=\"form-control\" name=\"label\" placeholder=\"显示标签\" value=\"";
    echo $info['label'];
    echo "\">\r\n        </div>\r\n    </div>\r\n\r\n      <div class=\"form-group\" >\r\n        <label for=\"name\" class=\"col-sm-2 control-label\">分组选择</label>\r\n         <div class=\"col-sm-10\"><select class=\"form-control\" name=\"group\">\r\n            ";
    $list = $DB->query('SELECT * FROM `line_grop` order by id desc');
    while ($vo = $DB->fetch($list)) {
        $selected = '';
        if ($info['group'] == $vo['id']) {
            $selected = 'selected';
        }
        echo '<option value="' . $vo['id'] . '" ' . $selected . '>' . $vo['name'] . '</option>';
    }
    echo "        </select></div>\r\n    </div>\r\n\r\n    <div class=\"form-group\" >\r\n        <label for=\"name\" class=\"col-sm-2 control-label\">线路内容</label>\r\n         <div class=\"col-sm-10\">\r\n          <a type=\"submit\" class=\"btn btn-success\" onclick=\"autoGs()\" href=\"javascript:void(0);\">自动换行</a>\r\n         <textarea class=\"form-control\" rows=\"10\" placeholder=\"只需输入免流代码部分，无需输入Key.证书等\" name=\"content\">";
    echo $info['content'];
    echo "</textarea></div>\r\n    </div>\r\n <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\">线路状态</label>\r\n                    <div class=\"col-sm-4\">\r\n                      <label class=\"radio-inline\">\r\n                        <input type=\"radio\" name=\"show\" id=\"optionsRadios1\" value=\"1\" checked=\"\">\r\n                        启用\r\n                      </label>\r\n                      <label class=\"radio-inline\">\r\n                        <input type=\"radio\" name=\"show\" id=\"optionsRadios2\" value=\"0\">\r\n                        禁用\r\n                      </label>\r\n                    </div>\r\n                  </div>\r\n    <div class=\"form-group\">\r\n        <div class=\"col-sm-offset-2 col-sm-10\">\r\n            <button type=\"submit\" class=\"btn btn-primary\">提交数据</button>\r\n        </div>\r\n    </div>\r\n\r\n</form> \r\n    </div>\r\n    <script>\r\n    function autoGs(){\r\n        var content = \$(\"[name=content]\").val();\r\n        content = content.replace(\"\\n\\r\",\"\\n\");  \r\n        content = content.replace(\"\\n\",\"\\n\\r\");\r\n        \$(\"[name=content]\").val(content);\r\n    }\r\n    </script>\r\n    \r\n";
}
echo "</div>\r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n";
include 'copy.php';
function success_go($msg, $url)
{
    echo "<div class=\"breadcrumbs\">\r\n            <button type=\"button\" class=\"close\" data-dismiss=\"alert\"\r\n                    aria-hidden=\"true\">\r\n                &times;\r\n            </button>\r\n            " . $msg . ',系统将在3秒后跳转。<a href="' . $url . "\">等不及了！</a>\r\n        </div> ";
    echo "<script>setTimeout(function(){\r\n            window.location.href=\"" . $url . "\";\r\n        },3000)</script>";
    return null;
}
function error_go($msg, $url)
{
    echo "<div class=\"breadcrumbs\">\r\n            <button type=\"button\" class=\"close\" data-dismiss=\"alert\"\r\n                    aria-hidden=\"true\">\r\n                &times;\r\n            </button>\r\n            " . $msg . ',系统将在3秒后跳转。<a href="' . $url . "\">等不及了！</a>\r\n        </div> ";
    echo "<script>setTimeout(function(){\r\n            window.location.href=\"" . $url . "\";\r\n        },3000)</script>";
    return null;
}