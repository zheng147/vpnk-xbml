<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "\r\n               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>服务器列表</h1>\r\n                                <div class=\"options\">\r\n                                <button data-target=\"#addfwq\" class=\"btn btn-info btn-single\" data-toggle=\"modal\">添加服务器</button>\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n                            ";
$my = isset($_GET['my']) ? $_GET['my'] : null;
if ($my == 'del') {
    echo '<div class="alert';
    $id = daddslashes($_GET['id']);
    $sql = $DB->query('DELETE FROM `auth_fwq` WHERE id=\'' . $id . '\'');
    if ($sql) {
        echo " alert-success\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=fwqlist.php\">";
    } else {
        echo " alert-danger\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除失败！";
    }
    echo '</div>';
} else {
    if (!empty($_GET['kw'])) {
        $sql = ' `name`=\'' . $_GET['kw'] . '\'';
        $numrows = $DB->count('SELECT count(*) from `auth_fwq` WHERE' . $sql);
        $con = '共有 ' . $numrows . ' 个服务器';
    } else {
        $numrows = $DB->count('SELECT count(*) from `auth_fwq` WHERE 1');
        $sql = ' 1';
        $con = '平台共' . $numrows . '个服务器';
    }
    echo "<div class=\"row\">\r\n    <div class=\"col-md-12\">\r\n        <div class=\"panel panel-default\">\r\n            <div class=\"panel-heading\">\r\n                <h2>";
    echo $con;
    echo "</h2>\r\n                <div class=\"panel-ctrls\"><form action=\"fwqlist.php\">\r\n                <label class=\"panel-ctrls-center\"> <input type=\"text\" class=\"form-control\" size=\"10\" name=\"kw\" placeholder=\"搜索（名称）\"></label>\r\n                 </form></div>\r\n            </div>\r\n            <div class=\"panel-body panel-no-padding\">\r\n            <div class=\"table-responsive\">\r\n                <table id=\"example\" class=\"table table-bordered table-fixed-header m0\" cellspacing=\"0\" width=\"100%\">\r\n                    <thead>\r\n                        <tr>\r\n                            <th>ID</th>\r\n                            <th>名称</th>\r\n                            <th>地址</th>\r\n                            <th>在线人数</th>\r\n                            <th>添加时间</th>\r\n                            <th>操作</th>\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n                      ";
    $pagesize = 10;
    $pages = intval($numrows / $pagesize);
    if ($numrows % $pagesize) {
        ($pages += 1) + -1;
    }
    if (isset($_GET['page'])) {
        $page = intval($_GET['page']);
    } else {
        $page = 1;
    }
    $offset = $pagesize * ($page - 1);
    $rs = $DB->query('SELECT * FROM `auth_fwq` WHERE' . $sql . ' order by id desc limit ' . $offset . ',' . $pagesize);
    while ($res = $DB->fetch($rs)) {
        $str = file_get_contents('http://' . $res['ipport'] . '/res/tcp.txt', false, stream_context_create(array('http' => array('method' => 'GET', 'timeout' => 1))));
        $str2 = file_get_contents('http://' . $res['ipport'] . '/udp/udp.txt', false, stream_context_create(array('http' => array('method' => 'GET', 'timeout' => 1))));
        $onlinenum_tcp = (substr_count($str, date('Y')) - 1) / 2;
        $onlinenum_udp = (substr_count($str2, date('Y')) - 1) / 2;
        $onlinenum = $onlinenum_tcp + $onlinenum_udp;
        if (!($onlinenum >= 0)) {
            $onlinetext = '<span style="color:red;">超时</span>';
        } else {
            $onlinetext = '<a href="online.php?id=' . $res['id'] . '">' . $onlinenum . '</a>';
        }
        $onlinetext2 = '<a class="btn btn-xs btn-success" href="online.php?id=' . $res['id'] . '">在线人数</a>';
        echo "                                          <tr>\r\n                                          <th><span class=\"co-name\">";
        echo $res['id'];
        echo "</span></th>\r\n                                          <td>";
        echo $res['name'];
        echo "</td>\r\n                                          <td>";
        echo $res['ipport'];
        echo "</td>\r\n                                          <td>";
        echo $onlinetext;
        echo "</td>\r\n                                          <td>";
        echo $res['time'];
        echo "</td>\r\n                                          <td>";
        echo $onlinetext2;
        echo '&nbsp;<a class="btn btn-xs btn-info" href="./fwqset.php?id=';
        echo $res['id'];
        echo '">配置</a>&nbsp;<a href="./fwqlist.php?my=del&id=';
        echo $res['id'];
        echo "\" class=\"btn btn-xs btn-danger\" onclick=\"if(!confirm('你确实要删除此记录吗？')){return false;}\">删除</a></td>\r\n                                          </tr>\r\n                                          ";
    }
    echo "                                      </tbody>\r\n                                  </table>\r\n                       </div>\r\n                      \r\n                      <div class=\"panel-footer\">\r\n                      <div class=\"row\">\r\n                      <div class=\"col-sm-12\">\r\n                      <div class=\"dataTables_paginate paging_bootstrap\" id=\"example_paginate\">\r\n                       ";
    echo '<ul class="pagination pull-right m0">';
    $first = 1;
    $prev = $page - 1;
    $next = $page + 1;
    $last = $pages;
    if ($page > 1) {
        echo '<li class="previous disabled"><a href="fwqlist.php?page=' . $first . $link . '">首页</a></li>';
    } else {
        echo '<li class="previous disabled"><a>首页</a></li>';
    }
    $i = 1;
    while (!($i >= $page)) {
        echo '<li class="active"><a href="fwqlist.php?page=' . $i . $link . '">' . $i . '</a></li>';
        ($i += 1) + -1;
    }
    echo '<li  class="active"><a>' . $page . '</a></li>';
    $i = $page + 1;
    while (!($i > $pages)) {
        echo '<li><a href="fwqlist.php?page=' . $i . $link . '">' . $i . '</a></li>';
        ($i += 1) + -1;
    }
    echo '';
    if (!($page >= $pages)) {
        echo '<li class="next disabled"><a href="fwqlist.php?page=' . $last . $link . '">尾页</a></li>';
    } else {
        echo '<li class="next disabled"><a>尾页</a></li>';
    }
    echo '</ul>';
}
echo "                      </div>\r\n                      </div>\r\n                      </div>\r\n                      </div>\r\n\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n                      ";
if ($_POST['name']) {
    $name = daddslashes($_POST['name']);
    $ipport = daddslashes($_POST['ipport']);
    if (!$DB->get_row('select * from `auth_fwq` where `name`=\'' . $name . '\' limit 1')) {
        $sql = 'insert into `auth_fwq` (`name`,`ipport`) values (\'' . $name . '\',\'' . $ipport . '\')';
        if ($DB->query($sql)) {
            exit('<script language=\'javascript\'>alert(\'成功添加一个服务器！\');window.location.href=\'./fwqlist.php\';</script>');
        } else {
            exit('<script language=\'javascript\'>alert(\'添加失败\');window.location.href=\'./fwqlist.php\';</script>');
        }
    } else {
        exit('<script language=\'javascript\'>alert(\'该服务器已存在！\');window.location.href=\'./fwqlist.php\';</script>');
    }
}
echo "<div class=\"modal fade\" id=\"addfwq\" role=\"dialog\" tabindex=\"-1\" aria-labelledby=\"addfwq\" aria-hidden=\"true\">\r\n<div class=\"modal-dialog\">\r\n<div class=\"modal-content\">\r\n<div class=\"modal-header\">\r\n<form action=\"./fwqlist.php\" method=\"POST\" class=\"form-inline\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"modal\"><i class=\"pci-cross pci-circle\"></i></button>\r\n<h4 class=\"modal-title\">添加服务器</h4>\r\n</div>\r\n<br>\r\n<div class=\"panel-body\">\r\n   <div class=\"col-md-2\"><label>服务器名称</label></div>\r\n   <div class=\"col-md-12\">\r\n<div class=\"form-group\">\r\n <input type=\"text\" class=\"form-control\" id=\"field-1\" placeholder=\"服务器名称\" name=\"name\" data-validate=\"required\">\r\n</div>\r\n</div>\r\n</br>\r\n  <div class=\"col-md-2\"><label>IP:端口</label></div>\r\n   <div class=\"col-md-12\">\r\n  <div class=\"form-group\">\r\n <input type=\"text\" class=\"form-control\" id=\"field-1\" placeholder=\"IP:端口\" name=\"ipport\" data-validate=\"required\">\r\n  </div>\r\n</div>\r\n</br>\r\n  <div class=\"col-md-12\">\r\n<div class=\"modal-footer\">\r\n<input type=\"submit\" value=\"添加\" class=\"btn btn-primary\"/>\r\n</div></div>\r\n</form>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n";
include 'copy.php';