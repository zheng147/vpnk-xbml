<?php /* by:凌一 QQ:863963860*/

include '../api.php';
$id = $_GET['id'];
$res = $DB->get_row('SELECT * FROM `xbml_article` where `id`=\'' . $id . '\' limit 1');
$name = $res['title'];
$name = urldecode($name);
$name = mb_convert_encoding($name, 'GB2312', 'UTF-8');
$mo = $res['content'];
$fp = fopen($name . '.ovpn', 'w');
@fopen($name . '.ovpn', 'w');
fwrite($fp, $mo);
$filename = $name . '.ovpn';
header('Content-Type:text/txt');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length:' . filesize($filename));
readfile($filename);