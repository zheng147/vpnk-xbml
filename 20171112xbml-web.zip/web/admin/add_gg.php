<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "\r\n               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>添加公告</h1>\r\n                                <div class=\"options\">\r\n                                <a class=\"btn btn-info btn-single\" href=\"list_gg\">公告列表</a>\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n                            <div class=\"col-sm-12\">\r\n                    <div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">\r\n                      <h2\">添加公告</h2>\r\n                      </div>\r\n        <div class=\"panel-body\">\r\n\r\n";
$id = $_GET['id'];
$name = $_POST['name'];
$content = $_POST['content'];
if ($_GET['act'] == 'update') {
    $sql = $DB->query('update `app_gg` set `name`=\'' . $name . '\',`content`=\'' . $content . '\' where `id`=\'' . $id . '\'');
    if ($sql) {
        success_go('公告修改成功', 'list_gg.php?act=mod&id=' . $_GET['id']);
        echo '</div>';
    } else {
        error_go('十分抱歉修改失败', 'list_gg.php?act=mod&id=' . $_GET['id']);
        echo '</div>';
    }
} elseif ($_GET['act'] == 'add') {
    $sql = 'insert into `app_gg` (`name`,`content`,`time`) values (\'' . $name . '\',\'' . $content . '\',\'' . time() . '\')';
    if ($DB->query($sql)) {
        success_go('新增消息【' . $_POST['name'] . '】成功！', 'list_gg.php');
        echo '</div>';
    } else {
        error_go('十分抱歉修改失败', 'list_gg.php');
        echo '</div>';
    }
} else {
    $action = '?act=add';
    if ($_GET['act'] == 'mod') {
        $rs = $DB->query('SELECT * FROM `app_gg` WHERE `id`=' . $id);
        $info = $DB->fetch($rs);
        $action = '?act=update&id=' . $_GET['id'];
    }
    echo "\r\n                  <div class=\"tile-body color transparent-black rounded-corners\">\r\n    <form class=\"form-horizontal\" role=\"form\" method=\"POST\" action=\"";
    echo $action;
    echo "\" onsubmit=\"return checkStr()\">\r\n    <div class=\"form-group\">\r\n        <label for=\"firstname\" class=\"col-sm-2 control-label\">标题</label>\r\n        <div class=\"col-sm-10\">\r\n            <input type=\"text\" class=\"form-control\" name=\"name\" placeholder=\"标题\" value=\"";
    echo $info['name'];
    echo "\">\r\n        </div>\r\n    </div>\r\n    \r\n    \r\n    \r\n    <div class=\"form-group\" >\r\n        <label for=\"name\" class=\"col-sm-2 control-label\">内容</label>\r\n         <div class=\"col-sm-10\"><textarea class=\"form-control\" rows=\"10\" name=\"content\">";
    echo $info['content'];
    echo "</textarea></div>\r\n    </div>\r\n    \r\n    <div class=\"form-group\">\r\n        <div class=\"col-sm-offset-2 col-sm-10\">\r\n            <button type=\"submit\" class=\"btn btn-primary btn-single\">提交数据</button>\r\n        </div>\r\n    </div>\r\n</form> \r\n    </div></div></div>\r\n        <script>\r\n    function checkStr(){\r\n        var title = \$('[name=\"title\"]').val();\r\n        var content = \$('[name=\"content\"]').val();\r\n        if(title == \"\" || content ==　\"\"){\r\n            alert(\"标题与内容不得为空\");\r\n            return false;\r\n        }\r\n        return true;\r\n    }\r\n    </script>\r\n    ";
}
echo "   </div>\r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n";
include 'copy.php';
function success_go($msg, $url)
{
    echo "<div class=\"tile-header\">\r\n            <button type=\"button\" class=\"close\" data-dismiss=\"alert\"\r\n                    aria-hidden=\"true\">\r\n                &times;\r\n            </button>\r\n            " . $msg . ',系统将在3秒后跳转。<a href="' . $url . "\">等不及了！</a>\r\n        </div> ";
    echo "<script>setTimeout(function(){\r\n            window.location.href=\"" . $url . "\";\r\n        },3000)</script>";
    return null;
}
function error_go($msg, $url)
{
    echo "<div class=\"tile-header\">\r\n            <button type=\"button\" class=\"close\" data-dismiss=\"alert\"\r\n                    aria-hidden=\"true\">\r\n                &times;\r\n            </button>\r\n            " . $msg . ',系统将在3秒后跳转。<a href="' . $url . "\">等不及了！</a>\r\n        </div> ";
    echo "<script>setTimeout(function(){\r\n            window.location.href=\"" . $url . "\";\r\n        },3000)</script>";
    return null;
}