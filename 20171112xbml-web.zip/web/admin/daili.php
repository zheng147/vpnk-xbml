<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "\r\n               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>代理管理</h1>\r\n                                <div class=\"options\">  <a href=\"dlconfig.php\" class=\"btn btn-info\">代理设置</a>\r\n</div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n";
$my = $_GET['my'];
if ($my == 'black1') {
    $user = $_GET['user'];
    echo "<div class=\"alert alert-success\">\r\n                    <button type=\"button\" class=\"close\" data-dismiss=\"alert\">\r\n                      <span aria-hidden=\"true\">×</span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>";
    $id = $_GET['id'];
    $sql = $DB->query('update `auth_daili` set `active`=\'0\' where `user`=\'' . $user . '\'');
    if ($sql) {
        echo '设置成功，状态为未激活！';
    } else {
        echo '设置失败！';
    }
    echo '</div>';
} elseif ($my == 'black2') {
    $user = $_GET['user'];
    echo "<div class=\"panel panel-default\">\r\n                        <div class=\"panel-heading\">\r\n                        代理充值</div>\r\n                        <div class=\"panel-body\">\r\n<form action=\"./daili.php?\" method=\"get\" class=\"form-inline validate\" role=\"form\">\r\n            <div class=\"form-group\">\r\n            <input type=\"text\" name=\"user\" value=" . $user . " hidden />\r\n            <input type=\"text\" name=\"my\" value=\"black2\" hidden/>\r\n              <input type=\"text\" name=\"s\" size=\"25\" value=\"\" class=\"form-control\"  placeholder=\"为" . $user . "充值多少金额？\" data-validate=\"required,number\"/>\r\n            </div>\r\n            <input type=\"submit\" value=\"充值\" class=\"btn btn-warning btn-single\"/>\r\n          </form>\r\n</div>\r\n                    </div>";
    if ($_GET['s'] && $_GET['user']) {
        $s = $_GET['s'];
        if ($s > 999999) {
            exit('<script language=\'javascript\'>alert(\'数据非法！\');history.go(-1);</script>');
        }
        echo "<div class=\"alert alert-success\">\r\n                                        <button type=\"button\" class=\"close\" data-dismiss=\"alert\">\r\n                                            <span aria-hidden=\"true\">×</span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>为 ";
        echo $user;
        $rs = $DB->get_row('SELECT * FROM auth_daili WHERE user=\'' . $user . '\' limit 1');
        $rmb = $rs['rmb'] + $s;
        $sql = $DB->query('update `auth_daili` set `rmb`=\'' . $rmb . '\' where `user`=\'' . $user . '\'');
        if ($rs['tj_user']) {
            $rmb2 = $s * $conf_rate;
            $sql2 = $DB->query('update `auth_daili` set `tj_rmb`=`tj_rmb`+' . $rmb2 . ' where `user`=\'' . $rs['tj_user'] . '\'');
        }
        if ($sql) {
            echo ' 充值成功，' . $s . '元！</div>';
            wlog('代理充值', '管理员为代理' . $user . '充值' . $s . '元[' . $date . ']');
        } else {
            echo '充值失败！';
        }
        echo '';
    } else {
        echo '';
    }
} elseif ($my == 'black3') {
    $user = daddslashes($_GET['user']);
    $rs = $DB->get_row('SELECT * FROM auth_daili WHERE user=\'' . $user . '\' limit 1');
    $name = $rs['name'];
    $qq = $rs['qq'];
    $tel = $rs['tel'];
    $buy = $rs['buy'];
    $buy2 = $rs['buy2'];
    echo "<div id=\"daili_info\" class=\"panel panel-default panel-border panel-shadow\"><!-- Add class \"collapsed\" to minimize the panel -->\r\n                        <div class=\"panel-heading\">\r\n                         修改信息\r\n                        </div>\r\n                        \r\n                        <div class=\"panel-body\">\r\n<form action=\"./daili.php?\" method=\"get\" class=\"form-horizontal validate\" role=\"form\">\r\n            <input type=\"text\" name=\"user\" value=" . $user . " hidden />\r\n            <input type=\"text\" name=\"my\" value=\"black3\" hidden/>\r\n<div class=\"form-group\">\r\n  <label class=\"col-sm-2 control-label\" for=\"field-1\">姓名</label>\r\n  <div class=\"col-sm-10\">\r\n    <input type=\"text\" class=\"form-control\"id=\"field-1\" value=\"" . $name . "\" name=\"name\" data-validate=\"required\"/>\r\n  </div>\r\n</div>\r\n<div class=\"form-group\">\r\n  <label class=\"col-sm-2 control-label\" for=\"field-2\">密码</label>\r\n  <div class=\"col-sm-10\">\r\n    <input type=\"text\" class=\"form-control\"id=\"field-2\" value=\"" . $rs['pass'] . "\" name=\"mima\" data-validate=\"required\"/>\r\n  </div>\r\n</div>\r\n<div class=\"form-group\">\r\n  <label class=\"col-sm-2 control-label\" for=\"field-3\">QQ</label>\r\n  <div class=\"col-sm-10\">\r\n    <input type=\"text\" class=\"form-control\"id=\"field-3\" value=\"" . $qq . "\" name=\"qq\" data-validate=\"required\"/>\r\n  </div>\r\n</div>\r\n<div class=\"form-group\">\r\n  <label class=\"col-sm-2 control-label\" for=\"field-4\">电话</label>\r\n  <div class=\"col-sm-10\">\r\n    <input type=\"text\" class=\"form-control\"id=\"field-4\" value=\"" . $tel . "\" name=\"tel\" data-validate=\"required\"/>\r\n  </div>\r\n</div>\r\n<div class=\"form-group\">\r\n  <label class=\"col-sm-2 control-label\" for=\"field-4\">购买链接</label>\r\n  <div class=\"col-sm-10\">\r\n    <input type=\"text\" class=\"form-control\"id=\"field-4\" value=\"" . $buy . "\" name=\"buy\" data-validate=\"url\"/>\r\n  </div>\r\n</div>\r\n<div class=\"form-group\">\r\n  <label class=\"col-sm-2 control-label\" for=\"field-4\">支付代码</label>\r\n  <div class=\"col-sm-10\">\r\n    <textarea class=\"form-control\" cols=\"5\" id=\"field-5\" name=\"buy2\">" . $buy2 . "</textarea>\r\n  </div>\r\n</div>\r\n<div class=\"form-group\">\r\n  <label class=\"col-sm-2 control-label\"></label>\r\n  <div class=\"col-sm-10\">\r\n    <input type=\"submit\" value=\"修改\" class=\"btn btn-purple btn-single\"/>\r\n  </div>\r\n</div>\r\n          </form>\r\n                        </div>\r\n                    </div>";
    $mima = daddslashes($_GET['mima']);
    $name_c = daddslashes($_GET['name']);
    $qq_c = daddslashes($_GET['qq']);
    $tel_c = daddslashes($_GET['tel']);
    $buy_c = daddslashes($_GET['buy']);
    $buy2_c = daddslashes($_GET['buy2']);
    if ($mima != '') {
        $sql = $DB->query('update `auth_daili` set `name`=\'' . $name_c . '\', `pass`=\'' . $mima . '\', `qq`=\'' . $qq_c . '\', `tel`=\'' . $tel_c . '\', `buy`=\'' . $buy_c . '\', `buy2`=\'' . $buy2_c . '\' where `user`=\'' . $user . '\'');
        if ($sql) {
            echo "<div class=\"alert alert-success\">\r\n                                        <button type=\"button\" class=\"close\" data-dismiss=\"alert\">\r\n                                            <span aria-hidden=\"true\">×</span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>\r\n                                        设置成功！\r\n                                    </div>";
            echo '<style>#daili_info{display: none;}</style>';
        } else {
            echo "<div class=\"alert alert-danger\">\r\n                                        设置失败！\r\n                                    </div>";
        }
    } else {
        echo "<div class='alert alert-warning'>\r\n                                        为<strong>" . $user . '</strong> 更改信息，密码不能为空！</div>';
    }
    echo '';
} elseif ($my == 'black0') {
    $user = daddslashes($_GET['user']);
    echo "<div class=\"alert alert-success\">\r\n                    <button type=\"button\" class=\"close\" data-dismiss=\"alert\">\r\n                      <span aria-hidden=\"true\">×</span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>";
    $id = daddslashes($_GET['id']);
    $sql = $DB->query('update `auth_daili` set `active`=\'1\' where `user`=\'' . $user . '\'');
    if ($sql) {
        echo '设置成功，状态为已激活！';
    } else {
        echo '设置失败！';
    }
    echo '</div>';
} elseif ($my == 'vip') {
    $user = daddslashes($_GET['user']);
    $rs = $DB->get_row('SELECT * FROM auth_daili WHERE user=\'' . $user . '\' limit 1');
    $vip = daddslashes($rs['vip']);
    echo "<div class=\"panel panel-default panel-border panel-shadow\"><!-- Add class \"collapsed\" to minimize the panel -->\r\n                        <div class=\"panel-heading\">\r\n                       更改代理级别\r\n                        </div>\r\n                        \r\n                        <div class=\"panel-body\">\r\n<div class=\"alert alert-default\">\r\n                    <button type=\"button\" class=\"close\" data-dismiss=\"alert\">\r\n                      <span aria-hidden=\"true\">×</span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>\r\n                    <strong> 为" . $user . "更新代理级别！</strong>\r\n                  </div>\r\n<form action=\"./daili.php?\" method=\"get\" class=\"form-inline\" role=\"form\">\r\n            <div class=\"form-group\">\r\n            <input type=\"text\" name=\"user\" value=" . $user . " hidden />\r\n            <input type=\"text\" name=\"my\" value=\"vip\" hidden/>\r\n             <select name=\"vip\" class=\"form-control\">\r\n                <option value=\"0\">普通代理</option>\r\n                <option value=\"1\">铜牌代理</option>\r\n                <option value=\"2\">银牌代理</option>\r\n                <option value=\"3\">金牌代理</option>\r\n                <option value=\"4\">钻石代理</option>\r\n                <option value=\"5\">至尊代理</option>\r\n              </select>\r\n            </div>\r\n            <input type=\"submit\" value=\"升级\" class=\"btn btn-info btn-single\"/>\r\n          </form>\r\n                        </div>\r\n                    </div>";
    if (isset($_GET['vip']) && $_GET['user']) {
        $vip = daddslashes($_GET['vip']);
        if ($vip > 5) {
            exit('<script language=\'javascript\'>alert(\'数据非法！\');history.go(-1);</script>');
        }
        echo "<div class=\"alert alert-success\">\r\n                                        <button type=\"button\" class=\"close\" data-dismiss=\"alert\">\r\n                                            <span aria-hidden=\"true\">×</span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>\r\n                                    ";
        echo $user;
        $rs = $DB->get_row('SELECT * FROM auth_daili WHERE user=\'' . $user . '\' limit 1');
        $sql = $DB->query('update `auth_daili` set `vip`=\'' . $vip . '\' where `user`=\'' . $user . '\'');
        if ($sql) {
            echo '升级成功，当前为VIP' . $vip . '';
        } else {
            echo '升级失败！';
        }
        echo '</div>';
    } else {
        echo '';
    }
} elseif ($my == 'del') {
    $user = daddslashes($_GET['user']);
    echo "<div class=\"alert alert-success\">\r\n                    <button type=\"button\" class=\"close\" data-dismiss=\"alert\">\r\n                      <span aria-hidden=\"true\">×</span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>";
    $sql = $DB->query('DELETE FROM auth_daili WHERE user=\'' . $user . '\'');
    if ($sql) {
        echo '删除代理' . $user . '成功！';
    } else {
        echo '删除失败！';
    }
    echo '</div>';
} elseif ($my == 'empty') {
    $user = daddslashes($_GET['user']);
    $sql = $DB->query('update `auth_daili` set `tj_rmb`=\'0.00\' where `user`=\'' . $user . '\'');
    if ($sql) {
        echo "<div class=\"alert alert-success\">\r\n                                        <button type=\"button\" class=\"close\" data-dismiss=\"alert\">\r\n                                            <span aria-hidden=\"true\">×</span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>\r\n                                    清空" . $user . '推荐余额成功！</div>';
    } else {
        echo '<div class="alert alert-danger">清空失败！</div>';
    }
    echo '';
} elseif ($my == 'qkkm') {
    $sql = $DB->query('DELETE FROM auth_kms WHERE daili=\'' . $_GET['id'] . '\'');
    if ($sql) {
        echo "<div class=\"alert alert-success\">\r\n                                        <button type=\"button\" class=\"close\" data-dismiss=\"alert\">\r\n                                            <span aria-hidden=\"true\">×</span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>\r\n                                    清空代理id:  " . $_GET['id'] . '下所生成卡密成功！</div>';
    } else {
        echo '<div class="alert alert-danger">清空失败！</div>';
    }
} elseif ($my == 'qkyh') {
    $sql = $DB->query('DELETE FROM openvpn WHERE dlid=\'' . $_GET['id'] . '\'');
    if ($sql) {
        echo "<div class=\"alert alert-success\">\r\n                                        <button type=\"button\" class=\"close\" data-dismiss=\"alert\">\r\n                                            <span aria-hidden=\"true\">×</span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>\r\n                                    清空代理id:  " . $_GET['id'] . '下所生成用户成功！</div>';
    } else {
        echo '<div class="alert alert-danger">清空失败！</div>';
    }
}
echo '            ';
if (isset($_GET['sdl'])) {
    $sdl = daddslashes($_GET['sdl']);
    $dl = '1';
    if ($_GET['type'] == 1) {
        $sdl = daddslashes($_GET['sdl']);
        $sql = ' `user`=\'' . $sdl . '\'';
        $numrows = $DB->count('SELECT count(*) from `auth_daili` WHERE' . $sql);
        $con = '包含 ' . $_GET['sdl'] . ' 的共有 ' . $numrows . ' 个信息';
    } elseif ($_GET['type'] == 2) {
        $kw = daddslashes($_GET['kw']);
        $sql = ' `vip`=\'' . $kw . '\'';
        $numrows = $DB->count('SELECT count(*) from `auth_daili` WHERE' . $sql);
        $con = '包含 ' . $_GET['kw'] . ' 的共有 ' . $numrows . ' 个信息';
    }
} else {
    $numrows = $DB->count('SELECT count(*) from `auth_daili` WHERE 1');
    $sql = ' 1';
    $con = '平台共有 ' . $numrows . ' 个代理信息';
}
echo "<div class=\"row\">\r\n    <div class=\"col-md-12\">\r\n    <div class=\"alert alert-info\">提示：默认代理ID必须是0，请勿修改删除！\r\n</div>\r\n        <div class=\"panel panel-default\">\r\n            <div class=\"panel-heading\">";
echo $con;
echo "                <div class=\"panel-ctrls\"><form action=\"daili.php\">\r\n                <label class=\"panel-ctrls-center\"> <input type=\"text\" class=\"form-control\" size=\"10\" name=\"sdl\" placeholder=\"搜索\"></label>\r\n                 </form></div>\r\n            </div>\r\n            \r\n                 <div class=\"panel-body panel-no-padding\"><div class=\"table-responsive\">\r\n\t\t\t\t<table class=\"table table-bordered table-fixed-header m0\">    \r\n                    <thead>\r\n                        <tr>\r\n                            <th>ID</th>\r\n                                          <th>用户名</th>\r\n                                          <th>密码</th>\r\n                                          <th>状态</th>\r\n                                          <th>等级</th>\r\n                                          <th>余额</th>\r\n                                          <th>收入</th>\r\n                                          <th>推荐人</th>\r\n                                          <th>推荐余额</th>\r\n                                          <th>姓名</th>\r\n                                          <th>QQ</th>\r\n                                          <th>电话</th>\r\n                                          <th>操作</th>\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n                     ";
$pagesize = 15;
$pages = intval($numrows / $pagesize);
if ($numrows % $pagesize) {
    ($pages += 1) + -1;
}
if (isset($_GET['page'])) {
    $page = intval($_GET['page']);
} else {
    $page = 1;
}
$offset = $pagesize * ($page - 1);
if ($dl == '1') {
    $rs = $DB->query('SELECT * FROM auth_daili  where user=\'' . $sdl . '\' limit ' . $offset . ',' . $pagesize);
} else {
    $rs = $DB->query('SELECT * FROM auth_daili   limit ' . $offset . ',' . $pagesize);
}
while (true) {
    $res = $DB->fetch($rs);
    if (!$DB->fetch($rs)) {
        echo "                                      </tbody>\r\n                                  </table>\r\n                      \r\n                       </div>\r\n                      <div class=\"panel-footer\">\r\n                      <div class=\"row\">\r\n                      <div class=\"col-sm-6\">\r\n                   \r\n                      </div>\r\n                      <div class=\"col-sm-6\">\r\n                      <div class=\"dataTables_paginate paging_bootstrap\" id=\"example_paginate\">\r\n                       ";
        echo '<ul class="pagination pull-right m0">';
        $first = 1;
        $prev = $page - 1;
        $next = $page + 1;
        $last = $pages;
        if ($page > 1) {
            echo '<li class="previous disabled"><a href="daili.php?page=' . $first . $link . '">首页</a></li>';
        } else {
            echo '<li class="previous disabled"><a>首页</a></li>';
        }
        $i = 1;
        while (true) {
            if ($i >= $page) {
                echo '<li  class="active"><a>' . $page . '</a></li>';
                $i = $page + 1;
                while (true) {
                    if ($i > $pages) {
                        echo '';
                        if (!($page >= $pages)) {
                            echo '<li class="next disabled"><a href="daili.php?page=' . $last . $link . '">尾页</a></li>';
                        } else {
                            echo '<li class="next disabled"><a>尾页</a></li>';
                        }
                        echo '</ul>';
                        echo "                      </div>\r\n                      </div>\r\n                      </div>\r\n                      </div>\r\n\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n\r\n                            </div> <!-- .container-fluid -->\r\n                        </div> <!-- #page-content -->\r\n                    </div>\r\n";
                        include 'copy.php';
                        return null;
                    }
                    echo '<li><a href="daili.php?page=' . $i . $link . '">' . $i . '</a></li>';
                    ($i += 1) + -1;
                }
            }
            echo '<li class="active"><a href="daili.php?page=' . $i . $link . '">' . $i . '</a></li>';
            ($i += 1) + -1;
        }
    }
    $dengji = $res['vip'];
    if ($dengji == 0) {
        $dj = '普通代理';
    } elseif ($dengji == 1) {
        $dj = '铜牌代理';
    } elseif ($dengji == 2) {
        $dj = '银牌代理';
    } elseif ($dengji == 3) {
        $dj = '金牌代理';
    } elseif ($dengji == 4) {
        $dj = '钻石代理';
    } elseif ($dengji == 5) {
        $dj = '至尊代理';
    }
    if ($res['active'] == 0) {
        $isactive = '<span class="badge badge-warning">未激活</span>';
    } elseif ($res['active'] == 1) {
        $isactive = '<span class="badge badge-info">已激活</span>';
    }
    if ($res['id'] == 0) {
        $del = '<button class="btn btn-xs btn-gray disabled">不可删除</button>';
    } else {
        $del = '<a href="./daili.php?my=del&user=' . $res['user'] . '" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要进行操作吗？\');">删除</a>';
    }
    echo '<tr><th><span class="co-name">' . $res['id'] . '</span></th><td>' . $res['user'] . '</td><td>' . $res['pass'] . '</td><td>' . $isactive . '</td><td>' . $dj . '</td><td>' . $res['rmb'] . '</td><td><p class="text-danger">' . $res['income'] . '</p></td><!-- JXL_add for 2016-04-16 begin --><td>' . $res['tj_user'] . '</td><td>' . $res['tj_rmb'] . '</td><td>' . $res['name'] . '</td><td>' . $res['qq'] . '</td><td>' . $res['tel'] . '</td><!-- JXL_add for 2016-04-16 end --><td>' . ($res['active'] == 1 ? '<a href="./daili.php?my=black1&user=' . $res['user'] . '" class="btn btn-xs btn-primary" onclick="return confirm(\'你确实要更改状态吗？\');">取消激活</a>' : '<a href="./daili.php?my=black0&user=' . $res['user'] . '" class="btn btn-xs btn-success" onclick="return confirm(\'你确实要将此代理激活吗？\');">激活</a>') . '<a href="./daili.php?my=black2&user=' . $res['user'] . '" class="btn btn-xs btn-info">充值</a><a href="./daili.php?my=black3&user=' . $res['user'] . '" class="btn btn-xs btn-purple">配置</a><a href="./daili.php?my=vip&user=' . $res['user'] . '" class="btn btn-xs btn-success">等级</a><a href="./daili.php?my=qkkm&id=' . $res['id'] . '" class="btn btn-xs btn-warning">清空卡密</a><a href="./daili.php?my=qkyh&id=' . $res['id'] . '" class="btn btn-xs btn-info">清空用户</a><!-- JXL_add for 2016-04-16 begin --><a href="./daili.php?my=empty&user=' . $res['user'] . '" class="btn btn-xs btn-orange" onclick="return confirm(\'你确实要进行操作吗？\');">清空推荐余额</a><!-- JXL_add for 2016-04-16 end -->' . $del . '</td></tr>';
}