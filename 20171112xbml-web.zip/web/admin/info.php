<?php /* by:凌一 QQ:863963860*/

if (!($islogin2 == 1)) {
    exit('<script language=\'javascript\'>window.location.href=\'./login.php\';</script>');
}
error_reporting(0);
@header('content-Type: text/html; charset=utf-8');
ob_start();
$mysqlversion = $DB->count('select VERSION()');
define('HTTP_HOST', preg_replace('~^www\\.~i', '', $_SERVER['HTTP_HOST']));
if (PHP_OS == 'Linux') {
    $sysInfo = sys_linux();
    $sysReShow = false !== sys_linux() ? 'show' : 'none';
} elseif (PHP_OS == 'FreeBSD') {
    $sysInfo = sys_freebsd();
    $sysReShow = false !== sys_freebsd() ? 'show' : 'none';
} elseif (PHP_OS == 'WINNT') {
    $sysInfo = sys_windows();
    $sysReShow = false !== sys_windows() ? 'show' : 'none';
}
$uptime = $sysInfo['uptime'];
$stime = date('Y-n-j H:i:s');
$df = round(@disk_free_space('.') / (1024 * 1024 * 1024), 3);
$dt = round(@disk_total_space('.') / (1024 * 1024 * 1024), 3);
if (!($sysInfo['memTotal'] >= 1024)) {
    $memTotal = $sysInfo['memTotal'] . ' M';
    $mt = $sysInfo['memTotal'] . ' M';
    $mu = $sysInfo['memUsed'] . ' M';
    $mf = $sysInfo['memFree'] . ' M';
    $mc = $sysInfo['memCached'] . ' M';
    $mb = $sysInfo['memBuffers'] . ' M';
    $st = $sysInfo['swapTotal'] . ' M';
    $su = $sysInfo['swapUsed'] . ' M';
    $sf = $sysInfo['swapFree'] . ' M';
    $swapPercent = $sysInfo['swapPercent'];
    $memRealUsed = $sysInfo['memRealUsed'] . ' M';
    $memRealFree = $sysInfo['memRealFree'] . ' M';
    $memRealPercent = $sysInfo['memRealPercent'];
    $memPercent = $sysInfo['memPercent'];
    $memCachedPercent = $sysInfo['memCachedPercent'];
} else {
    $memTotal = round($sysInfo['memTotal'] / 1024, 3) . ' G';
    $mt = round($sysInfo['memTotal'] / 1024, 3) . ' G';
    $mu = round($sysInfo['memUsed'] / 1024, 3) . ' G';
    $mf = round($sysInfo['memFree'] / 1024, 3) . ' G';
    $mc = round($sysInfo['memCached'] / 1024, 3) . ' G';
    $mb = round($sysInfo['memBuffers'] / 1024, 3) . ' G';
    $st = round($sysInfo['swapTotal'] / 1024, 3) . ' G';
    $su = round($sysInfo['swapUsed'] / 1024, 3) . ' G';
    $sf = round($sysInfo['swapFree'] / 1024, 3) . ' G';
    $swapPercent = $sysInfo['swapPercent'];
    $memRealUsed = round($sysInfo['memRealUsed'] / 1024, 3) . ' G';
    $memRealFree = round($sysInfo['memRealFree'] / 1024, 3) . ' G';
    $memRealPercent = $sysInfo['memRealPercent'];
    $memPercent = $sysInfo['memPercent'];
    $memCachedPercent = $sysInfo['memCachedPercent'];
}
echo "<div id=\"page\">\r\n    \r\n <table class=\"table\">\r\n  <tr><td>PHP版本：";
echo phpversion();
echo "</td> </tr>\r\n <tr><td>MySQL版本：";
echo $mysqlversion;
echo "</td> </tr>\r\n <tr><td>POST许可：";
echo ini_get('post_max_size');
echo "</td> </tr>\r\n <tr><td>服务器软件：";
echo $_SERVER['SERVER_SOFTWARE'];
echo "</td> </tr>\r\n <tr><td>文件上传许可：";
echo ini_get('upload_max_filesize');
echo "</td> </tr>\r\n <tr><td>程序最大运行时间：";
echo ini_get('max_execution_time');
echo "s</td> </tr>\r\n  <tr>\r\n    <td>当前IP地址: ";
echo $_SERVER['SERVER_ADDR'];
echo "</td>\r\n  </tr>\r\n  <tr>\r\n    <td>操作系统: ";
$os = explode(' ', php_uname());
echo $os[0];
echo "</td>\r\n  </tr>\r\n  <tr>\r\n    <td>Web引擎: ";
echo $_SERVER['SERVER_SOFTWARE'];
echo "</td>\r\n  </tr>\r\n  <tr>\r\n    <td>Web端口: ";
echo $_SERVER['SERVER_PORT'];
echo "</td>\r\n  </tr>\r\n  <tr>\r\n    <td>当前时间: ";
echo $stime;
echo "</td>\r\n  </tr>\r\n  <tr>\r\n    <td>已运行时间: ";
echo $uptime;
echo "</td>\r\n  </tr>\r\n  <tr>\r\n    <td>系统负载: ";
echo $sysInfo['loadAvg'];
echo "</td>\r\n  </tr>\r\n  <tr>\r\n    <td>总空间: ";
echo $dt;
echo "&nbsp;G</td>\r\n  </tr>\r\n  <tr>\r\n    <td>可用空间: ";
echo $df;
echo "&nbsp;G</td>\r\n  </tr>\r\n  <tr>\r\n    <td class=\"word\">CPU型号[";
echo $sysInfo['cpu']['num'];
echo '核]: ';
echo $sysInfo['cpu']['model'];
echo "</td>\r\n  </tr>\r\n  <tr>\r\n    <td>物理内存: ";
echo $memTotal;
echo "</td>\r\n  </tr>\r\n  <tr>\r\n    <td>已用内存: ";
echo $mu;
echo "</td>\r\n  </tr>\r\n  <tr>\r\n    <td>空闲内存: ";
echo $mf;
echo "</td>\r\n  </tr>\r\n";
if ($sysInfo['memCached'] > 0) {
    echo "  <tr>\r\n    <td>cache内存: ";
    echo $mc;
    echo "</td>\r\n  </tr>\r\n";
}
if ($sysInfo['swapTotal'] > 0) {
    echo "\t\r\n  <tr>\r\n    <td>SWAP分区: ";
    echo $st;
    echo "</td>\r\n  </tr>\r\n  <tr>\r\n    <td>SWAP已用: ";
    echo $su;
    echo "</td>\r\n  </tr>\r\n  <tr>\r\n    <td>SWAP空闲: ";
    echo $sf;
    echo "</td>\r\n  </tr>\r\n";
}
$strs = @file('/proc/net/dev');
if (false !== @file('/proc/net/dev')) {
    $i = 2;
    while (!($i >= count($strs))) {
        preg_match_all('/([^\\s]+):[\\s]{0,}(\\d+)\\s+(\\d+)\\s+(\\d+)\\s+(\\d+)\\s+(\\d+)\\s+(\\d+)\\s+(\\d+)\\s+(\\d+)\\s+(\\d+)\\s+(\\d+)\\s+(\\d+)/', $strs[$i], $info);
        if ($info[2][0] > 0) {
            echo "  <tr>\r\n    <td>当前服务器流量-";
            echo $info[1][0];
            echo "\t\t<br />已接收: ";
            $tmp = round($info[2][0] / 1024 / 1024, 3);
            $tmp2 = round($tmp / 1024, 3);
            echo $tmp2;
            echo " G\r\n\t\t<br />已发送: ";
            $tmp = round($info[10][0] / 1024 / 1024, 3);
            $tmp2 = round($tmp / 1024, 3);
            echo $tmp2;
            echo " G\r\n\t</td>\r\n  </tr>\r\n";
        }
        ($i += 1) + -1;
    }
}
echo "</table>\r\n</div>\r\n</body>\r\n</html>";
function sys_linux()
{
    $str = @file('/proc/cpuinfo');
    if (false === @file('/proc/cpuinfo')) {
        return false;
    }
    $str = implode('', $str);
    @preg_match_all("/model\\s+name\\s{0,}\\:+\\s{0,}([\\w\\s\\)\\(\\@.-]+)([\r\n]+)/s", $str, $model);
    @preg_match_all("/cpu\\s+MHz\\s{0,}\\:+\\s{0,}([\\d\\.]+)[\r\n]+/", $str, $mhz);
    @preg_match_all("/cache\\s+size\\s{0,}\\:+\\s{0,}([\\d\\.]+\\s{0,}[A-Z]+[\r\n]+)/", $str, $cache);
    @preg_match_all("/bogomips\\s{0,}\\:+\\s{0,}([\\d\\.]+)[\r\n]+/", $str, $bogomips);
    if (false !== is_array($model[1])) {
        $res['cpu']['num'] = sizeof($model[1]);
        if ($res['cpu']['num'] == 1) {
            $x1 = '';
        } else {
            $x1 = ' ×' . $res['cpu']['num'];
        }
        $mhz[1][0] = ' | 频率:' . $mhz[1][0];
        $cache[1][0] = ' | 二级缓存:' . $cache[1][0];
        $bogomips[1][0] = ' | Bogomips:' . $bogomips[1][0];
        $res['cpu']['model'][] = $model[1][0] . $mhz[1][0] . $cache[1][0] . $bogomips[1][0] . $x1;
        if (false !== is_array($res['cpu']['model'])) {
            $res['cpu']['model'] = implode('<br />', $res['cpu']['model']);
        }
        if (false !== is_array($res['cpu']['mhz'])) {
            $res['cpu']['mhz'] = implode('<br />', $res['cpu']['mhz']);
        }
        if (false !== is_array($res['cpu']['cache'])) {
            $res['cpu']['cache'] = implode('<br />', $res['cpu']['cache']);
        }
        if (false !== is_array($res['cpu']['bogomips'])) {
            $res['cpu']['bogomips'] = implode('<br />', $res['cpu']['bogomips']);
        }
    }
    $str = @file('/proc/uptime');
    if (false === @file('/proc/uptime')) {
        return false;
    }
    $str = explode(' ', implode('', $str));
    $str = trim($str[0]);
    $min = $str / 60;
    $hours = $min / 60;
    $days = floor($hours / 24);
    $hours = floor($hours - $days * 24);
    $min = floor($min - $days * 60 * 24 - $hours * 60);
    if ($days !== 0) {
        $res['uptime'] = $days . '天';
    }
    if ($hours !== 0) {
        $res['uptime'] = $res['uptime'] . ($hours . '小时');
    }
    $res['uptime'] = $res['uptime'] . ($min . '分钟');
    $str = @file('/proc/meminfo');
    if (false === @file('/proc/meminfo')) {
        return false;
    }
    $str = implode('', $str);
    preg_match_all('/MemTotal\\s{0,}\\:+\\s{0,}([\\d\\.]+).+?MemFree\\s{0,}\\:+\\s{0,}([\\d\\.]+).+?Cached\\s{0,}\\:+\\s{0,}([\\d\\.]+).+?SwapTotal\\s{0,}\\:+\\s{0,}([\\d\\.]+).+?SwapFree\\s{0,}\\:+\\s{0,}([\\d\\.]+)/s', $str, $buf);
    preg_match_all('/Buffers\\s{0,}\\:+\\s{0,}([\\d\\.]+)/s', $str, $buffers);
    $res['memTotal'] = round($buf[1][0] / 1024, 2);
    $res['memFree'] = round($buf[2][0] / 1024, 2);
    $res['memBuffers'] = round($buffers[1][0] / 1024, 2);
    $res['memCached'] = round($buf[3][0] / 1024, 2);
    $res['memUsed'] = $res['memTotal'] - $res['memFree'];
    $res['memPercent'] = floatval($res['memTotal']) != 0 ? round($res['memUsed'] / $res['memTotal'] * 100, 2) : 0;
    $res['memRealUsed'] = $res['memTotal'] - $res['memFree'] - $res['memCached'] - $res['memBuffers'];
    $res['memRealFree'] = $res['memTotal'] - $res['memRealUsed'];
    $res['memRealPercent'] = floatval($res['memTotal']) != 0 ? round($res['memRealUsed'] / $res['memTotal'] * 100, 2) : 0;
    $res['memCachedPercent'] = floatval($res['memCached']) != 0 ? round($res['memCached'] / $res['memTotal'] * 100, 2) : 0;
    $res['swapTotal'] = round($buf[4][0] / 1024, 2);
    $res['swapFree'] = round($buf[5][0] / 1024, 2);
    $res['swapUsed'] = round($res['swapTotal'] - $res['swapFree'], 2);
    $res['swapPercent'] = floatval($res['swapTotal']) != 0 ? round($res['swapUsed'] / $res['swapTotal'] * 100, 2) : 0;
    $str = @file('/proc/loadavg');
    if (false === @file('/proc/loadavg')) {
        return false;
    }
    $str = explode(' ', implode('', $str));
    $str = array_chunk($str, 4);
    $res['loadAvg'] = implode(' ', $str[0]);
    return $res;
}
function sys_freebsd()
{
    $res['cpu']['num'] = get_key('hw.ncpu');
    if (false === get_key('hw.ncpu')) {
        return false;
    }
    $res['cpu']['model'] = get_key('hw.model');
    $res['loadAvg'] = get_key('vm.loadavg');
    if (false === get_key('vm.loadavg')) {
        return false;
    }
    $buf = get_key('kern.boottime');
    if (false === get_key('kern.boottime')) {
        return false;
    }
    $buf = explode(' ', $buf);
    $sys_ticks = time() - intval($buf[3]);
    $min = $sys_ticks / 60;
    $hours = $min / 60;
    $days = floor($hours / 24);
    $hours = floor($hours - $days * 24);
    $min = floor($min - $days * 60 * 24 - $hours * 60);
    if ($days !== 0) {
        $res['uptime'] = $days . '天';
    }
    if ($hours !== 0) {
        $res['uptime'] = $res['uptime'] . ($hours . '小时');
    }
    $res['uptime'] = $res['uptime'] . ($min . '分钟');
    $buf = get_key('hw.physmem');
    if (false === get_key('hw.physmem')) {
        return false;
    }
    $res['memTotal'] = round($buf / 1024 / 1024, 2);
    $str = get_key('vm.vmtotal');
    preg_match_all("/\nVirtual Memory[\\:\\s]*\\(Total[\\:\\s]*([\\d]+)K[\\,\\s]*Active[\\:\\s]*([\\d]+)K\\)\n/i", $str, $buff, PREG_SET_ORDER);
    preg_match_all("/\nReal Memory[\\:\\s]*\\(Total[\\:\\s]*([\\d]+)K[\\,\\s]*Active[\\:\\s]*([\\d]+)K\\)\n/i", $str, $buf, PREG_SET_ORDER);
    $res['memRealUsed'] = round($buf[0][2] / 1024, 2);
    $res['memCached'] = round($buff[0][2] / 1024, 2);
    $res['memUsed'] = round($buf[0][1] / 1024, 2) + $res['memCached'];
    $res['memFree'] = $res['memTotal'] - $res['memUsed'];
    $res['memPercent'] = floatval($res['memTotal']) != 0 ? round($res['memUsed'] / $res['memTotal'] * 100, 2) : 0;
    $res['memRealPercent'] = floatval($res['memTotal']) != 0 ? round($res['memRealUsed'] / $res['memTotal'] * 100, 2) : 0;
    return $res;
}
function get_key($keyName)
{
    return do_command('sysctl', '-n ' . $keyName);
}
function find_command($commandName)
{
    $path = array('/bin', '/sbin', '/usr/bin', '/usr/sbin', '/usr/local/bin', '/usr/local/sbin');
    foreach ($path as $p) {
        if (@is_executable($p . '/' . $commandName)) {
            return $p . '/' . $commandName;
        }
    }
    return false;
}
function do_command($commandName, $args)
{
    $buffer = '';
    $command = find_command($commandName);
    if (false === find_command($commandName)) {
        return false;
    }
    $fp = @popen($command . ' ' . $args, 'r');
    if (!@popen($command . ' ' . $args, 'r')) {
        return false;
    }
    while (true) {
        if (@feof($fp)) {
            return trim($buffer);
        }
        $buffer .= @fgets($fp, 4096);
    }
}
function sys_windows()
{
    if (!(PHP_VERSION >= 5)) {
        return false;
    }
    $objLocator = 'COM';
    $wmi = $objLocator->ConnectServer();
    $prop = $wmi->get('Win32_PnPEntity');
    $cpuinfo = GetWMI($wmi, 'Win32_Processor', array('Name', 'L2CacheSize', 'NumberOfCores'));
    $res['cpu']['num'] = $cpuinfo[0]['NumberOfCores'];
    if (null == $res['cpu']['num']) {
        $res['cpu']['num'] = 1;
    }
    $cpuinfo[0]['L2CacheSize'] = ' (' . $cpuinfo[0]['L2CacheSize'] . ')';
    if ($res['cpu']['num'] == 1) {
        $x1 = '';
    } else {
        $x1 = '×' . $res['cpu']['num'];
    }
    $res['cpu']['model'] = $cpuinfo[0]['Name'] . $cpuinfo[0]['L2CacheSize'] . $x1;
    $sysinfo = GetWMI($wmi, 'Win32_OperatingSystem', array('LastBootUpTime', 'TotalVisibleMemorySize', 'FreePhysicalMemory', 'Caption', 'CSDVersion', 'SerialNumber', 'InstallDate'));
    $sysinfo[0]['Caption'] = iconv('GBK', 'UTF-8', $sysinfo[0]['Caption']);
    $sysinfo[0]['CSDVersion'] = iconv('GBK', 'UTF-8', $sysinfo[0]['CSDVersion']);
    $res['win_n'] = $sysinfo[0]['Caption'] . ' ' . $sysinfo[0]['CSDVersion'] . (' 序列号:' . $sysinfo[0]['SerialNumber'] . ' 于') . date('Y年m月d日H:i:s', strtotime(substr($sysinfo[0]['InstallDate'], 0, 14))) . '安装';
    $res['uptime'] = $sysinfo[0]['LastBootUpTime'];
    $sys_ticks = 3600 * 8 + time() - strtotime(substr($res['uptime'], 0, 14));
    $min = $sys_ticks / 60;
    $hours = $min / 60;
    $days = floor($hours / 24);
    $hours = floor($hours - $days * 24);
    $min = floor($min - $days * 60 * 24 - $hours * 60);
    if ($days !== 0) {
        $res['uptime'] = $days . '天';
    }
    if ($hours !== 0) {
        $res['uptime'] = $res['uptime'] . ($hours . '小时');
    }
    $res['uptime'] = $res['uptime'] . ($min . '分钟');
    $res['memTotal'] = round($sysinfo[0]['TotalVisibleMemorySize'] / 1024, 2);
    $res['memFree'] = round($sysinfo[0]['FreePhysicalMemory'] / 1024, 2);
    $res['memUsed'] = $res['memTotal'] - $res['memFree'];
    $res['memPercent'] = round($res['memUsed'] / $res['memTotal'] * 100, 2);
    $swapinfo = GetWMI($wmi, 'Win32_PageFileUsage', array('AllocatedBaseSize', 'CurrentUsage'));
    $loadinfo = GetWMI($wmi, 'Win32_Processor', array('LoadPercentage'));
    $res['loadAvg'] = $loadinfo[0]['LoadPercentage'];
    return $res;
}
function GetWMI($wmi, $strClass, $strValue = array())
{
    $arrData = array();
    $objWEBM = $wmi->Get($strClass);
    $arrProp = $objWEBM->Properties_;
    $arrWEBMCol = $objWEBM->Instances_();
    foreach ($arrWEBMCol as $objItem) {
        @reset($arrProp);
        $arrInstance = array();
        foreach ($arrProp as $propItem) {
            '$value = $objItem->' . $propItem->Name . ';';
            if (empty($strValue)) {
                $arrInstance[$propItem->Name] = trim($value);
            } elseif (in_array($propItem->Name, $strValue)) {
                $arrInstance[$propItem->Name] = trim($value);
            }
        }
        $arrData[] = $arrInstance;
    }
    return $arrData;
}