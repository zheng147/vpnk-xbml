<?php /* by:凌一 QQ:863963860*/

if (!($islogin2 == 1)) {
    exit('<script language=\'javascript\'>window.location.href=\'./login.php\';</script>');
}
$myfile = fopen('/home/jiankong.log', 'r');
if (!(bool) fopen('/home/jiankong.log', 'r')) {
    exit('错误!');
}
echo fread($myfile, filesize('/home/jiankong.log'));
fclose($myfile);