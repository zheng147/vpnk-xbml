<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>账号配置</h1>\r\n                                <div class=\"options\">\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n";
$user = daddslashes($_GET['user']);
echo "            <div class=\"row\">\r\n                <div class=\"col-sm-12\">\r\n                  <div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">进行账号 ";
echo $user;
echo " 的配置\r\n                    </div>\r\n                    <div class=\"panel-body\">\r\n";
if (!(bool) (!$user)) {
    $row = $DB->get_row('select * from `openvpn` where iuser=\'' . $user . '\' limit 1');
}
if ((bool) (!$user)) {
    exit('账号不存在!');
}
if ($_POST['type'] == 'update') {
    echo '<div class="alert ';
    $notes = daddslashes($_POST['notes']);
    $fwqid = daddslashes($_POST['fwqid']);
    $pass = daddslashes($_POST['pass']);
    $maxll = daddslashes($_POST['maxll']) * 1024 * 1024;
    $state = daddslashes($_POST['state']);
    $endtime = strtotime($_POST['enddate']);
    $dlid = daddslashes($_POST['dlid']);
    if ($DB->query('update `openvpn` set `pass`=\'' . $pass . '\',`maxll`=\'' . $maxll . '\',`i`=\'' . $state . '\',`endtime`=\'' . $endtime . '\',`dlid`=\'' . $dlid . '\',`fwqid`=\'' . $fwqid . '\',`notes`=\'' . $notes . '\' where iuser=\'' . $user . '\'')) {
        echo "alert-success\">\r\n                    <button type=\"button\" class=\"close\">\r\n                      <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>\r\n                  修改成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=qqlist.php\">";
    } else {
        echo "alert-danger\">\r\n                    <button type=\"button\" class=\"close\">\r\n                      <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>\r\n                  修改失败！" . $DB->error();
    }
    echo '</div>';
    echo '<style>#qset{display: none;}</style>';
}
$fwqlist = $DB->query('SELECT * FROM auth_fwq');
$dllist = $DB->query('SELECT * FROM auth_daili');
echo "      \r\n                <form id=\"qset\" action=\"./qset.php?user=";
echo $user;
echo "\" method=\"post\" role=\"form\" class=\"form-horizontal\">\r\n                <input type=\"hidden\" name=\"type\" value=\"update\" />\r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\">帐号密码</label>\r\n                    <div class=\"col-sm-9\">\r\n                      <input type=\"text\" class=\"form-control\" id=\"field-1\" placeholder=\"请输入密码\" name=\"pass\" value=\"";
echo $row['pass'];
echo "\">\r\n                    </div>\r\n                  </div>  \r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\">是否开通</label>\r\n                    <div class=\"col-sm-9\">\r\n                ";
if ($row['i'] == 1) {
    echo "\r\n                        <label class=\"radio-inline\">\r\n                          <input type=\"radio\" name=\"state\" checked=\"\" value=\"1\">\r\n                          开通\r\n                        </label>\r\n                        <label class=\"radio-inline\">\r\n                          <input type=\"radio\" name=\"state\" value=\"0\">\r\n                          禁用\r\n                        </label>\r\n                  ";
} else {
    echo "\r\n                        <label class=\"radio-inline\">\r\n                          <input type=\"radio\" name=\"state\" value=\"1\">\r\n                          开通\r\n                        </label>\r\n                        <label class=\"radio-inline\">\r\n                          <input type=\"radio\" name=\"state\" checked=\"\" value=\"0\">\r\n                          禁用\r\n                        </label>\r\n                  ";
}
echo "                    </div>\r\n                  </div>  \r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\">开通流量</label>\r\n                    <div class=\"col-sm-9\">\r\n                      <div class=\"input-group\">\r\n                        <input type=\"text\" class=\"form-control\" name=\"maxll\" value=\"";
echo round($row['maxll'] / 1024 / 1024);
echo "\">\r\n                        <span class=\"input-group-addon\">MB</span> \r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\">到期日期</label>\r\n                    \r\n                    <div class=\"col-sm-9\">\r\n                      <div class=\"input-group\">\r\n                      <input type=\"date\" class=\"form-control\" data-format=\"yyyy/mm/dd \" name=\"enddate\" data-validate=\"required,date\" value=\"";
echo date('Y/m/d', $row['endtime']);
echo "\">\r\n                        <div class=\"input-group-addon\">\r\n                          <a href=\"#\"><i class=\"linecons-calendar\"></i></a>\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n              <!-- <div class=\"input-group\">\r\n              <span class=\"input-group-addon\">使用天数</span>\r\n              <input type=\"text\" name=\"tian\" value=\"\" class=\"form-control\"  autocomplete=\"off\" required>\r\n              </div><br/> -->\r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\">选择代理</label>\r\n                    <div class=\"col-sm-9\">\r\n                      <select class=\"form-control\" name=\"dlid\">\r\n                      ";
while (true) {
    $d = $DB->fetch($dllist);
    if (!$DB->fetch($dllist)) {
        echo "                      </select>\r\n                    </div>\r\n                      \r\n                  </div>\r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\">选择服务器</label>\r\n                    <div class=\"col-sm-9\">\r\n                      <select class=\"form-control\" name=\"fwqid\">\r\n                      ";
        while (true) {
            $v = $DB->fetch($fwqlist);
            if (!$DB->fetch($fwqlist)) {
                echo "                      </select>\r\n                    </div>\r\n                      \r\n                  </div>\r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\">账户备注</label>\r\n                    <div class=\"col-sm-9\">\r\n                      <input type=\"text\" class=\"form-control\" id=\"field-1\" placeholder=\"请输入备注\" name=\"notes\" value=\"";
                echo $row['notes'];
                echo "\">\r\n                    </div>\r\n                  </div>  \r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\"></label>\r\n                    <div class=\"col-sm-9\">\r\n                      <button type=\"submit\" type=\"button\" class=\"btn btn-info btn-block\">修改</button>\r\n                    </div>\r\n                  </div>\r\n                  \r\n                </form>\r\n                      \r\n                    </div>\r\n                  \r\n                  </div>\r\n                    \r\n                </div>\r\n            </div>\r\n   \r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n";
                include 'copy.php';
                return null;
            }
            echo '                        <option value="';
            echo $v['id'];
            echo '">';
            echo $v['name'];
            echo "</option>\r\n                      ";
        }
    }
    echo '                        <option value="';
    echo $d['id'];
    echo '"  ';
    if ($d['id'] == $row['dlid']) {
        echo 'selected="selected"';
    }
    echo '>用户名：';
    echo $d['user'];
    echo '；姓名：';
    echo $d['name'];
    echo "</option>\r\n                      ";
}