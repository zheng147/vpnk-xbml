<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
$numrows = $DB->count('SELECT count(*) from `auth_fwq` WHERE 1');
if ($numrows == '0') {
    $fwq = '0';
    $fwqlist = '0%';
}
if ($numrows == '1') {
    $fwq = '10';
    $fwqlist = '10%';
}
if ($numrows == '2') {
    $fwq = '20';
    $fwqlist = '20%';
}
if ($numrows == '3') {
    $fwq = '30';
    $fwqlist = '30%';
}
if ($numrows == '4') {
    $fwq = '40';
    $fwqlist = '40%';
}
if ($numrows == '5') {
    $fwq = '50';
    $fwqlist = '50%';
}
if ($numrows == '6') {
    $fwq = '60';
    $fwqlist = '60%';
}
if ($numrows == '7') {
    $fwq = '70';
    $fwqlist = '70%';
}
if ($numrows == '8') {
    $fwq = '80';
    $fwqlist = '80%';
}
if ($numrows == '9') {
    $fwq = '90';
    $fwqlist = '90%';
}
if ($numrows >= '10') {
    $fwq = '100';
    $fwqlist = '100%;';
}
$dt = round(@disk_total_space('.') / (400 * 400 * 400), 3);
$df = round(@disk_free_space('.') / (400 * 400 * 400), 3);
$du = $dt - $df;
$hdPercent = floatval($dt) != 0 ? round($du / $dt * 100, 2) : 0;
$av = 0;
$str2 = shell_exec('more /proc/stat');
$pattern = '/(cpu[0-9]?)[\\s]+([0-9]+)[\\s]+([0-9]+)[\\s]+([0-9]+)[\\s]+([0-9]+)[\\s]+([0-9]+)[\\s]+([0-9]+)[\\s]+([0-9]+)/';
preg_match_all($pattern, $str2, $out);
$n = 0;
while (true) {
    if ($n >= count($out[1])) {
        $cpu = number_format($av / $n, 2);
        $str1 = shell_exec('more /proc/meminfo');
        $pattern1 = '/(.+):\\s*([0-9]+)/';
        preg_match_all($pattern1, $str1, $out1);
        $ncun = number_format(100 * ($out1[2][0] - $out1[2][1]) / $out1[2][0], 2);
        echo "                <div class=\"static-content-wrapper\">\n                    <div class=\"static-content\">\n                        <div class=\"page-content\">\n                            <div class=\"page-heading\">            \n                                <h1>平台首页</h1>\n                                <div class=\"options\">\n                           </div>\n                            </div>\n                            <div class=\"container-fluid\">\n                    <div id=\"panel-advancedoptions\">\n\t                    <div class=\"row\">\n\t\t                    <div class=\"col-md-3\">\n\t\t\t\t\t\t\t<a class=\"info-tiles tiles-grape has-footer\" href=\"qqlist.php\">\n\t\t\t\t\t\t\t    <div class=\"tiles-heading\">\n\t\t\t\t\t\t\t        <div class=\"pull-left\">注册用户</div>\n\t\t\t\t\t\t\t        <div class=\"pull-right\">\n\t\t\t\t\t\t\t        \t<div id=\"tileorders\" class=\"sparkline-block\"></div>\n\t\t\t\t\t\t\t        </div>\n\t\t\t\t\t\t\t    </div>\n\t\t\t\t\t\t\t    <div class=\"tiles-body\">\n\t\t\t\t\t\t\t        <div class=\"pull-left\"><i class=\"fa fa-group\"></i></div>\n\t\t\t\t\t\t\t        <div class=\"pull-right\">";
        echo $count;
        echo "</div>\n\t\t\t\t\t\t\t    </div>\n\t\t\t\t\t\t\t    <div class=\"tiles-footer\">\n\t\t\t\t\t\t\t    ";
        $lv = ($count - $count2) / $count * 10;
        echo "\t\t\t\t\t\t\t    \t<div class=\"pull-left\">";
        if (!($lv >= 0)) {
            echo '减少';
        } else {
            echo '增加';
        }
        echo "</div>\n\t\t\t\t\t\t\t    \t<div class=\"pull-right percent-change\">";
        echo round($lv);
        echo "%</div>\n\t\t\t\t\t\t\t    </div>\n\t\t\t\t\t\t\t</a>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<div class=\"col-md-3\">\n\t\t\t\t\t\t\t<a class=\"info-tiles tiles-info has-footer\" href=\"qqlist.php\">\n\t\t\t\t\t\t\t    <div class=\"tiles-heading\">\n\t\t\t\t\t\t\t        <div class=\"pull-left\">正常用户</div>\n\t\t\t\t\t\t\t        <div class=\"pull-right\">\n\t\t\t\t\t\t\t        \t<div id=\"tiletickets\" class=\"sparkline-block\"></div>\n\t\t\t\t\t\t\t        </div>\n\t\t\t\t\t\t\t    </div>\n\t\t\t\t\t\t\t    <div class=\"tiles-body\">\n\t\t\t\t\t\t\t    ";
        $lv2 = ($count2 - $count) / $count2 * 10;
        echo "\t\t\t\t\t\t\t        <div class=\"pull-left\"><i class=\"fa fa-shopping-cart\"></i></div>\n\t\t\t\t\t\t\t        <div class=\"pull-right\">";
        echo $count2;
        echo "</div>\n\t\t\t\t\t\t\t    </div>\n\t\t\t\t\t\t\t    <div class=\"tiles-footer\">\n\t\t\t\t\t\t\t    \t<div class=\"pull-left\">";
        if (!($lv2 >= 0)) {
            echo '减少';
        } else {
            echo '增加';
        }
        echo "</div>\n\t\t\t\t\t\t\t    \t<div class=\"pull-right percent-change\">";
        echo round($lv2);
        echo "%</div>\n\t\t\t\t\t\t\t    </div>\n\t\t\t\t\t\t\t</a>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<div class=\"col-md-3\">\n\t\t\t\t\t\t\t<a class=\"info-tiles tiles-alizarin has-footer\" href=\"online.php\">\n\t\t\t\t\t\t\t    <div class=\"tiles-heading\">\n\t\t\t\t\t\t\t        <div class=\"pull-left\">在线人数</div>\n\t\t\t\t\t\t\t        <div class=\"pull-right\">\n                    ";
        $str = file_get_contents('../udp/udp.txt', false, stream_context_create(array('http' => array('method' => 'GET', 'timeout' => 1))));
        $onlinenum_udp = (substr_count($str, date('Y')) - 1) / 2;
        $str = file_get_contents('../res/tcp.txt', false, stream_context_create(array('http' => array('method' => 'GET', 'timeout' => 1))));
        $onlinenum = (substr_count($str, date('Y')) - 1) / 2;
        echo "\t\t\t\t\t\t\t        \t<div id=\"tilerevenues\" class=\"sparkline-block\"></div>\n\t\t\t\t\t\t\t        </div>\n\t\t\t\t\t\t\t    </div>\n\t\t\t\t\t\t\t    <div class=\"tiles-body\">\n\t\t\t\t\t\t\t        <div class=\"pull-left\"><i class=\"fa fa-user\"></i></div>\n\t\t\t\t\t\t\t        <div class=\"pull-right\">";
        echo round($onlinenum_udp + $onlinenum);
        echo "</div>\n\t\t\t\t\t\t\t    </div>\n\t\t\t\t\t\t\t    <div class=\"tiles-footer\">\n\t\t\t\t\t\t\t    \t<div class=\"pull-left\">比例</div>\n\t\t\t\t\t\t\t    \t";
        $tj = round(($onlinenum_udp + $onlinenum) / $count2 * 100);
        echo "\t\t\t\t\t\t\t    \t<div class=\"pull-right percent-change\">";
        echo $tj;
        echo "%</div>\n\t\t\t\t\t\t\t    </div>\n\t\t\t\t\t\t\t</a>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<div class=\"col-md-3\">\n\t\t\t\t\t\t\t<a class=\"info-tiles tiles-midnightblue has-footer\" href=\"#\">\n\t\t\t\t\t\t\t    <div class=\"tiles-heading\">\n\t\t\t\t\t\t\t        <div class=\"pull-left\">当前时间</div>\n\t\t\t\t\t\t\t        <div class=\"pull-right\">\n\t\t\t\t\t\t\t        \t<div id=\"tilemembers\" class=\"sparkline-block\"></div>\n\t\t\t\t\t\t\t        </div>\n\t\t\t\t\t\t\t    </div>\n\t\t\t\t\t\t\t    <div class=\"tiles-body\">\n\t\t\t\t\t\t\t        <div class=\"pull-left\"><i class=\"fa fa-eye\"></i></div>\n\t\t\t\t\t\t\t        <div class=\"pull-right\">";
        echo date('H:i');
        echo "</div>\n\t\t\t\t\t\t\t    </div>\n\t\t\t\t\t\t\t    <div class=\"tiles-footer\">\n\t\t\t\t\t\t\t    \t<div class=\"pull-left\">今天</div>\n\t\t\t\t\t\t\t    \t<div class=\"pull-right percent-change\">";
        echo date('Y/m/d');
        echo "</div>\n\t\t\t\t\t\t\t    </div>\n\t\t\t\t\t\t\t</a>\n\t\t\t\t\t\t</div>\n              <div class=\"col-sm-6\">\n                    <div class=\"panel panel-default\">\n                                             <div class=\"panel-body\"> \n                                                <div class=\"m-b-15\">\n                                                    <h5>CPU利用率 <span class=\"pull-right\">";
        echo $cpu;
        echo "%</span></h5>\n                                                    <div class=\"progress progress-lg progress-striped active\">\n\t\t\t                        <div class=\"progress-bar progress-bar-success\" style=\"width: ";
        echo $cpu;
        echo "%\"></div>\n\t\t\t                    </div>\n                                                </div>\n                                                <div class=\"m-b-15\">\n                                                    <h5>内存利用率 <span class=\"pull-right\">";
        echo $hdPercent;
        echo "%</span></h5>\n                                                    <div class=\"progress progress-lg progress-striped active\">\n\t\t\t                        <div class=\"progress-bar progress-bar-info\" style=\"width: ";
        echo $hdPercent;
        echo "%\"></div>\n\t\t\t                    </div>\n                                                </div>\n                                                <div class=\"m-b-15\">\n                                                    <h5>服务器负载率 <span class=\"pull-right\">";
        echo $fwqlist;
        echo "</span></h5>\n                                                    <div class=\"progress progress-lg progress-striped active\">\n\t\t\t                        <div class=\"progress-bar progress-bar-inverse\" style=\"width: ";
        echo $fwq;
        echo "%\"></div>\n\t\t\t                    </div>\n                                                </div>\n                                            </div>\n                </div>\n            </div>\n\t\t\t\t\n\t\t\t\t<div class=\"col-lg-6\">       \n                 <div class=\"panel panel-primary\">\n\t\t\t\t<a data-toggle=\"collapse\" data-parent=\"#accordionA\" href=\"#collapseThree2\" class=\"collapsed\"><div class=\"panel-heading\"><h2>服务器信息</h2></div></a>\n\t\t\t\t<div id=\"collapseThree2\" class=\"collapse\" style=\"height: 0px;\">\n\t\t\t\t\t<div class=\"panel-body\">\n\t\t\t\t\t\t";
        include 'info.php';
        echo "\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</div></div>\n\n\t\t\t<div class=\"col-md-6 bs-grid\">\n                 <div class=\"row\">\n\t\t\t\t\t\t<div class=\"col-sm-4\">\n\t\t\t\t\t\t\t<a  class=\"info-tiles tiles-midnightblue\">\n\t\t            \t\t\t<div class=\"tiles-heading\">\n\t\t            \t\t\t\t代理数量比例\n\t\t            \t\t\t</div>\n\t\t            \t\t\t<div class=\"tiles-body\">\n\t\t            \t\t\t\t<div class=\"easypiechart\" id=\"bandwidth\" data-percent=\"";
        echo round($countdaili2 / $countdaili * 10);
        echo "\">\n\t\t            \t\t\t    \t<span class=\"percent\"></span>\n\t\t            \t\t\t\t</div>\n\t\t            \t\t\t</div>\n\t\t            \t\t</a>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<div class=\"col-sm-4\">\n\t\t\t\t\t\t\t<a  class=\"info-tiles tiles-primary\">\n\t\t            \t\t\t<div class=\"tiles-heading\">\n\t\t            \t\t\t\t卡密数量比例\n\t\t            \t\t\t</div>\n\t\t            \t\t\t<div class=\"tiles-body\">\n\t\t            \t\t\t\t<div class=\"easypiechart\" id=\"serverload\" data-percent=\"";
        echo round($countkm2 / $countkm * 10);
        echo "\">\n\t\t            \t\t\t    \t<span class=\"percent\"></span>\n\t\t            \t\t\t\t</div>\n\t\t            \t\t\t</div>\n\t\t            \t\t</a>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<div class=\"col-sm-4\">\n\t\t\t\t\t\t\t<a  class=\"info-tiles tiles-grape\">\n\t\t            \t\t\t<div class=\"tiles-heading\">\n\t\t            \t\t\t\t网站人数比例\n\t\t            \t\t\t</div>\n\t\t            \t\t\t<div class=\"tiles-body\">\n\t\t            \t\t\t\t<div class=\"easypiechart\" id=\"ramusage\" data-percent=\"";
        echo round($count2 / $count * 10);
        echo "\">\n\t\t            \t\t\t    \t<span class=\"percent\"></span>\n\t\t            \t\t\t\t</div>\n\t\t            \t\t\t</div>\n\t\t            \t\t</a>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t\t</div>\n\n\n\t <div class=\"row\">\n\t<div class=\"col-md-6\">       \n                 <div class=\"panel panel-default\">\n\t\t\t<div class=\"panel-heading\">\n\t\t\t\t<h2>官方公告</h2>\n\t\t\t</div>\n\t\t\t<div class=\"panel-body panel-no-padding\">\n\t\t\t\t<div class=\"table-responsive\">\n\t\t\t\t\t<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" class=\"table table-striped table-fixed-header m0\" id=\"example\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t\t<th>标题信息</th>\n\t\t\t\t\t\t\t\t<th>发布时间</th>\n\t\t\t\t\t\t\t\t<th>详情内容</th>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t\t";
        $gg = file_get_contents($msg);
        echo $gg;
        echo "\t\t\t\t\t\t</tbody>\n\t\t\t\t\t\t<tfoot>\n\t\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t\t<th>标题信息</th>\n\t\t\t\t\t\t\t\t<th>发布时间</th>\n\t\t\t\t\t\t\t\t<th>详情内容</th>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</tfoot>\n\t\t\t\t\t</table>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n\t<div class=\"col-md-6\">       \n                 <div class=\"panel panel-default\">\n\t\t\t<div class=\"panel-heading\">\n\t\t\t\t<h2>线路推送</h2>\n\t\t\t</div>\n\t\t\t<div class=\"panel-body panel-no-padding\">\n\t\t\t\t<div class=\"table-responsive\">\n\t\t\t\t\t<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" class=\"table table-striped table-fixed-header m0\" id=\"example\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t\t<th>线路名称</th>\n\t\t\t\t\t\t\t\t<th>发布时间</th>\n\t\t\t\t\t\t\t\t<th>覆盖地区</th>\n\t\t\t\t\t\t\t\t<th>详情内容</th>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t    ";
        $xl = file_get_contents($line);
        echo $xl;
        echo "\t\t\t\t\t\t</tbody>\n\t\t\t\t\t\t<tfoot>\n\t\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t\t<th>线路名称</th>\n\t\t\t\t\t\t\t\t<th>发布时间</th>\n\t\t\t\t\t\t\t\t<th>覆盖地区</th>\n\t\t\t\t\t\t\t\t<th>详情内容</th>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</tfoot>\n\t\t\t\t\t</table>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</div></div>\n                      </div>\n                   </div>\n                            </div> \n                        </div> \n";
        include 'copy.php';
        return null;
    }
    $av += 100 * ($out[1][$n] + $out[2][$n] + $out[3][$n]) / ($out[4][$n] + $out[5][$n] + $out[6][$n] + $out[7][$n]) . '</br>';
    ($n += 1) + -1;
}