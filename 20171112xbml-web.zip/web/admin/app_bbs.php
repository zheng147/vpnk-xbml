<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>流量卫士反馈管理</h1>\r\n                                <div class=\"options\">\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n";
$my = isset($_GET['my']) ? $_GET['my'] : null;
if ($my == 'del') {
    $id = $_GET['id'];
    $sql = $DB->query('DELETE FROM app_bbs WHERE id=\'' . $id . '\'');
    if ($sql) {
        echo '<div class="alert alert-success">删除成功！ - 3秒后自动跳转<meta http-equiv="refresh" content="3;URL=app_bbs.php">';
    } else {
        echo '<div class="alert alert-success">删除失败！ - 3秒后自动跳转<meta http-equiv="refresh" content="3;URL=app_bbs.php">';
    }
    echo '<style>#app_bbs{display: none;}</style>';
}
if (isset($_GET['kw'])) {
    if ($_GET['type'] == 1) {
        $sql = ' `km`=\'' . $_GET['kw'] . '\' and kind=1';
        $numrows = $DB->count('SELECT count(*) from app_bbs WHERE' . $sql);
        $con = '卡密 ' . $_GET['kw'] . ' 的搜索';
    } elseif ($_GET['type'] == 2) {
        $sql = ' `user`=\'' . $_GET['kw'] . '\' and kind=1';
        $numrows = $DB->count('SELECT count(*) from app_bbs WHERE' . $sql);
        $con = '卡密 ' . $_GET['kw'] . ' 的搜索';
    }
} else {
    $numrows = $DB->count('SELECT count(*) from app_bbs');
    $con = '平台共有 <b>' . $numrows . '</b> 个反馈';
}
echo "<div id=\"app_bbs\" class=\"row\">\r\n          <div class=\"col-md-12\">\r\n        <div class=\"panel panel-default\">\r\n            <div class=\"panel-heading\">\r\n                <h2>";
echo $con;
echo "</h2>\r\n </div>\r\n             <div class=\"panel-body panel-no-padding\"> <div class=\"table-responsive\">\r\n                <table class=\"table table-bordered table-fixed-header m0\">\r\n                  <thead><tr><th>用户名</th><th>反馈内容</th><th>线路名称</th><th>时间</th><th>免不免</th><th>操作</th></tr></thead>\r\n          <tbody>\r\n";
$pagesize = 30;
$pages = intval($numrows / $pagesize);
if ($numrows % $pagesize) {
    ($pages += 1) + -1;
}
if (isset($_GET['page'])) {
    $page = intval($_GET['page']);
} else {
    $page = 1;
}
$offset = $pagesize * ($page - 1);
$rs = $DB->query('SELECT * FROM app_bbs order by id desc limit ' . $offset . ',' . $pagesize);
while (true) {
    $res = $DB->fetch($rs);
    if (!$DB->fetch($rs)) {
        echo "          </tbody>\r\n        </table>\r\n      </div>\r\n     </div>\r\n        </div>\r\n\r\n";
        echo '<ul class="pagination">';
        $first = 1;
        $prev = $page - 1;
        $next = $page + 1;
        $last = $pages;
        if ($page > 1) {
            echo '<li><a href="kmlist.php?page=' . $first . $link . '">首页</a></li>';
            echo '<li><a href="kmlist.php?page=' . $prev . $link . '">&laquo;</a></li>';
        } else {
            echo '<li class="disabled"><a>首页</a></li>';
            echo '<li class="disabled"><a>&laquo;</a></li>';
        }
        $i = 1;
        while (true) {
            if ($i >= $page) {
                echo '<li class="disabled"><a>' . $page . '</a></li>';
                $i = $page + 1;
                while (true) {
                    if ($i > $pages) {
                        echo '';
                        if (!($page >= $pages)) {
                            echo '<li><a href="kmlist.php?page=' . $next . $link . '">&raquo;</a></li>';
                            echo '<li><a href="kmlist.php?page=' . $last . $link . '">尾页</a></li>';
                        } else {
                            echo '<li class="disabled"><a>&raquo;</a></li>';
                            echo '<li class="disabled"><a>尾页</a></li>';
                        }
                        echo '</ul>';
                        echo "             </div></div>\r\n\r\n          </div>\r\n            </div>\r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n";
                        include 'copy.php';
                        return null;
                    }
                    echo '<li><a href="kmlist.php?page=' . $i . $link . '">' . $i . '</a></li>';
                    ($i += 1) + -1;
                }
            }
            echo '<li><a href="kmlist.php?page=' . $i . $link . '">' . $i . '</a></li>';
            ($i += 1) + -1;
        }
    }
    if ($res['to'] == 1) {
        $to = '可以免';
    } elseif ($res['to'] == 3) {
        $to = '不能免';
    } elseif ($res['to'] == 2) {
        $to = '免部分';
    }
    if (empty($res['username'])) {
        $username = '回复内容无用户名';
    } else {
        $username = $res['username'];
    }
    echo '<tr><td>' . $username . '</td><td><b>' . $res['content'] . '</b></td><td><b>' . $res['name'] . '</b></td><td>' . date('Y-m-d', $res['time']) . '</td><td><b>' . $to . '</b></td><td><a href="./app_bbs.php?my=del&id=' . $res['id'] . '" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要删除此反馈吗？\');">删除</a></td></tr>';
}