<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
$rs = $DB->get_row('SELECT * FROM auth_config');
$regok = $rs['regok'];
$member_reg = $rs['member_reg'];
$activeok = $rs['activeok'];
$dl0 = $rs['dl0'];
$dl1 = $rs['dl1'];
$dl2 = $rs['dl2'];
$dl3 = $rs['dl3'];
$dl4 = $rs['dl4'];
$dl5 = $rs['dl5'];
$dls0 = $rs['dls0'];
$dls1 = $rs['dls1'];
$dls2 = $rs['dls2'];
$dls3 = $rs['dls3'];
$dls4 = $rs['dls4'];
$dls5 = $rs['dls5'];
$gongg = $rs['gg'];
$gonggs = $rs['ggs'];
$shopUrl_con = $rs['shopUrl'];
$shopCode_con = $rs['shopCode'];
$daili_cash_con = $rs['daili_cash'];
$reg_cash_con = round($rs['reg_cash'] / 1024 / 1024);
$user_cash_con = round($rs['user_cash'] / 1024 / 1024);
$qian_con = round($rs['qian'] / 1024 / 1024);
$user_endtime_con = $rs['user_endtime'];
$wx0 = $rs['wx0'];
$wx1 = $rs['wx1'];
$wx2 = $rs['wx2'];
$wx3 = $rs['wx3'];
$wx4 = $rs['wx4'];
$wx5 = $rs['wx5'];
echo "               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>代理高级配置</h1>\r\n                                <div class=\"options\">\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n <div class=\"row\">\r\n                <div class=\"col-sm-12\">\r\n                  <div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">请输入管理信息\r\n                    </div>\r\n                    <div class=\"panel-body\">\r\n";
$my = $_POST['my'];
if ($my == 'config') {
    echo '<div class="alert';
    $ak = daddslashes($_POST['ak']);
    $rk = daddslashes($_POST['rk']);
    $member_reg = daddslashes($_POST['member_reg']);
    $dl00 = daddslashes($_POST['dl0']);
    $dl01 = daddslashes($_POST['dl1']);
    $dl02 = daddslashes($_POST['dl2']);
    $dl03 = daddslashes($_POST['dl3']);
    $dl04 = daddslashes($_POST['dl4']);
    $dl05 = daddslashes($_POST['dl5']);
    $dls00 = daddslashes($_POST['dls0']);
    $dls01 = daddslashes($_POST['dls1']);
    $dls02 = daddslashes($_POST['dls2']);
    $dls03 = daddslashes($_POST['dls3']);
    $dls04 = daddslashes($_POST['dls4']);
    $dls05 = daddslashes($_POST['dls5']);
    $gg = daddslashes($_POST['gongg']);
    $ggs = daddslashes($_POST['gonggs']);
    $shopUrl = daddslashes($_POST['shopUrl']);
    $shopCode = daddslashes($_POST['shopCode']);
    $daili_cash = daddslashes($_POST['daili_cash']);
    $reg_cash = daddslashes($_POST['reg_cash']) * 1024 * 1024;
    $user_cash = daddslashes($_POST['user_cash']) * 1024 * 1024;
    $qian = daddslashes($_POST['qian']) * 1024 * 1024;
    $user_endtime = daddslashes($_POST['user_endtime']);
    $wx00 = daddslashes($_POST['wx0']);
    $wx01 = daddslashes($_POST['wx1']);
    $wx02 = daddslashes($_POST['wx2']);
    $wx03 = daddslashes($_POST['wx3']);
    $wx04 = daddslashes($_POST['wx4']);
    $wx05 = daddslashes($_POST['wx5']);
    $sql = $DB->query('update `auth_config` set  `gg`=\'' . $gg . '\',`ggs`=\'' . $ggs . '\',`activeok`=\'' . $ak . '\',`regok`=\'' . $rk . '\',`member_reg`=\'' . $member_reg . '\',`dl1`=\'' . $dl01 . '\',`dl2`=\'' . $dl02 . '\',`dl3`=\'' . $dl03 . '\',`dl4`=\'' . $dl04 . '\',`dl5`=\'' . $dl05 . '\',`dl0`=\'' . $dl00 . '\',`dls1`=\'' . $dls01 . '\',`dls2`=\'' . $dls02 . '\',`dls3`=\'' . $dls03 . '\',`dls4`=\'' . $dls04 . '\',`dls5`=\'' . $dls05 . '\',`dls0`=\'' . $dls00 . '\',`shopUrl`=\'' . $shopUrl . '\',`daili_cash`=\'' . $daili_cash . '\',`reg_cash`=\'' . $reg_cash . '\',`user_cash`=\'' . $user_cash . '\',`qian`=\'' . $qian . '\',`user_endtime`=\'' . $user_endtime . '\',`shopCode`=\'' . $shopCode . '\',`wx0`=\'' . $wx00 . '\',`wx1`=\'' . $wx01 . '\',`wx2`=\'' . $wx02 . '\',`wx3`=\'' . $wx03 . '\',`wx4`=\'' . $wx04 . '\',`wx5`=\'' . $wx05 . '\' where 1');
    if ($sql) {
        echo " alert-success\">\r\n                    <button type=\"button\" class=\"close\">\r\n                      <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>保存成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=dlconfig.php\">";
    } else {
        echo " alert-danger\">\r\n                    <button type=\"button\" class=\"close\">\r\n                      <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>保存失败！";
    }
    echo '</div>';
    echo '<style>#dlconfig{display: none;}</style>';
}
echo "              <form id=\"dlconfig\" action=\"./dlconfig.php\" method=\"post\" role=\"form\" class=\"form-horizontal validate\">\r\n                \r\n                <div class=\"form-group\">\r\n                  <input type=\"hidden\" name=\"my\" value=\"config\"/>\r\n                  <label class=\"col-sm-2 control-label\">代理公告</label>\r\n                  <div class=\"col-sm-9\">\r\n                    <textarea class=\"form-control\" cols=\"5\" id=\"field-5\" placeholder=\"请输入代理公告\" name=\"gongg\">";
echo $gongg;
echo "</textarea>\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group\">\r\n                  <input type=\"hidden\" name=\"my\" value=\"config\"/>\r\n                  <label class=\"col-sm-2 control-label\">用户公告</label>\r\n                  <div class=\"col-sm-9\">\r\n                    <textarea class=\"form-control\" cols=\"5\" id=\"field-5\" placeholder=\"请输入公告公告\" name=\"gonggs\">";
echo $gonggs;
echo "</textarea>\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\">购买链接</label>\r\n                  <div class=\"col-sm-9\">\r\n                    <input type=\"text\" class=\"form-control\" id=\"field-1\" value=\"";
echo $shopUrl_con;
echo "\" name=\"shopUrl\" data-validate=\"url\">\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\">支付代码</label>\r\n                  <div class=\"col-sm-9\">\r\n                    <textarea class=\"form-control\" cols=\"5\" id=\"field-5\" name=\"shopCode\">";
echo $shopCode_con;
echo "</textarea><br>\r\n                    <p class=\"text-success\">* 此处为第三方平台实现支付，<a target=\"_blank\" class=\"text-success\" href=\"http://www.jiasale.com/\">打开此链接</a>注册后插入代码</p>\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group-separator\"></div>\r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\">代理推荐返现</label>\r\n                  <div class=\"col-sm-9\">\r\n                    <div class=\"input-group\">\r\n                      <input type=\"text\" class=\"form-control\" id=\"field-1\" value=\"";
echo $daili_cash_con;
echo "\" name=\"daili_cash\" data-validate=\"required,number\">\r\n                      <span class=\"input-group-addon\">元</span>  \r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\">新注册用户赠送流量</label>\r\n                  <div class=\"col-sm-2\">\r\n                    <div class=\"input-group\">\r\n                      <input type=\"text\" class=\"form-control\" id=\"field-1\" value=\"";
echo $reg_cash_con;
echo "\" name=\"reg_cash\" data-validate=\"required,number\">\r\n                      <span class=\"input-group-addon\">MB</span>  \r\n                    </div>\r\n                  </div>\r\n                  <div class=\"col-sm-2\">\r\n                    <div class=\"input-group\">\r\n                      <input type=\"text\" class=\"form-control\" id=\"field-1\" value=\"";
echo $user_endtime_con;
echo "\" name=\"user_endtime\" data-validate=\"required,number\">\r\n                      <span class=\"input-group-addon\">天</span>  \r\n                    </div>\r\n                  </div>\r\n                  <div class=\"col-sm-5\">\r\n                    <p class=\"text-info\">* 赠送如果设置为0，注册的用户默认就禁用</p>\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\">推荐用户赠送流量</label>\r\n                  <div class=\"col-sm-4\">\r\n                    <div class=\"input-group\">\r\n                      <input type=\"text\" class=\"form-control\" id=\"field-1\" value=\"";
echo $user_cash_con;
echo "\" name=\"user_cash\" data-validate=\"required,number\">\r\n                      <span class=\"input-group-addon\">MB</span>  \r\n                    </div>\r\n                  </div>\r\n                  <div class=\"col-sm-5\">\r\n                    <p class=\"text-info\">* 推荐后的用户，采用卡密激活即可获取赠送流量</p>\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\">签到赠送流量</label>\r\n                  <div class=\"col-sm-9\">\r\n                    <div class=\"input-group\">\r\n                      <input type=\"text\" class=\"form-control\" id=\"field-1\" value=\"";
echo $qian_con;
echo "\" name=\"qian\" data-validate=\"required,number\">\r\n                      <span class=\"input-group-addon\">MB</span>  \r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group-separator\"></div>\r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\">代理注册</label>\r\n                  <div class=\"col-sm-9\">\r\n                ";
if ($member_reg == 1) {
    echo "\r\n                      <label class=\"radio-inline\">\r\n                        <input type=\"radio\" name=\"rk\" value=\"0\">\r\n                        开放\r\n                      </label>\r\n                      <label class=\"radio-inline\">\r\n                        <input type=\"radio\" name=\"rk\" checked value=\"1\">\r\n                        关闭\r\n                      </label>\r\n                  ";
} else {
    echo "\r\n                      <label class=\"radio-inline\">\r\n                        <input type=\"radio\" name=\"rk\" checked value=\"0\">\r\n                        开放\r\n                      </label>\r\n                      <label class=\"radio-inline\">\r\n                        <input type=\"radio\" name=\"rk\" value=\"1\">\r\n                        关闭\r\n                      </label>\r\n                  ";
}
echo "                  </div>\r\n                </div>  \r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\">用户注册</label>\r\n                  <div class=\"col-sm-9\">\r\n                ";
if ($member_reg == 1) {
    echo "\r\n                      <label class=\"radio-inline\">\r\n                        <input type=\"radio\" name=\"member_reg\" value=\"0\">\r\n                        开放\r\n                      </label>\r\n                      <label class=\"radio-inline\">\r\n                        <input type=\"radio\" name=\"member_reg\" checked value=\"1\">\r\n                        关闭\r\n                      </label>\r\n                  ";
} else {
    echo "\r\n                      <label class=\"radio-inline\">\r\n                        <input type=\"radio\" name=\"member_reg\" checked value=\"0\">\r\n                        开放\r\n                      </label>\r\n                      <label class=\"radio-inline\">\r\n                        <input type=\"radio\" name=\"member_reg\" value=\"1\">\r\n                        关闭\r\n                      </label>\r\n                  ";
}
echo "                  </div>\r\n                </div>  \r\n                <div class=\"form-group hide\">\r\n                  <label class=\"col-sm-2 control-label\">注册默认开通</label>\r\n                  <div class=\"col-sm-9\">\r\n                  <select name=\"ak\" class=\"form-control\">\r\n                  ";
if ($activeok == 1) {
    echo ' <option value="0">默认开通账号</option><option value="1" selected="selected">默认关闭账号</option>';
} else {
    echo ' <option value="0" selected="selected" >默认开通账号</option><option value="1" >默认关闭账号</option>';
}
echo "              </select>\r\n                  </div>\r\n                </div>  \r\n                <div class=\"form-group-separator\"></div>\r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\">普通代理价格</label>\r\n                  <div class=\"col-sm-9\">\r\n                    <div class=\"row\">\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"价格\" value=\"";
echo $dl0;
echo "\" name=\"dl0\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/天</span>  \r\n                        </div>\r\n                      </div>\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"价格\" value=\"";
echo $dls0;
echo "\" name=\"dls0\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/GB</span> \r\n                        </div>\r\n                      </div>\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"价格\" value=\"";
echo $wx0;
echo "\" name=\"wx0\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/无限流量账号</span> \r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\">铜牌代理价格</label>\r\n                  <div class=\"col-sm-9\">\r\n                    <div class=\"row\">\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"价格\" value=\"";
echo $dl1;
echo "\" name=\"dl1\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/天</span>  \r\n                        </div>\r\n                      </div>\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"价格\" value=\"";
echo $dls1;
echo "\" name=\"dls1\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/GB</span> \r\n                        </div>\r\n                      </div>\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"价格\" value=\"";
echo $wx1;
echo "\" name=\"wx1\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/无限流量账号</span> \r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group has-info\">\r\n                  <label class=\"col-sm-2 control-label\">银牌代理价格</label>\r\n                  <div class=\"col-sm-9\">\r\n                    <div class=\"row\">\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"价格\" value=\"";
echo $dl2;
echo "\" name=\"dl2\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/天</span>  \r\n                        </div>\r\n                      </div>\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"价格\" value=\"";
echo $dls2;
echo "\" name=\"dls2\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/GB</span> \r\n                        </div>\r\n                      </div>\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"价格\" value=\"";
echo $wx2;
echo "\" name=\"wx2\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/无限流量账号</span> \r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group has-success\">\r\n                  <label class=\"col-sm-2 control-label\">金牌代理价格</label>\r\n                  <div class=\"col-sm-9\">\r\n                    <div class=\"row\">\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"价格\" value=\"";
echo $dl3;
echo "\" name=\"dl3\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/天</span>  \r\n                        </div>\r\n                      </div>\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"价格\" value=\"";
echo $dls3;
echo "\" name=\"dls3\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/GB</span> \r\n                        </div>\r\n                      </div>\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"价格\" value=\"";
echo $wx3;
echo "\" name=\"wx3\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/无限流量账号</span> \r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group has-warning\">\r\n                  <label class=\"col-sm-2 control-label\">钻石代理价格</label>\r\n                  <div class=\"col-sm-9\">\r\n                    <div class=\"row\">\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"价格\" value=\"";
echo $dl4;
echo "\" name=\"dl4\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/天</span>  \r\n                        </div>\r\n                      </div>\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"价格\" value=\"";
echo $dls4;
echo "\" name=\"dls4\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/GB</span> \r\n                        </div>\r\n                      </div>\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"价格\" value=\"";
echo $wx4;
echo "\" name=\"wx4\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/无限流量账号</span> \r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group has-error\">\r\n                  <label class=\"col-sm-2 control-label\">至尊代理价格</label>\r\n                  <div class=\"col-sm-9\">\r\n                    <div class=\"row\">\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"时间\" value=\"";
echo $dl5;
echo "\" name=\"dl5\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/天</span>  \r\n                        </div>\r\n                      </div>\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"流量\" value=\"";
echo $dls5;
echo "\" name=\"dls5\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/GB</span> \r\n                        </div>\r\n                      </div>\r\n                      <div class=\"col-sm-4\">\r\n                        <div class=\"input-group\">\r\n                          <input type=\"text\" class=\"form-control\" placeholder=\"价格\" value=\"";
echo $wx5;
echo "\" name=\"wx5\" data-validate=\"required,number\">\r\n                          <span class=\"input-group-addon\">元/无限流量账号</span> \r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"form-group\">\r\n                  <label class=\"col-sm-2 control-label\"></label>\r\n                  <div class=\"col-sm-6\">\r\n                    <button type=\"submit\" type=\"button\" class=\"btn btn-info\">保存</button>\r\n                  </div>\r\n                </div>\r\n                \r\n              </form> \r\n                      \r\n                    </div>\r\n                  \r\n                  </div>\r\n                    \r\n                </div>\r\n            </div>\r\n   \r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n";
include 'copy.php';