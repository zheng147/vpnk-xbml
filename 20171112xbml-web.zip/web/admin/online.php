<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
if ($_GET['my'] == 'out') {
    system('../res/sha "' . $_GET['name'] . '"');
    exit('<script language=\'javascript\'>alert(\'踢出成功！\');window.location.href=\'./online.php\';</script>');
} elseif ($_GET['my'] == 'out_udp') {
    system('../udp/sha "' . $_GET['name'] . '"');
    exit('<script language=\'javascript\'>alert(\'踢出成功！\');window.location.href=\'./online.php\';</script>');
}
$file = '../res/tcp.txt';
$file2 = '../udp/udp.txt';
echo "<div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading mb0\">\r\n                                <h1>在线用户</h1>\r\n                                <div class=\"options\">\r\n    <div class=\"btn-toolbar\">\r\n        <a href=\"#\" class=\"btn btn-default\"><i class=\"fa fa-fw fa-cog\"></i></a>\r\n    </div>\r\n</div>\r\n                            </div>\r\n                            <div class=\"page-tabs\">\r\n                                <ul class=\"nav nav-tabs\">\r\n                                    \r\n<li class=\"active\"><a data-toggle=\"tab\" href=\"#details\">TCP模式</a></li>\r\n<li><a data-toggle=\"tab\" href=\"#meta\">UDP模式</a></li>\r\n\r\n                                </ul>\r\n                            </div>\r\n                            <div class=\"container-fluid\"><div class=\"tab-content\">\r\n  <div class=\"tab-pane active\" id=\"details\">\r\n        <div class=\"tab-pane active\" id=\"details\">\r\n <div class=\"row\">\r\n\r\n                <div class=\"col-sm-12\">\r\n                    <div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">TCP \r\n                    ";
$st1r = file_get_contents('../res/tcp.txt', false, stream_context_create(array('http' => array('method' => 'GET', 'timeout' => 1))));
$onlinenum = (substr_count($st1r, date('Y')) - 1) / 2;
echo round($onlinenum);
echo "                                           人在线\r\n                    </div>\r\n                     <div class=\"panel-body panel-no-padding\">\r\n                            <div class=\"table-responsive\">\r\n                                        <table cellspacing=\"0\" class=\"table table-bordered table-fixed-header m0\">\r\n                                            <thead>\r\n                                                <tr>\r\n                                                      <th>ID</th>\r\n                                                      <th data-priority=\"1\">用户名</th>\r\n                                                      <th data-priority=\"3\">上传</th>\r\n                                                      <th data-priority=\"6\">下载</th>\r\n                                                      <th data-priority=\"6\">剩余</th>\r\n                                                      <th data-priority=\"6\">IP地址</th>\r\n                                                      <th data-priority=\"6\">连接时间</th>\r\n                                                     <th data-priority=\"6\">操作</th>\r\n                                                </tr>\r\n                                            </thead>\r\n                                            <tbody>\r\n                                                 ";
$str = file_get_contents($file);
$num = (substr_count($str, date('Y')) - 1) / 2;
$fp = fopen($file, 'r');
fgets($fp);
fgets($fp);
fgets($fp);
$i = 0;
while (true) {
    if ($i >= $num) {
        echo "                                            </tbody>\r\n                                        </table>\r\n                 \r\n                            </div>\r\n                          </div></div></div></div></div></div>            \r\n               <div class=\"tab-pane\" id=\"meta\">\r\n               <div class=\"row\">\r\n                <div class=\"col-sm-12\">\r\n                     <div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">UDP \r\n                    ";
        $str = file_get_contents('../udp/udp.txt', false, stream_context_create(array('http' => array('method' => 'GET', 'timeout' => 1))));
        $onlinenum_udp = (substr_count($str, date('Y')) - 1) / 2;
        echo round($onlinenum_udp);
        echo "                                           人在线\r\n                    </div>\r\n                  <div class=\"panel-body panel-no-padding\">\r\n                            <div class=\"table-responsive\">\r\n                                        <table cellspacing=\"0\" class=\"table table-bordered table-fixed-header m0\">\r\n                                            <thead>\r\n                                                <tr>\r\n                                                      <th>ID</th>\r\n                                                      <th data-priority=\"1\">用户名</th>\r\n                                                      <th data-priority=\"3\">上传</th>\r\n                                                      <th data-priority=\"6\">下载</th>\r\n                                                      <th data-priority=\"6\">剩余</th>\r\n                                                      <th data-priority=\"6\">IP地址</th>\r\n                                                      <th data-priority=\"6\">连接时间</th>\r\n                                                     <th data-priority=\"6\">操作</th>\r\n                                                </tr>\r\n                                            </thead>\r\n                                            <tbody>\r\n                                            ";
        $str2 = file_get_contents($file2);
        $num = (substr_count($str2, date('Y')) - 1) / 2;
        $fp = fopen($file2, 'r');
        fgets($fp);
        fgets($fp);
        fgets($fp);
        $i = 0;
        while (true) {
            if ($i >= $num) {
                echo "                                                  \r\n                                            </tbody>\r\n                                        </table>\r\n                            \r\n                  \r\n                            \r\n                            </div>\r\n                          </div></div></div></div>\r\n\r\n\r\n                          \r\n                      \r\n                    </div>\r\n                  \r\n                  </div>\r\n                    \r\n                </div>\r\n            </div>\r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n";
                include 'copy.php';
                return null;
            }
            $j = $i + 1;
            echo '<tr>';
            $line = fgets($fp);
            $arr = explode(',', $line);
            $recv = round($arr[2] / 1024) / 1000;
            $sent = round($arr[3] / 1024) / 1000;
            $rs = $DB->query('SELECT * FROM `openvpn` WHERE iuser=\'' . $arr['0'] . '\'');
            $res = $DB->fetch($rs);
            echo '<th>' . $j . '</th>';
            echo '<td>' . $arr[0] . '</td>';
            echo '<td>' . $recv . 'MB</td>';
            echo '<td>' . $sent . 'MB</td>';
            echo '<td>' . round(($res['maxll'] - $res['isent'] - $res['irecv']) / 1024 / 1024) . 'MB</td>';
            echo '<td>' . $arr[1] . '</td>';
            echo '<td>' . $arr[4] . '</td>';
            echo '<td><a class="btn btn-xs btn-danger" href="./online.php?my=out_udp&name=' . $arr[0] . '"> 踢出 </a></td>';
            echo '</tr>';
            ($i += 1) + -1;
        }
    }
    $j = $i + 1;
    echo '<tr>';
    $line = fgets($fp);
    $arr = explode(',', $line);
    $recv = round($arr[2] / 1024) / 1000;
    $sent = round($arr[3] / 1024) / 1000;
    $rs = $DB->query('SELECT * FROM `openvpn` WHERE iuser=\'' . $arr['0'] . '\'');
    $res = $DB->fetch($rs);
    echo '<th>' . $j . '</th>';
    echo '<td>' . $arr[0] . '</td>';
    echo '<td>' . $recv . 'MB</td>';
    echo '<td>' . $sent . 'MB</td>';
    echo '<td>' . round(($res['maxll'] - $res['isent'] - $res['irecv']) / 1024 / 1024) . 'MB</td>';
    echo '<td>' . $arr[1] . '</td>';
    echo '<td>' . $arr[4] . '</td>';
    echo '<td><a class="btn btn-xs btn-danger" href="./online.php?my=out&name=' . $arr[0] . '"> 踢出 </a></td>';
    echo '</tr>';
    ($i += 1) + -1;
}