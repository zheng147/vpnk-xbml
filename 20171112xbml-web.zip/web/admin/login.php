<?php /* by:凌一 QQ:863963860*/

echo "<!DOCTYPE html>\n<html lang=\"en\" class=\"coming-soon\">\n<head>\n    <meta charset=\"utf-8\">\n    <title>登录到后台</title>\n    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no\">\n    <meta name=\"apple-mobile-web-app-capable\" content=\"yes\">\n    <meta name=\"apple-touch-fullscreen\" content=\"yes\">\n    <meta name=\"description\" content=\"\">\n    <meta name=\"author\" content=\"The Red Team\">\n    <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700' rel='stylesheet' type='text/css'>\n    <link href=\"../api/Core/assets/plugins/iCheck/skins/minimal/blue.css\" type=\"text/css\" rel=\"stylesheet\">\n    <link href=\"../api/Core/assets/fonts/font-awesome/css/font-awesome.min.css\" type=\"text/css\" rel=\"stylesheet\">\n    <link href=\"../api/Core/assets/css/styles.css\" type=\"text/css\" rel=\"stylesheet\">\n    </head>\n";

echo '    ';
error_reporting(E_ALL);
$mod = 'blank';
include '../api.php';
if (isset($_POST['user']) && isset($_POST['pass'])) {
    $user = daddslashes($_POST['user']);
    $pass = daddslashes($_POST['pass']);
    $pass = md5($pass);
    $row = $DB->get_row('SELECT * FROM `admin` limit 1');
    if ($user == $row['username'] && $pass == $row['password']) {
        $session = md5($user . $pass . $password_hash);
        $token = authcode($user . "\t" . $session, 'ENCODE', SYS_KEY);
        setcookie('ol_token', $token, time() + 604800);
        @header('Content-Type: text/html; charset=UTF-8');
        exit('<script language=\'javascript\'>alert(\'登录成功！\');window.location.href=\'index.php\';</script>');
    } elseif ($pass != $row['pass']) {
        @header('Content-Type: text/html; charset=UTF-8');
        exit('<script language=\'javascript\'>alert(\'用户名或密码不正确！\');history.go(-1);</script>');
    }
} elseif (isset($_GET['logout'])) {
    setcookie('ol_token', '', time() - 604800);
    @header('Content-Type: text/html; charset=UTF-8');
    exit('<script language=\'javascript\'>alert(\'您已成功注销本次登录！\');window.location.href=\'./login.php\';</script>');
} elseif ($islogin2 == 1) {
    exit('<script language=\'javascript\'>alert(\'您已登录！\');window.location.href=\'index.php\';</script>');
}
$bn = $DB->get_row('SELECT * FROM banner');
$img1 = $bn['img1'];
$tit1 = $bn['tit1'];
$info1 = $bn['info1'];
$img2 = $bn['img2'];
$tit2 = $bn['tit2'];
$info2 = $bn['info2'];
$img3 = $bn['img3'];
$tit3 = $bn['tit3'];
$info3 = $bn['info3'];
echo '    <body  class="focused-form" style="background-image:url(';
echo $img2;
echo ")\">\n    <br>  <br>  <br>\n<div class=\"container\" id=\"login-form\">\n\t<a href=\"index.php\"><img src=\"../api/Core/assets/img/login-logo.png\" class=\"login-logo\"></a>\n\t<div class=\"row\">\n\t\t<div class=\"col-md-4 col-md-offset-4\">\n\t\t\t<div class=\"panel panel-default\">\n\t\t\t\t<div class=\"panel-heading\"><h2>管理员登录</h2></div>\n\t\t\t\t<div class=\"panel-body\">\n\t\t\t\t\t\n\t\t\t\t\t<form action=\"login.php\" method=\"post\" role=\"form\" id=\"login\" class=\"form-horizontal\">\n\t\t\t\t\t\t<div class=\"form-group\">\n\t                        <div class=\"col-xs-12\">\n\t                        \t<div class=\"input-group\">\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t<span class=\"input-group-addon\">\n\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-user\"></i>\n\t\t\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control\" name=\"user\" id=\"user\" placeholder=\"请输入管理员帐号\">\n\t\t\t\t\t\t\t\t</div>\n\t                        </div>\n\t\t\t\t\t\t</div>\n\n\t\t\t\t\t\t<div class=\"form-group\">\n\t                        <div class=\"col-xs-12\">\n\t                        \t<div class=\"input-group\">\n\t\t\t\t\t\t\t\t\t<span class=\"input-group-addon\">\n\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-key\"></i>\n\t\t\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t\t\t\t<input type=\"password\" class=\"form-control\" name=\"pass\" id=\"pass\" placeholder=\"请输入管理员密码\">\n\t\t\t\t\t\t\t\t</div>\n\t                        </div>\n\t\t\t\t\t\t</div>\n\n\t\t\t\t\t\t<div class=\"panel-footer\">\n\t\t\t\t\t\t\t<div class=\"clearfix\">\n\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-primary pull-right\">登录</button>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</div>\n\n\t\t\t\t\t</form>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n</div>\n<script src=\"../api/Core/assets/js/jquery-1.10.2.min.js\"></script> \t\n<script src=\"../api/Core/assets/js/jqueryui-1.9.2.min.js\"></script> \n<script src=\"../api/Core/assets/js/bootstrap.min.js\"></script>\n<script src=\"../api/Core/assets/plugins/jquery-slimscroll/jquery.slimscroll.js\"></script> \n<script src=\"../api/Core/assets/plugins/sparklines/jquery.sparklines.min.js\"></script>  \t\n<script src=\"../api/Core/assets/plugins/jstree/dist/jstree.min.js\"></script>  \n<script src=\"../api/Core/assets/plugins/codeprettifier/prettify.js\"></script> \t\n<script src=\"../api/Core/assets/plugins/bootstrap-switch/bootstrap-switch.js\"></script> \n<script src=\"../api/Core/assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js\"></script>\n<script src=\"../api/Core/assets/plugins/iCheck/icheck.min.js\"></script> \n<script src=\"../api/Core/assets/js/enquire.min.js\"></script> \t\t\t\n<script src=\"../api/Core/assets/plugins/bootbox/bootbox.js\"></script>\t\n<script src=\"../api/Core/assets/js/application.js\"></script>\n<script src=\"../api/Core/assets/demo/demo.js\"></script>\n<script src=\"../api/Core/assets/demo/demo-switcher.js\"></script>\n<script src=\"../api/Core/assets/plugins/simpleWeather/jquery.simpleWeather.min.js\"></script> \n    </body>\n</html>";