<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>代理充值套餐管理</h1>\r\n                                <div class=\"options\"> <button data-target=\"#addkm\" class=\"btn btn-info btn-single\" data-toggle=\"modal\">添加套餐</button>\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n";
if ($_POST['name']) {
    echo '';
    $name = daddslashes($_POST['name']);
    $days = daddslashes($_POST['days']);
    $maxll = daddslashes($_POST['maxll']) * 1024 * 1024;
    $km_rmb = daddslashes($_POST['km_rmb']);
    if (!$DB->get_row('select * from `kmtype` where `name`=\'' . $name . '\' limit 1')) {
        $sql = 'insert into `kmtype` (`name`,`days`,`maxll`,`km_rmb`,`i`) values (\'' . $name . '\',\'0\',\'0\',\'' . $km_rmb . '\',\'1\')';
        if ($DB->query($sql)) {
            echo "<div class=\"alert alert-success\">\r\n                    <button type=\"button\" class=\"close\">\r\n                      <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>\r\n                  成功添加一个充值</div>\r\n                <a href=\"javascript:history.go(-1)\" class=\"btn btn-success btn-icon btn-icon-standalone\">\r\n                 \r\n                  <span>继续添加</span>\r\n                </a>\r\n                <a href=\"cztype.php\" class=\"btn btn-info btn-icon btn-icon-standalone\">\r\n                 \r\n                  <span>查看列表</span>\r\n                </a>\r\n                  <style>#addtype{display: none;}</style>";
        } else {
            echo "<div class=\"alert alert-danger\">\r\n                    <button type=\"button\" class=\"close\">\r\n                      <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>添加失败：" . $DB->error() . "</div>\r\n                <a href=\"javascript:history.go(-1)\" class=\"btn btn-secondary btn-icon btn-icon-standalone\">\r\n                  <i class=\"fa-edit\"></i>\r\n                  <span>继续添加</span>\r\n                </a>\r\n                <a href=\"cztype.php\" class=\"btn btn-info btn-icon btn-icon-standalone\">\r\n                  <i class=\"fa-list-ol\"></i>\r\n                  <span>查看列表</span>\r\n                </a>\r\n                <style>#addtype{display: none;}</style>";
        }
    } else {
        echo '<script>alert(\'该充值已存在！\');history.go(-1);</script>';
    }
    echo '';
}
$my = isset($_GET['my']) ? $_GET['my'] : null;
if ($my == 'del') {
    echo '<div class="alert';
    $id = $_GET['id'];
    $sql = $DB->query('DELETE FROM `kmtype` WHERE id=\'' . $id . '\'');
    if ($sql) {
        echo " alert-success\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除成功！";
    } else {
        echo " alert-danger\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除失败！";
    }
    echo '</div><style>#addtype{display: none;}</style>';
}
if (!empty($_GET['kw'])) {
    $sql = ' `id`=\'' . $_GET['kw'] . '\'';
    $numrows = $DB->count('SELECT count(*) from `kmtype` WHERE' . $sql);
    $con = '包含 ' . $_GET['kw'] . ' 的共有 ' . $numrows . ' 个充值类型';
} else {
    $numrows = $DB->count('SELECT count(*) from `kmtype` WHERE  `i` = \'1\'');
    $sql = ' 1';
    $con = '平台共有 ' . $numrows . ' 个充值类型';
}
echo "            <div id=\"addtype\" class=\"row\">\r\n                <div class=\"col-sm-12\">\r\n                    \r\n                  <div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">";
echo $con;
echo "                    </div>\r\n                    <div class=\"panel-body\">\r\n                    \r\n                    ";
$dl_rs = $DB->query('SELECT * FROM `auth_daili`');
while (true) {
    $dl_res = $DB->fetch($dl_rs);
    if (!$DB->fetch($dl_rs)) {
        echo "                    \r\n                    <br>\r\n                    <div id=\"addtype_list\" class=\"row\">\r\n                                       ";
        $rs = $DB->query('SELECT * FROM `kmtype` WHERE `i` = 1');
        while (true) {
            $res = $DB->fetch($rs);
            if (!$DB->fetch($rs)) {
                echo "                                </div>\r\n                   <div class=\"alert alert-success\">\r\n                            </button>此处仅添加代理商ID为0的套餐，就是管理员自己</div>\r\n                    </div>\r\n                  \r\n                  </div>\r\n                    \r\n                </div><div class=\"modal fade\" id=\"addkm\" role=\"dialog\" tabindex=\"-1\" aria-labelledby=\"addkm\" aria-hidden=\"true\">\r\n<div class=\"modal-dialog\">\r\n<div class=\"modal-content\">\r\n<div class=\"modal-header\">\r\n<form action=\"cztype.php?my=add\" method=\"POST\" class=\"form-inline\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"modal\"><i class=\"pci-cross pci-circle\"></i></button>\r\n<h4 class=\"modal-title\">添加套餐</h4>\r\n</div>\r\n<br>\r\n<div class=\"panel-body\">\r\n   <div class=\"col-md-2\"><label>充值名称</label></div>\r\n   <div class=\"col-md-12\">\r\n<div class=\"form-group\">\r\n<input type=\"text\" class=\"form-control\" name=\"name\" placeholder=\"充值名称\">\r\n</div>\r\n</div>\r\n</br>\r\n  <div class=\"col-md-2\"><label>充值额度</label></div>\r\n   <div class=\"col-md-12\">\r\n\r\n  <div class=\"form-group\">\r\n    <input type=\"text\" class=\"form-control\" name=\"km_rmb\" placeholder=\"充值额度\">\r\n  </div>\r\n</div>\r\n  </br>\r\n  \r\n  <div class=\"col-md-12\">\r\n<div class=\"modal-footer\">\r\n<input type=\"submit\" value=\"生成\" class=\"btn btn-primary\"/>\r\n</div></div>\r\n</form>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n            </div>\r\n   \r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n";
                include 'copy.php';
                return null;
            }
            echo "                               <div class=\"col-md-4\">\r\n                                     <ul class=\"list-group\">\r\n                                     <li class=\"list-group-item\"><strong>";
            echo $res['name'];
            echo "</strong></li>\r\n                                     <li class=\"list-group-item\">";
            echo $res['km_rmb'];
            echo "元</li>\r\n                                       <li class=\"list-group-item\"><a href=\"kmtype.php?my=del&id=";
            echo $res['id'];
            echo "\" class=\"btn bin-block btn-danger\" onclick=\"if(!confirm('你确实要删除此套餐吗？')){return false;}\">删除</a> \r\n                                                  </li>\r\n                                              </form>\r\n                                            </div>\r\n                                           </ul>\r\n                                        ";
        }
    }
    echo '                    <a href="kmtype.php?dlid=';
    echo $dl_res['id'];
    echo '" class="btn btn-info">';
    echo $dl_res['user'];
    echo "</a>\r\n                    ";
}