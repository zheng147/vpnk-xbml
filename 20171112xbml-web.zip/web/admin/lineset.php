<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>线路配置</h1>\r\n                                <div class=\"options\">\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n";
$id = daddslashes($_GET['id']);
echo "            <div class=\"row\">\r\n                <div class=\"col-sm-12\">\r\n                    \r\n                  <div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">进行线路编号为 ";
echo $id;
echo " 的配置\r\n                    </div>\r\n                    <div class=\"panel-body\">\r\n";
if (!(bool) (!$id)) {
    $row = $DB->get_row('select * from `xbml_article` where id=\'' . $id . '\' limit 1');
}
if ((bool) (!$id)) {
    exit('线路不存在!');
}
if ($_POST['type'] == 'update') {
    echo '<div class="alert ';
    $name = daddslashes($_POST['name']);
    $mo = daddslashes($_POST['mo']);
    $linetype = daddslashes($_POST['linetype']);
    if ($DB->query('update `xbml_article` set `category_id`=\'' . $linetype . '\',`title`=\'' . $name . '\',`content`=\'' . $mo . '\' where id=\'' . $id . '\'')) {
        echo "alert-success\">\r\n                    <button type=\"button\" class=\"close\">\r\n                      <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>\r\n                  修改成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=openlist.php\"";
    } else {
        echo "alert-danger\">\r\n                    <button type=\"button\" class=\"close\">\r\n                      <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>\r\n                  修改失败！" . $DB->error();
    }
    echo '</div>';
    echo '<style>#lineset{display: none;}</style>';
}
echo "      \r\n                <form id=\"lineset\" action=\"./lineset.php?id=";
echo $id;
echo "\" method=\"post\" role=\"form\" class=\"form-horizontal\">\r\n                <input type=\"hidden\" name=\"type\" value=\"update\" />\r\n                    <div class=\"form-group\">\r\n                      <label class=\"col-sm-2 control-label\">线路名称：</label>\r\n                      <div class=\"col-sm-9\">\r\n                        <input type=\"text\" class=\"form-control\" id=\"field-1\" placeholder=\"输入模式名称\" name=\"name\" data-validate=\"required\" value=\"";
echo $row['title'];
echo "\">\r\n                      </div>\r\n                    </div>\r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\">线路类型：</label>\r\n                    <div class=\"col-sm-9\">\r\n                      <label class=\"radio-inline\">\r\n                        <input type=\"radio\" name=\"linetype\" ";
if (1 == $row['category_id']) {
    echo 'checked=""';
}
echo " value=\"1\">\r\n                        移动\r\n                      </label>\r\n                      <label class=\"radio-inline\">\r\n                        <input type=\"radio\" name=\"linetype\" ";
if (2 == $row['category_id']) {
    echo 'checked=""';
}
echo " value=\"2\">\r\n                        联通\r\n                      </label>\r\n                      <label class=\"radio-inline\">\r\n                        <input type=\"radio\" name=\"linetype\" ";
if (3 == $row['category_id']) {
    echo 'checked=""';
}
echo " value=\"3\">\r\n                        电信\r\n                      </label>\r\n                    </div>\r\n                  </div>\r\n                    <div class=\"form-group\">\r\n                      <label class=\"col-sm-2 control-label\">模式内容：</label>\r\n                      <div class=\"col-sm-9\">\r\n                         <textarea class=\"form-control\" cols=\"5\" id=\"field-5\" name=\"mo\" rows=\"6\" data-validate=\"required\">";
echo $row['content'];
echo "</textarea>\r\n                      </div>\r\n                    </div>   \r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\"></label>\r\n                    <div class=\"col-sm-9\">\r\n                      <button type=\"submit\" type=\"button\" class=\"btn btn-info btn-block\">修改</button>\r\n                    </div>\r\n                  </div>\r\n                  \r\n                </form>\r\n                      \r\n                    </div>\r\n                  \r\n                  </div>\r\n                    \r\n                </div>\r\n            </div>\r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n";
include 'copy.php';