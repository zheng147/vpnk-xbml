<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "\r\n               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>账号列表</h1>\r\n                                <div class=\"options\">\r\n                                <div class=\"btn-group\">\r\n                                    <a href=\"#\" class=\"btn btn-primary\"><i class=\"fa fa-cog\"></i></a>\r\n                                    <a href=\"#\" class=\"btn btn-primary dropdown-toggle\" data-toggle=\"dropdown\"><span class=\"caret\"></span></a>\r\n                                    <ul class=\"dropdown-menu\" role=\"menu\">\r\n                                        <li><a href=\"daochu.php\" onclick=\"if(!confirm('你确实要执行批量导出吗？')){return false;}\">导出账号数据</a></li>\r\n                                        <li>   <a href=\"qqlist.php?my=qk\" onclick=\"if(!confirm('你确实要删除所有已禁用帐号吗？')){return false;}\">清空禁用帐号</a></li>\r\n                                         <li>   <a href=\"qqlist.php?my=qk2\" onclick=\"if(!confirm('你确实要删除所有帐号吗？')){return false;}\">清空所有帐号</a></li>\r\n                                    </ul>\r\n                                </div>\r\n</div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n";
$my = isset($_GET['my']) ? $_GET['my'] : null;
if ($my == 'del') {
    echo '<div class="alert';
    $user = $_GET['user'];
    $sql = $DB->query('DELETE FROM `openvpn` WHERE iuser=\'' . $user . '\'');
    if ($sql) {
        echo " alert-success\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=qqlist.php\">";
    } else {
        echo " alert-danger\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除失败！";
    }
    echo '</div><style>#qqlist{display: none;}</style>';
} else {
    if (!empty($_GET['kw'])) {
        $sql = ' `iuser`=\'' . $_GET['kw'] . '\'';
        $numrows = $DB->count('SELECT count(*) from `openvpn` WHERE' . $sql);
        $con = '包含 ' . $_GET['kw'] . ' 的共有 ' . $numrows . ' 个账号';
    } else {
        $numrows = $DB->count('SELECT count(*) from `openvpn` WHERE 1');
        $sql = ' 1';
        $con = '平台共 ' . $numrows . ' 个账号';
    }
    if ($my == 'qk') {
        echo '<div class="alert';
        if ($DB->query('DELETE FROM openvpn WHERE i=0') == true) {
            echo " alert-success\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>清空成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=qqlist.php\">";
        } else {
            echo " alert-danger\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>清空失败！";
        }
        echo '</div><style>#qqlist{display: none;}</style>';
    }
    if ($my == 'qk2') {
        echo '<div class="alert';
        if ($DB->query('DELETE FROM openvpn') == true) {
            echo " alert-success\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>清空成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=qqlist.php\">";
        } else {
            echo " alert-danger\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>清空失败！";
        }
        echo '</div><style>#qqlist{display: none;}</style>';
    }
    echo "<div id=\"qqlist\" class=\"row\">\r\n    <div class=\"col-md-12\">\r\n        <div class=\"panel panel-default\">\r\n            <div class=\"panel-heading\">\r\n                <h2>";
    echo $con;
    echo "</h2>\r\n                <div class=\"panel-ctrls\"><form action=\"qqlist.php\">\r\n                <label class=\"panel-ctrls-center\"> <input type=\"text\" class=\"form-control\" size=\"10\" name=\"kw\" placeholder=\"查询\"></label>\r\n                 </form></div>\r\n            </div>\r\n            <div class=\"panel-body panel-no-padding\"> <div class=\"table-responsive\">\r\n                <table id=\"example\" class=\"table table-bordered table-fixed-header m0\" cellspacing=\"0\" width=\"100%\">\r\n                    <thead>\r\n                        <tr>\r\n                            <th>ID</th>\r\n                            <th>账号</th>\r\n                            <th>密码</th>\r\n                            <th>添加时间</th>\r\n                            <th>到期时间</th>\r\n                            <th>剩余流量</th>\r\n                            <th>总流量</th>\r\n                            <th>激活天数</th>\r\n                            <th>状态</th>\r\n                            <th>备注</th>\r\n                            <th>推荐人</th>\r\n                            <th>充值送推荐人流量</th>\r\n                            <th>操作</th>\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n                       ";
    $pagesize = 20;
    $pages = intval($numrows / $pagesize);
    if ($numrows % $pagesize) {
        ($pages += 1) + -1;
    }
    if (isset($_GET['page'])) {
        $page = intval($_GET['page']);
    } else {
        $page = 1;
    }
    $offset = $pagesize * ($page - 1);
    $rs = $DB->query('SELECT * FROM `openvpn` WHERE' . $sql . ' order by id desc limit ' . $offset . ',' . $pagesize);
    while ($res = $DB->fetch($rs)) {
        echo "                                        <tr>\r\n                                        <th><span class=\"co-name\">";
        echo $res['fwqid'];
        echo "</span></th>\r\n                                        <td>";
        echo $res['iuser'];
        echo "</td>\r\n                                        <td>";
        echo $res['pass'];
        echo "</td>\r\n                                        <td>";
        echo date('Y-m-d', $res['starttime']);
        echo "</td>\r\n                                        <td>";
        echo date('Y-m-d', $res['endtime']);
        echo "</td>\r\n                                        <td>";
        echo round(($res['maxll'] - $res['isent'] - $res['irecv']) / 1024 / 1024);
        echo "MB</td>\r\n                                        <td>";
        echo round($res['maxll'] / 1024 / 1024);
        echo "MB</td>\r\n                                        <td>";
        echo $res['tian'];
        echo "</td>\r\n                                        <td>";
        echo $res['i'] ? '<span class="badge badge-info">开通</span>' : '<span class="badge badge-danger">禁用</span>';
        echo "</td>\r\n                                        <td>";
        echo $res['notes'];
        echo "</td>\r\n                                        <td>";
        echo $res['tj_user'];
        echo "</td>\r\n                                        <td>";
        echo $res['tj_ok'] ? '<div class="label label-info">有</div>' : '<div class="label label-default">无</div>';
        echo "</td>\r\n                                        <td><a class=\"btn btn-xs btn-success\" href=\"./qset.php?user=";
        echo $res['iuser'];
        echo '"><i class="fa fa-cog"></i></a>&nbsp;<a href="./qqlist.php?my=del&user=';
        echo $res['iuser'];
        echo "\" class=\"btn btn-xs btn-danger\" onclick=\"if(!confirm('你确实要删除此账号吗？')){return false;}\"><i class=\"fa fa-times\"></i></a></td>\r\n                                        </tr>\r\n                                        ";
    }
    echo "                                      </tbody>\r\n                                  </table>\r\n                       </div>\r\n                      \r\n                      <div class=\"panel-footer\">\r\n                      <div class=\"row\">\r\n                      <div class=\"col-sm-6\">\r\n                      </div>\r\n                      <div class=\"col-sm-6\">\r\n                      <div class=\"dataTables_paginate paging_bootstrap\" id=\"example_paginate\">\r\n                       ";
    echo '<ul class="pagination pull-right m0">';
    $first = 1;
    $prev = $page - 1;
    $next = $page + 1;
    $last = $pages;
    if ($page > 1) {
        echo '<li class="previous disabled"><a href="qqlist.php?page=' . $first . $link . '">首页</a></li>';
    } else {
        echo '<li class="previous disabled"><a>首页</a></li>';
    }
    $i = 1;
    while (!($i >= $page)) {
        echo '<li class="active"><a href="qqlist.php?page=' . $i . $link . '">' . $i . '</a></li>';
        ($i += 1) + -1;
    }
    echo '<li  class="active"><a>' . $page . '</a></li>';
    $i = $page + 1;
    while (!($i > $pages)) {
        echo '<li><a href="qqlist.php?page=' . $i . $link . '">' . $i . '</a></li>';
        ($i += 1) + -1;
    }
    echo '';
    if (!($page >= $pages)) {
        echo '<li class="next disabled"><a href="qqlist.php?page=' . $last . $link . '">尾页</a></li>';
    } else {
        echo '<li class="next disabled"><a>尾页</a></li>';
    }
    echo '</ul>';
}
echo "                      </div>\r\n                      </div>\r\n                      </div>\r\n                      </div>\r\n\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n\r\n                            </div> <!-- .container-fluid -->\r\n                        </div> <!-- #page-content -->\r\n                    </div>\r\n";
include 'copy.php';