<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "\r\n               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>启动图设置</h1>\r\n                                <div class=\"options\">\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n                           ";
$require = true;
include '../app_api/Splash.php';
if ($_GET['act'] == 'update') {
    $content = '<?php /* by:凌一 QQ:863963860*/   $data["status"] = "' . $_POST['status'] . "\";\r\n    \$data[\"url\"] = \"" . $_POST['url'] . "\"; //请在此填写下载地址\r\n    ";
    file_put_contents('../app_api/Splash.php', $content);
    success_go('修改成功', 'AdminSplash.php?act=mod&id=' . $_GET['id']);
} else {
    $action = '?act=update';
    echo "<div class=\"main\">\r\n<div style=\"clear:both;height:10px;\"></div>\r\n<div class=\"alert alert-danger\">请保证您的图片尽可能的小！因为如果超过2秒APP无法全部加载图片，为了用户体验，就会放弃加载！</div>\r\n    <form class=\"form-horizontal\" role=\"form\" method=\"POST\" action=\"";
    echo $action;
    echo "\" onsubmit=\"return checkStr()\">\r\n    <div class=\"form-group\">\r\n        <label for=\"firstname\" class=\"col-sm-2 control-label\">功能开关</label>\r\n        <div class=\"col-sm-10\">\r\n            <div class=\"col-sm-10\">\r\n            <select name=\"status\">\r\n                <option value=\"error\">关闭</option>\r\n                <option value=\"success\">开启</option>\r\n            </select>\r\n        【当前】<b style=\"color:red\">";
    echo $data['status'] == 'success' ? '已开启' : '已关闭';
    echo "</b>\r\n        </div>\r\n        </div>\r\n    </div>\r\n    \r\n    \r\n    \r\n   \r\n    <div class=\"form-group\" >\r\n        <label for=\"firstname\" class=\"col-sm-2 control-label\">启动图地址</label>\r\n        <div class=\"col-sm-10\">\r\n            <div class=\"col-sm-10\"><input class=\"form-control\" rows=\"10\" name=\"url\" value=\"";
    echo $data['url'];
    echo "\"></div>\r\n        </div>\r\n    </div>\r\n    \r\n    <div class=\"form-group\">\r\n        <div class=\"col-sm-offset-2 col-sm-10\">\r\n            <button type=\"submit\" class=\"btn btn-default\">提交数据</button>\r\n        </div>\r\n    </div>\r\n</form> \r\n    </div>\r\n    <script>\r\n    function checkStr(){\r\n        var title = \$('[name=\"title\"]').val();\r\n        var content = \$('[name=\"content\"]').val();\r\n        if(title == \"\" || content ==　\"\"){\r\n            alert(\"标题与内容不得为空\");\r\n            return false;\r\n        }\r\n        return true;\r\n    }\r\n    </script>\r\n";
}
echo "                            </div> \r\n                        </div>\r\n                    </div>\r\n";
include 'copy.php';
function success_go($msg, $url)
{
    echo "<div class=\"alert alert-success alert-dismissable\">\r\n            <button type=\"button\" class=\"close\" data-dismiss=\"alert\"\r\n                    aria-hidden=\"true\">\r\n                &times;\r\n            </button>\r\n            " . $msg . ',系统将在3秒后跳转。<a href="' . $url . "\">等不及了！</a>\r\n        </div> ";
    echo "<script>setTimeout(function(){\r\n            window.location.href=\"" . $url . "\";\r\n        },3000)</script>";
    return null;
}
function error_go($msg, $url)
{
    echo "<div class=\"alert alert-danger alert-dismissable\">\r\n            <button type=\"button\" class=\"close\" data-dismiss=\"alert\"\r\n                    aria-hidden=\"true\">\r\n                &times;\r\n            </button>\r\n            " . $msg . ',系统将在3秒后跳转。<a href="' . $url . "\">等不及了！</a>\r\n        </div> ";
    echo "<script>setTimeout(function(){\r\n            window.location.href=\"" . $url . "\";\r\n        },3000)</script>";
    return null;
}