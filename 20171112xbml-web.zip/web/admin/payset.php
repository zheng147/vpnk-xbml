<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>在线支付设置</h1>\r\n                                <div class=\"options\">\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n                            ";
$id = '1';
if (!(bool) (!$id)) {
    $row = $DB->get_row('select * from `alipay` where id=\'' . $id . '\' limit 1');
}
if ((bool) (!$id)) {
    exit('不存在!');
}
if ($_POST['type'] == 'update') {
    echo '<div class="alert ';
    $partner = daddslashes($_POST['partner']);
    $alikey = daddslashes($_POST['alikey']);
    $url = daddslashes($_POST['url']);
    if ($DB->query('update `alipay` set `partner`=\'' . $partner . '\',`alikey`=\'' . $alikey . '\',`url`=\'' . $url . '\' where id=\'' . $id . '\'')) {
        echo "alert-success\">\r\n                    <button type=\"button\" class=\"close\">\r\n                      <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>\r\n                  修改成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=payset.php\">";
    } else {
        echo "alert-danger\">\r\n                    <button type=\"button\" class=\"close\">\r\n                      <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>\r\n                  修改失败！" . $DB->error();
    }
    echo '</div>';
    echo '<style>#payset{display: none;}</style>';
}
$params = array('app_id' => $row['partner'], 'method' => 'user.info', 'format' => 'json', 'charset' => 'utf-8', 'sign_type' => 'md5', 'timestamp' => date('Y-m-d H:i:s'), 'version' => 1);
$sign = sign($params, $row['alikey']);
$params['sign'] = $sign;
$res = http($params);
$html = json_decode($res, true);
$money = $html['data']['money'];
echo " <div id=\"payset\" class=\"row\">\r\n                <div class=\"col-sm-12\">\r\n                    \r\n                  <div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">接口配置输入\r\n                    </div>\r\n                    <div class=\"panel-body\">\r\n\r\n      \r\n                <form  action=\"./payset.php?id=";
echo $id;
echo "\" method=\"post\" role=\"form\" class=\"form-horizontal\">\r\n                <input type=\"hidden\" name=\"type\" value=\"update\" />\r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\">AppID</label>\r\n                    <div class=\"col-sm-9\">\r\n                      <input type=\"text\" class=\"form-control\" id=\"field-1\" name=\"partner\" data-validate=\"required,number,min[16]\" value=\"";
echo $row['partner'];
echo "\" placeholder=\"以2088开头由16位纯数字组成的字符串，\">\r\n                      <p class=\"text-success\">查看地址：<a href=\"https://www.fakajun.com/api/token\">点我进入</a></p>\r\n                    </div>\r\n                  </div>  \r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\">AppKEY</label>\r\n                    <div class=\"col-sm-9\">\r\n                        <input type=\"text\" class=\"form-control\" name=\"alikey\" data-validate=\"required,min[16]\" value=\"";
echo $row['alikey'];
echo "\" placeholder=\"由数字和字母组成的32位字符串\">\r\n                        <p class=\"text-success\">当前余额：";
echo $money;
echo " <br><a href=\"https://www.fakajun.com/user/withdraw\">前往提现</a></p>\r\n                    </div>\r\n                  </div>\r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\">网站网址</label>\r\n                    <div class=\"col-sm-9\">\r\n                        <input type=\"text\" class=\"form-control\" name=\"url\" data-validate=\"required\" value=\"";
echo $row['url'];
echo "\" placeholder=\"\">\r\n                        <p class=\"text-success\">请直接输入http://ip+端口即可</p>\r\n                    </div>\r\n                  </div>\r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\"></label>\r\n                    <div class=\"col-sm-9\">\r\n                      <button type=\"submit\" type=\"button\" class=\"btn btn-info btn-block\">设置</button>\r\n                    </div>\r\n                  </div>\r\n                  \r\n                </form>\r\n                      \r\n                    </div>\r\n                  \r\n                  </div>\r\n                    \r\n                </div>\r\n            </div>\r\n   \r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n";
include 'copy.php';
function http($params = array())
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.fakajun.com/gateway.do');
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    $res = curl_exec($ch);
    return $res;
}
function sign($params, $app_key)
{
    $para_filter = array();
    while (true) {
        if (!each($params)) {
            list($key, $val) = each($params);
            ksort($para_filter);
            reset($para_filter);
            $arg = '';
            while (true) {
                if (!each($para_filter)) {
                    list($key, $val) = each($para_filter);
                    $arg = substr($arg, 0, count($arg) - 2);
                    if (get_magic_quotes_gpc()) {
                        $arg = stripslashes($arg);
                    }
                    $string = $arg . $app_key;
                    return strtoupper(md5($string));
                }
                if (!is_array($val)) {
                    $arg .= $key . '=' . $val . '&';
                }
            }
        }
        if (!($key == 'sign' || $key == 'sign_type' || $val == '')) {
            $para_filter[$key] = $params[$key];
        }
    }
}