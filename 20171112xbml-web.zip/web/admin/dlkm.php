<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "\r\n               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>代理管理</h1>\r\n                                <div class=\"options\"> <div class=\"btn-group\">\r\n                                    <a href=\"#\" class=\"btn btn-primary\"><i class=\"fa fa-cog\"></i></a>\r\n                                    <a href=\"#\" class=\"btn btn-primary dropdown-toggle\" data-toggle=\"dropdown\"><span class=\"caret\"></span></a>\r\n                                    <ul class=\"dropdown-menu\" role=\"menu\">\r\n                                        <li> <a data-target=\"#addkm\" data-toggle=\"modal\">生成</a></li>\r\n                                        <li>   <a href=\"dlkm.php?my=qk\" onclick=\"return confirm(\\'你确实要清空吗？\\');\">清空</a></li>\r\n                                    </ul>\r\n                                </div>\r\n</div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n";
$my = isset($_GET['my']) ? $_GET['my'] : null;
if ($my == 'add') {
    $kind = 2;
    $num = intval($_POST['num']);
    $value = intval($_POST['value']);
    echo "<div class=\"list-group list-group-minimal\">\r\n                                        <li class=\"list-group-item list-group-item-success\">成功生成以下卡密</li>";
    $i = 0;
    while (!($i >= $num)) {
        $km = getkm(18);
        $sql = $DB->query('insert into `auth_kms` (`kind`,`km`,`value`,`addtime`) values (\'' . $kind . '\',\'' . $km . '\',\'' . $value . '\',\'' . $date . '\')');
        if ($sql) {
            echo '<li class=\'list-group-item\'>' . $km . '</li>';
        }
        ($i += 1) + -1;
    }
    echo '<a href="./dlkm.php" class="list-group-item active"><i class="fa fa-mail-reply"></i> 返回卡密列表</a>';
} elseif ($my == 'del') {
    echo '<div class="alert';
    $id = daddslashes($_GET['id']);
    $sql = $DB->query('DELETE FROM auth_kms WHERE id=\'' . $id . '\'');
    if ($sql) {
        echo " alert-success\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=dlkm.php\">";
    } else {
        echo " alert-danger\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除失败！";
    }
    echo '</div>';
} elseif ($my == 'qk') {
    echo "<div class=\"alert alert-warning\">\r\n                                        <button type=\"button\" class=\"close\" data-dismiss=\"alert\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span></button>\r\n您确认要清空所有卡密吗？清空后无法恢复！</div><a href=\"./dlkm.php?my=qk2\" class=\"btn btn-danger\">确定</a>\r\n<a href=\"javascript:history.back();\" class=\"btn btn-success\">返回</a></div></div>";
} elseif ($my == 'qk2') {
    echo '<div class="alert';
    if ($DB->query('DELETE FROM auth_kms WHERE kind=\'2\'') == true) {
        echo " alert-success\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>清空成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=dlkm.php\">";
    } else {
        echo " alert-danger\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>清空失败！";
    }
    echo '</div>';
} else {
    if (isset($_GET['kw'])) {
        if ($_GET['type'] == 1) {
            $km = daddslashes($_GET['kw']);
            $sql = ' `km`=\'' . $km . '\' and kind=2';
            $numrows = $DB->count('SELECT count(*) from auth_kms WHERE' . $sql);
            $con = '包含 ' . $_GET['kw'] . ' 的共有 ' . $numrows . ' 个卡密';
        } elseif ($_GET['type'] == 2) {
            $sql = ' `user`=\'' . $_GET['kw'] . '\' and kind=2';
            $numrows = $DB->count('SELECT count(*) from auth_kms WHERE' . $sql);
            $con = '包含 ' . $_GET['kw'] . ' 的共有 ' . $numrows . ' 个卡密';
        }
    } else {
        $numrows = $DB->count('SELECT count(*) from auth_kms WHERE kind=2');
        $sql = ' kind=2';
        $con = '平台共有 ' . $numrows . ' 个代理余额卡密';
    }
    echo "<div class=\"row\">\r\n    <div class=\"col-md-12\">\r\n        <div class=\"panel panel-default\">\r\n            <div class=\"panel-heading\">\r\n                <h2>";
    echo $con;
    echo "</h2>\r\n            </div>\r\n            <div class=\"panel-body panel-no-padding\"> <div class=\"table-responsive\">\r\n                <table id=\"example\" class=\"table table-bordered table-fixed-header m0\" cellspacing=\"0\" width=\"100%\">\r\n                    <thead>\r\n                        <tr>\r\n                          <th>序号</th>\r\n\t                                        <th>卡密</th>\r\n\t                                        <th>状态</th>\r\n\t                                        <th>金额</th>\r\n\t                                        <th>添加时间</th>\r\n\t                                        <th>使用时间</th>\r\n\t                                        <th>操作</th>\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n                    ";
    $pagesize = 15;
    $pages = intval($numrows / $pagesize);
    if ($numrows % $pagesize) {
        ($pages += 1) + -1;
    }
    if (isset($_GET['page'])) {
        $page = intval($_GET['page']);
    } else {
        $page = 1;
    }
    $offset = $pagesize * ($page - 1);
    $rs = $DB->query('SELECT * FROM auth_kms WHERE' . $sql . ' order by id desc limit ' . $offset . ',' . $pagesize);
    while ($res = $DB->fetch($rs)) {
        if ($res['isuse'] == 1) {
            $isuse = '<span class="badge badge-info">使用者:' . $res['user'] . '</span>';
        } elseif ($res['isuse'] == 0) {
            $isuse = '<span class="badge badge-secondary">未使用</span>';
        }
        if ($res['isuse'] == 1) {
            $del = '<button class="btn btn-xs btn-gray disabled">已经使用</button>';
        } elseif ($res['isuse'] == 0) {
            $del = '<a href="./dlkm.php?my=del&id=' . $res['id'] . '" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要删除此卡密吗？\');">删除</a>';
        }
        echo '<tr><th><span class="co-name">' . $res['id'] . '</span></th><td>' . $res['km'] . '</td><td>' . $isuse . '</td><th>' . number_format($res['value'], 2) . '</th><td>' . $res['addtime'] . '</td><td>' . $res['usetime'] . '</td><td>' . $del . '</td></tr>';
    }
    echo "                                      </tbody>\r\n                                  </table>\r\n                       </div>\r\n                      \r\n                      <div class=\"panel-footer\">\r\n                      <div class=\"row\">\r\n                      <div class=\"col-sm-6\">\r\n                 \r\n               \r\n                      </div>\r\n                      <div class=\"col-sm-6\">\r\n                      <div class=\"dataTables_paginate paging_bootstrap\" id=\"example_paginate\">\r\n                       ";
    echo '<ul class="pagination pull-right m0">';
    $first = 1;
    $prev = $page - 1;
    $next = $page + 1;
    $last = $pages;
    if ($page > 1) {
        echo '<li class="previous disabled"><a href="daili.php?page=' . $first . $link . '">首页</a></li>';
    } else {
        echo '<li class="previous disabled"><a>首页</a></li>';
    }
    $i = 1;
    while (!($i >= $page)) {
        echo '<li class="active"><a href="daili.php?page=' . $i . $link . '">' . $i . '</a></li>';
        ($i += 1) + -1;
    }
    echo '<li  class="active"><a>' . $page . '</a></li>';
    $i = $page + 1;
    while (!($i > $pages)) {
        echo '<li><a href="daili.php?page=' . $i . $link . '">' . $i . '</a></li>';
        ($i += 1) + -1;
    }
    echo '';
    if (!($page >= $pages)) {
        echo '<li class="next disabled"><a href="daili.php?page=' . $last . $link . '">尾页</a></li>';
    } else {
        echo '<li class="next disabled"><a>尾页</a></li>';
    }
    echo '</ul>';
}
echo "                      </div>\r\n                      </div>\r\n                      </div>\r\n                      </div>\r\n\r\n            </div>\r\n        </div>\r\n    </div><div class=\"modal fade\" id=\"addkm\" role=\"dialog\" tabindex=\"-1\" aria-labelledby=\"addkm\" aria-hidden=\"true\">\r\n<div class=\"modal-dialog\">\r\n<div class=\"modal-content\">\r\n<div class=\"modal-header\">\r\n<form action=\"dlkm.php?my=add\" method=\"POST\" class=\"form-inline\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"modal\"><i class=\"pci-cross pci-circle\"></i></button>\r\n<h4 class=\"modal-title\">生成卡密</h4>\r\n</div>\r\n<br>\r\n<div class=\"panel-body\">\r\n   <div class=\"col-md-2\"><label>卡密数量</label></div>\r\n   <div class=\"col-md-12\">\r\n<div class=\"form-group\">\r\n<input type=\"text\" class=\"form-control\" name=\"num\" placeholder=\"卡密数量\" data-validate=\"required,number,min[1]\">\r\n</div>\r\n</div>\r\n</br>\r\n  <div class=\"col-md-2\"><label>面值金额</label></div>\r\n   <div class=\"col-md-12\">\r\n\r\n  <div class=\"form-group\">\r\n    <input type=\"text\" class=\"form-control\" name=\"value\" placeholder=\"面值金额\" data-validate=\"required,number,min[1]\">\r\n  </div>\r\n</div>\r\n  </br>\r\n </br>\r\n  <div class=\"col-md-12\">\r\n<div class=\"modal-footer\">\r\n<input type=\"submit\" value=\"生成\" class=\"btn btn-primary\"/>\r\n</div></div>\r\n</form>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n                            </div> <!-- .container-fluid -->\r\n                        </div> <!-- #page-content -->\r\n                    </div>\r\n";
include 'copy.php';
function getkm($len = 18)
{
    $str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $strlen = strlen($str);
    $randstr = '';
    $i = 0;
    while (true) {
        if ($i >= $len) {
            return $randstr;
        }
        $randstr .= $str[mt_rand(0, $strlen - 1)];
        ($i += 1) + -1;
    }
}