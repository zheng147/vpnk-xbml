<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>操作记录</h1>\r\n                                <div class=\"options\"><form role=\"form\" class=\"form-inline\">\r\n                      <a href=\"log.php?my=qk2\" class=\"btn btn-danger\"  onclick=\"if(!confirm('你确实清空吗？')){return false;}\">清空</a>\r\n                      </form>\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n";
$my = isset($_GET['my']) ? $_GET['my'] : null;
if ($my == 'del') {
    echo '<div class="alert';
    $id = $_GET['id'];
    $sql = $DB->query('DELETE FROM `auth_log` WHERE id=\'' . $id . '\'');
    if ($sql) {
        echo " alert-success\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=log.php\"";
    } else {
        echo " alert-danger\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除失败！";
    }
    echo '</div>';
} elseif ($my == 'qk2') {
    echo '<div class="alert';
    if ($DB->query('DELETE FROM auth_log WHERE 1') == true) {
        echo " alert-success\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>清空成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=log.php\"";
    } else {
        echo " alert-danger\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>清空失败！";
    }
    echo '</div>';
} else {
    $numrows = $DB->count('SELECT count(*) from `auth_log` WHERE 1');
    $sql = ' 1';
    $con = '平台共有 ' . $numrows . ' 个记录';
    echo "            <div class=\"row\">\r\n                <div class=\"col-sm-12\">\r\n                  <div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">";
    echo $con;
    echo "                    </div>\r\n                    <div class=\"panel-body panel-no-padding\">\r\n                      <div class=\"table-responsive\">\r\n                      \r\n                                  <table cellspacing=\"0\" class=\"table table-small-font table-bordered\">\r\n                                      <thead>\r\n                                          <tr>\r\n                                              <th>类型</th>\r\n                                              <th data-priority=\"1\">事件内容</th>\r\n                                              <th data-priority=\"3\">操作时间</th>\r\n                                              <th data-priority=\"6\">操作</th>\r\n                                          </tr>\r\n                                      </thead>\r\n                                      <tbody>\r\n                                            ";
    $pagesize = 30;
    $pages = intval($numrows / $pagesize);
    if ($numrows % $pagesize) {
        ($pages += 1) + -1;
    }
    if (isset($_GET['page'])) {
        $page = intval($_GET['page']);
    } else {
        $page = 1;
    }
    $offset = $pagesize * ($page - 1);
    $rs = $DB->query('SELECT * FROM `auth_log` WHERE' . $sql . ' order by id desc limit ' . $offset . ',' . $pagesize);
    while ($res = $DB->fetch($rs)) {
        echo "                                            <tr>\r\n                                            <th><span class=\"co-name\">";
        echo $res['action'];
        echo "</span></th>\r\n                                            <td>";
        echo $res['msg'];
        echo "</td>\r\n                                            <td>";
        echo $res['time'];
        echo "</td>\r\n                                            <td><a href=\"./log.php?my=del&id=";
        echo $res['id'];
        echo "\" class=\"btn btn-xs btn-danger\" onclick=\"if(!confirm('你确实要删除此记录吗？')){return false;}\">删除</a></td>\r\n                                            </tr>\r\n                                            ";
    }
    echo " \r\n                                      </tbody>\r\n                                  </table>\r\n                      \r\n                      </div></div> </div>\r\n                      \r\n                      ";
    echo '<ul class="pagination pagination-sm">';
    $first = 1;
    $prev = $page - 1;
    $next = $page + 1;
    $last = $pages;
    if ($page > 1) {
        echo '<li><a href="log.php?page=' . $first . $link . '">首页</a></li>';
        echo '<li><a href="log.php?page=' . $prev . $link . '">&laquo;</a></li>';
    } else {
        echo '<li class="disabled"><a>首页</a></li>';
        echo '<li class="disabled"><a>&laquo;</a></li>';
    }
    $i = 1;
    while (!($i >= $page)) {
        echo '<li><a href="log.php?page=' . $i . $link . '">' . $i . '</a></li>';
        ($i += 1) + -1;
    }
    echo '<li class="disabled"><a>' . $page . '</a></li>';
    $i = $page + 1;
    while (!($i > $pages)) {
        echo '<li><a href="log.php?page=' . $i . $link . '">' . $i . '</a></li>';
        ($i += 1) + -1;
    }
    echo '';
    if (!($page >= $pages)) {
        echo '<li><a href="log.php?page=' . $next . $link . '">&raquo;</a></li>';
        echo '<li><a href="log.php?page=' . $last . $link . '">尾页</a></li>';
    } else {
        echo '<li class="disabled"><a>&raquo;</a></li>';
        echo '<li class="disabled"><a>尾页</a></li>';
    }
    echo '</ul>';
}
echo "                      \r\n                    </div>\r\n                    \r\n                </div> </div>\r\n            </div>\r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n";
include 'copy.php';