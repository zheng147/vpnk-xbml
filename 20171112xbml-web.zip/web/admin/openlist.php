<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo " <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading mb0\">\r\n                                <h1>线路列表</h1>\r\n                                <div class=\"options\">\r\n    <div class=\"btn-toolbar\">\r\n         <a href=\"open.php\" class=\"btn btn-primary\">添加线路</a>\r\n    </div>\r\n</div>\r\n                            </div>\r\n                            <div class=\"page-tabs\">\r\n                                <ul class=\"nav nav-tabs\">\r\n                                    \r\n<li class=\"active\"><a data-toggle=\"tab\" href=\"#details\">全部</a></li>\r\n<li><a data-toggle=\"tab\" href=\"#meta\">移动</a></li>\r\n<li><a data-toggle=\"tab\" href=\"#meta2\">联通</a></li>\r\n<li><a data-toggle=\"tab\" href=\"#meta3\">电信</a></li>\r\n\r\n                                </ul>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n                            ";
$my = isset($_GET['my']) ? $_GET['my'] : null;
if ($my == 'del') {
    echo '<div class="alert';
    $id = $_GET['id'];
    $sql = $DB->query('DELETE FROM `xbml_article` WHERE id=\'' . $id . '\'');
    if ($sql) {
        echo " alert-success\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=openlist.php\">";
    } else {
        echo " alert-danger\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除失败！";
    }
    echo '</div><style>.tab-pane{display: none;}</style>';
} else {
    if (!empty($_GET['kw'])) {
        $sql = ' `iuser`=\'' . $_GET['kw'] . '\'';
        $numrows = $DB->count('SELECT count(*) from `xbml_article` WHERE' . $sql);
        $con = '包含 ' . $_GET['kw'] . ' 的共有 ' . $numrows . ' 个线路';
    } else {
        $numrows = $DB->count('SELECT count(*) from `xbml_article` WHERE 1');
        $sql = ' 1';
        $con = '平台共有 ' . $numrows . ' 个线路';
    }
    echo "<div id=\"openlist\" class=\"row\">\r\n<div class=\"tab-content\">\r\n  <div class=\"tab-pane active\" id=\"details\">\r\n        <div class=\"tab-pane active\" id=\"details\">\r\n            <div class=\"col-md-12\">\r\n\r\n<div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">";
    echo $con;
    echo "                    </div>\r\n                    <div class=\"panel-body panel-no-padding\">\r\n                      <div class=\"table-responsive\">\r\n                      \r\n                                  <table cellspacing=\"0\" class=\"table table-bordered table-fixed-header m0\">\r\n                                      <thead>\r\n                                          <tr>\r\n                                            <th>线路ID</th>\r\n                                            <!--th data-priority=\"1\">线路类型</th-->\r\n                                            <th data-priority=\"3\">名称</th>\r\n                                            <th data-priority=\"6\">添加时间</th>\r\n                                            <th data-priority=\"6\">操作</th>\r\n                                          </tr>\r\n                                      </thead>\r\n                                      <tbody>\r\n                                        ";
    $pagesize = 10;
    $pages = intval($numrows / $pagesize);
    if ($numrows % $pagesize) {
        ($pages += 1) + -1;
    }
    if (isset($_GET['page'])) {
        $page = intval($_GET['page']);
    } else {
        $page = 1;
    }
    $offset = $pagesize * ($page - 1);
    $rs = $DB->query('SELECT * FROM `xbml_article` WHERE' . $sql . ' order by id desc limit ' . $offset . ',' . $pagesize);
    while ($res = $DB->fetch($rs)) {
        echo "                                        <tr>\r\n                                        <th><span class=\"co-name\">";
        echo $res['id'];
        echo "</span></th>\r\n                                        <!--td>";
        echo $category[$res['category_id']];
        echo "</td-->\r\n                                        <td>";
        echo $res['title'];
        echo "</td>\r\n                                        \r\n                                        <td>";
        echo date('Y-m-d', $res['timeline']);
        echo "</td>\r\n                                        <td><a class=\"btn btn-xs btn-success\" href=\"./down.php?id=";
        echo $res['id'];
        echo "\">下载</a>\r\n                                        <a class=\"btn btn-xs btn-info\" href=\"./lineset.php?id=";
        echo $res['id'];
        echo '">配置</a>&nbsp;<a href="./openlist.php?my=del&id=';
        echo $res['id'];
        echo "\" class=\"btn btn-xs btn-danger\" onclick=\"if(!confirm('你确实要删除此线路吗？')){return false;}\">删除</a>&nbsp;</td>\r\n                                        </tr>\r\n                                        ";
    }
    echo "                                      </tbody>\r\n                                  </table>\r\n                      \r\n                      </div>  </div></div>\r\n                      \r\n                      ";
    echo '<ul class="pagination pagination-sm">';
    $first = 1;
    $prev = $page - 1;
    $next = $page + 1;
    $last = $pages;
    if ($page > 1) {
        echo '<li><a href="openlist.php?page=' . $first . $link . '">首页</a></li>';
        echo '<li><a href="openlist.php?page=' . $prev . $link . '">&laquo;</a></li>';
    } else {
        echo '<li class="disabled"><a>首页</a></li>';
        echo '<li class="disabled"><a>&laquo;</a></li>';
    }
    $i = 1;
    while (!($i >= $page)) {
        echo '<li><a href="openlist.php?page=' . $i . $link . '">' . $i . '</a></li>';
        ($i += 1) + -1;
    }
    echo '<li class="disabled"><a>' . $page . '</a></li>';
    $i = $page + 1;
    while (!($i > $pages)) {
        echo '<li><a href="openlist.php?page=' . $i . $link . '">' . $i . '</a></li>';
        ($i += 1) + -1;
    }
    echo '';
    if (!($page >= $pages)) {
        echo '<li><a href="openlist.php?page=' . $next . $link . '">&raquo;</a></li>';
        echo '<li><a href="openlist.php?page=' . $last . $link . '">尾页</a></li>';
    } else {
        echo '<li class="disabled"><a>&raquo;</a></li>';
        echo '<li class="disabled"><a>尾页</a></li>';
    }
    echo '</ul>';
}
echo " </div> </div> </div> \r\n\r\n <div class=\"tab-pane\" id=\"meta\">\r\n                       <div class=\"col-md-12\">\r\n\r\n                  <div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">移动线路列表\r\n                    </div> <div class=\"panel-body panel-no-padding\">\r\n                      <div class=\"table-responsive\">\r\n                                  <table cellspacing=\"0\" class=\"table table-small-font table-bordered\">\r\n                                      <thead>\r\n                                          <tr>\r\n                                            <th>线路ID</th>\r\n                                            <!--th data-priority=\"1\">线路类型</th-->\r\n                                            <th data-priority=\"3\">名称</th>\r\n                                            <th data-priority=\"6\">添加时间</th>\r\n                                            <!--th data-priority=\"6\">添加时间</th-->\r\n                                            <th data-priority=\"6\">操作</th>\r\n                                          </tr>\r\n                                      </thead>\r\n                                      <tbody>\r\n                                        ";
$rs = $DB->query('SELECT * FROM `xbml_article` WHERE  `category_id` = 1 ');
while (true) {
    $res = $DB->fetch($rs);
    if (!$DB->fetch($rs)) {
        echo "                                      </tbody>\r\n                                  </table>\r\n                      </div>\r\n                  </div></div></div></div>\r\n\r\n                   <div class=\"tab-pane\" id=\"meta2\">\r\n                       <div class=\"col-md-12\">\r\n                  <div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">联通线路列表\r\n                    </div> <div class=\"panel-body panel-no-padding\">\r\n                      <div class=\"table-responsive\">\r\n                                  <table cellspacing=\"0\" class=\"table table-small-font table-bordered\">\r\n                                      <thead>\r\n                                          <tr>\r\n                                            <th>线路ID</th>\r\n                                            <!--th data-priority=\"1\">线路类型</th-->\r\n                                            <th data-priority=\"3\">名称</th>\r\n                                            <th data-priority=\"6\">添加时间</th>\r\n                                            <!--th data-priority=\"6\">添加时间</th-->\r\n                                            <th data-priority=\"6\">操作</th>\r\n                                          </tr>\r\n                                      </thead>\r\n                                      <tbody>\r\n                                        ";
        $rs = $DB->query('SELECT * FROM `xbml_article` WHERE  `category_id` = 2 ');
        while (true) {
            $res = $DB->fetch($rs);
            if (!$DB->fetch($rs)) {
                echo "                                      </tbody>\r\n                                  </table>\r\n                      </div>\r\n                  </div> </div> </div> </div>\r\n                  <div class=\"tab-pane\" id=\"meta3\">\r\n                       <div class=\"col-md-12\">\r\n                  <div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">电信线路列表\r\n                    </div> <div class=\"panel-body panel-no-padding\">\r\n                      <div class=\"table-responsive\">\r\n                                  <table cellspacing=\"0\" class=\"table table-small-font table-bordered\">\r\n                                      <thead>\r\n                                          <tr>\r\n                                            <th>线路ID</th>\r\n                                            <!--th data-priority=\"1\">线路类型</th-->\r\n                                            <th data-priority=\"3\">名称</th>\r\n                                            <th data-priority=\"6\">添加时间</th>\r\n                                            <!--th data-priority=\"6\">添加时间</th-->\r\n                                            <th data-priority=\"6\">操作</th>\r\n                                          </tr>\r\n                                      </thead>\r\n                                      <tbody>\r\n                                        ";
                $rs = $DB->query('SELECT * FROM `xbml_article` WHERE  `category_id` = 3 ');
                while (true) {
                    $res = $DB->fetch($rs);
                    if (!$DB->fetch($rs)) {
                        echo "                                      </tbody>\r\n                                  </table>\r\n                      </div>\r\n                  </div>\r\n                </div> </div> </div>\r\n                \r\n              </div>\r\n            </div></div></div>\r\n\r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n";
                        include 'copy.php';
                        return null;
                    }
                    echo "                                        <tr>\r\n                                        <th><span class=\"co-name\">";
                    echo $res['id'];
                    echo "</span></th>\r\n                                        <!--td>";
                    echo $category[$res['category_id']];
                    echo "</td-->\r\n                                        <td>";
                    echo $res['title'];
                    echo "</td>\r\n                                        <td>";
                    echo date('Y-m-d', $res['timeline']);
                    echo "</td>\r\n                                        <td><a class=\"btn btn-xs btn-success\" href=\"./down.php?id=";
                    echo $res['id'];
                    echo "\">下载</a>\r\n                                        <a class=\"btn btn-xs btn-info\" href=\"./lineset.php?id=";
                    echo $res['id'];
                    echo '">配置</a>&nbsp;<a href="./openlist.php?my=del&id=';
                    echo $res['id'];
                    echo "\" class=\"btn btn-xs btn-danger\" onclick=\"if(!confirm('你确实要删除此线路吗？')){return false;}\">删除</a>&nbsp;</td>\r\n                                        </tr>\r\n                                        ";
                }
            }
            echo "                                        <tr>\r\n                                        <th><span class=\"co-name\">";
            echo $res['id'];
            echo "</span></th>\r\n                                        <!--td>";
            echo $category[$res['category_id']];
            echo "</td-->\r\n                                        <td>";
            echo $res['title'];
            echo "</td>\r\n                                       <td>";
            echo date('Y-m-d', $res['timeline']);
            echo "</td>\r\n                                        <td><a class=\"btn btn-xs btn-success\" href=\"./down.php?id=";
            echo $res['id'];
            echo "\">下载</a>\r\n                                        <a class=\"btn btn-xs btn-info\" href=\"./lineset.php?id=";
            echo $res['id'];
            echo '">配置</a>&nbsp;<a href="./openlist.php?my=del&id=';
            echo $res['id'];
            echo "\" class=\"btn btn-xs btn-danger\" onclick=\"if(!confirm('你确实要删除此线路吗？')){return false;}\">删除</a>&nbsp;</td>\r\n                                        </tr>\r\n                                        ";
        }
    }
    echo "                                        <tr>\r\n                                        <th><span class=\"co-name\">";
    echo $res['id'];
    echo "</span></th>\r\n                                        <!--td>";
    echo $category[$res['category_id']];
    echo "</td-->\r\n                                        <td>";
    echo $res['title'];
    echo "</td>\r\n                                       <td>";
    echo date('Y-m-d', $res['timeline']);
    echo "</td>\r\n                                        <td><a class=\"btn btn-xs btn-success\" href=\"./down.php?id=";
    echo $res['id'];
    echo "\">下载</a>\r\n                                        <a class=\"btn btn-xs btn-info\" href=\"./lineset.php?id=";
    echo $res['id'];
    echo '">配置</a>&nbsp;<a href="./openlist.php?my=del&id=';
    echo $res['id'];
    echo "\" class=\"btn btn-xs btn-danger\" onclick=\"if(!confirm('你确实要删除此线路吗？')){return false;}\">删除</a>&nbsp;</td>\r\n                                        </tr>\r\n                                        ";
}