<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>分站管理</h1>\r\n                                <div class=\"options\">\r\n                                <a href=\"website.php\" class=\"btn btn-info\">添加分站</a>\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n";
$my = isset($_GET['my']) ? $_GET['my'] : null;
if ($my == 'del') {
    echo '<div class="alert';
    $id = $_GET['id'];
    $sql = $DB->query('DELETE FROM `website` WHERE id=\'' . $id . '\'');
    if ($sql) {
        echo " alert-success\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=weblist.php\">";
    } else {
        echo " alert-danger\">\r\n                                        <button type=\"button\" class=\"close\">\r\n                                            <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                                            <span class=\"sr-only\">Close</span>\r\n                                        </button>删除失败！";
    }
    echo '</div>';
} else {
    if (!empty($_GET['kw'])) {
        $sql = ' `name`=\'' . $_GET['kw'] . '\'';
        $numrows = $DB->count('SELECT count(*) from `website` WHERE' . $sql);
        $con = '共有 ' . $numrows . ' 个站点';
    } else {
        $numrows = $DB->count('SELECT count(*) from `website` WHERE 1');
        $sql = ' 1';
        $con = '平台共有 ' . $numrows . ' 个站点';
    }
    echo "            <div class=\"row\">\r\n                <div class=\"col-sm-12\">\r\n                <div class=\"alert alert-info\">\r\n                    \r\n                    <strong>注意：</strong> 默认站点代号必须是xbml，请勿修改删除！\r\n                  </div>\r\n                  <div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">";
    echo $con;
    echo "                    <div class=\"panel-ctrls\"><form action=\"weblist.php\">\r\n                <label class=\"panel-ctrls-center\"> <input type=\"text\" class=\"form-control\" size=\"10\" name=\"kw\" placeholder=\"查询（记录）\"></label>\r\n                 </form></div>\r\n                    </div>\r\n                    <div class=\"panel-body panel-no-padding\">\r\n\t\t\t\t<div class=\"table-responsive\">                                  <table cellspacing=\"0\" class=\"table table-bordered table-fixed-header m0\">\r\n                                      <thead>\r\n                                          <tr>\r\n                                                <th>ID</th>\r\n                                                <th data-priority=\"1\">站点名称</th>\r\n                                                <th data-priority=\"1\">主机记录</th>\r\n                                                <th data-priority=\"3\">代理ID</th>\r\n                                                <th data-priority=\"6\">电话号码</th>\r\n                                                <th data-priority=\"6\">操作</th>\r\n                                          </tr>\r\n                                      </thead>\r\n                                      <tbody>\r\n                                          ";
    $pagesize = 30;
    $pages = intval($numrows / $pagesize);
    if ($numrows % $pagesize) {
        ($pages += 1) + -1;
    }
    if (isset($_GET['page'])) {
        $page = intval($_GET['page']);
    } else {
        $page = 1;
    }
    $offset = $pagesize * ($page - 1);
    $rs = $DB->query('SELECT * FROM `website` WHERE' . $sql . ' order by id desc limit ' . $offset . ',' . $pagesize);
    while ($res = $DB->fetch($rs)) {
        if ($res['id'] == 0) {
            $del = '<button class="btn btn-xs btn-gray disabled">此站点不可删除</button>';
        } else {
            $del = '<a href="./weblist.php?my=del&id=' . $res['id'] . '" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要删除此记录吗？\');">删除</a>';
        }
        echo "                                          <tr>\r\n                                          <th><span class=\"co-name\">";
        echo $res['id'];
        echo "</span></th>\r\n                                          <td>";
        echo $res['title'];
        echo "</td>\r\n                                          <td>";
        echo $res['name'];
        echo "</td>\r\n                                          <td>";
        echo $res['daili'];
        echo "</td>\r\n                                          <td>";
        echo $res['tel'];
        echo "</td>\r\n                                          <td><a class=\"btn btn-xs btn-info\" target=\"_blank\" href=\"/?i=";
        echo $res['name'];
        echo '">浏览</a>&nbsp;<a class="btn btn-xs btn-success" href="./webset.php?id=';
        echo $res['id'];
        echo '">配置</a>&nbsp;';
        echo $del;
        echo "</td>\r\n                                          </tr>\r\n                                          ";
    }
    echo "                                      </tbody>\r\n                                  </table></div>\r\n                      \r\n                      </div> </div>\r\n                      \r\n                      ";
    echo '<ul class="pagination pagination-sm">';
    $first = 1;
    $prev = $page - 1;
    $next = $page + 1;
    $last = $pages;
    if ($page > 1) {
        echo '<li><a href="fwqlist.php?page=' . $first . $link . '">首页</a></li>';
        echo '<li><a href="fwqlist.php?page=' . $prev . $link . '">&laquo;</a></li>';
    } else {
        echo '<li class="disabled"><a>首页</a></li>';
        echo '<li class="disabled"><a>&laquo;</a></li>';
    }
    $i = 1;
    while (!($i >= $page)) {
        echo '<li><a href="fwqlist.php?page=' . $i . $link . '">' . $i . '</a></li>';
        ($i += 1) + -1;
    }
    echo '<li class="disabled"><a>' . $page . '</a></li>';
    $i = $page + 1;
    while (!($i > $pages)) {
        echo '<li><a href="fwqlist.php?page=' . $i . $link . '">' . $i . '</a></li>';
        ($i += 1) + -1;
    }
    echo '';
    if (!($page >= $pages)) {
        echo '<li><a href="fwqlist.php?page=' . $next . $link . '">&raquo;</a></li>';
        echo '<li><a href="fwqlist.php?page=' . $last . $link . '">尾页</a></li>';
    } else {
        echo '<li class="disabled"><a>&raquo;</a></li>';
        echo '<li class="disabled"><a>尾页</a></li>';
    }
    echo '</ul>';
}
echo "                      \r\n                    </div>\r\n            </div>\r\n   \r\n                            </div> \r\n                        </div>\r\n                    </div>\r\n";
include 'copy.php';