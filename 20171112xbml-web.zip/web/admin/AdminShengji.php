<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "\r\n               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>升级推送</h1>\r\n                                <div class=\"options\">\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n                           ";
$require = true;
include '../app_api/shengji.php';
if ($_GET['act'] == 'update') {
    $content = "<?php /* by:凌一 QQ:863963860*/   \$data[\"status\"] = \"success\";\r\n    \$data[\"versionCode\"] = \"" . $_POST['versionCode'] . "\";//请在此输入新的版本号 当版本号大于用户正在使用的版本时 将会提示升级\r\n    \$data[\"url\"] = \"" . $_POST['url'] . "\"; //请在此填写下载地址\r\n    \$data[\"content\"] = \"" . $_POST['content'] . "\";//再此处填写更新说明\r\n    if(\$require != true){\r\n        die(json_encode(\$data));\r\n    }";
    file_put_contents('../app_api/shengji.php', $content);
    success_go('修改成功', 'AdminShengji.php?act=mod&id=' . $_GET['id']);
} else {
    $action = '?act=update';
    echo "<div class=\"main\">\r\n<div style=\"clear:both;height:10px;\"></div>\r\n<div class=\"alert alert-danger\">暂时不支持自动检测更新与强制更新</div>\r\n    <form class=\"form-horizontal\" role=\"form\" method=\"POST\" action=\"";
    echo $action;
    echo "\" onsubmit=\"return checkStr()\">\r\n    <div class=\"form-group\">\r\n        <label for=\"firstname\" class=\"col-sm-2 control-label\">版本号(大于APP时才能检测到更新)</label>\r\n        <div class=\"col-sm-10\">\r\n            <div class=\"col-sm-10\"><input class=\"form-control\" rows=\"10\" name=\"versionCode\" value=\"";
    echo $data['versionCode'];
    echo "\"></div>\r\n        </div>\r\n    </div>\r\n    \r\n    \r\n    \r\n    <div class=\"form-group\" >\r\n        <label for=\"firstname\" class=\"col-sm-2 control-label\">更新说明</label>\r\n        <div class=\"col-sm-10\">\r\n            <div class=\"col-sm-10\"><textarea class=\"form-control\" rows=\"10\" name=\"content\">";
    echo $data['content'];
    echo "</textarea></div>\r\n        </div>\r\n    </div> \r\n    <div class=\"form-group\" >\r\n        <label for=\"firstname\" class=\"col-sm-2 control-label\">APP下载连接</label>\r\n        <div class=\"col-sm-10\">\r\n            <div class=\"col-sm-10\"><input class=\"form-control\" rows=\"10\" name=\"url\" value=\"";
    echo $data['url'];
    echo "\"></div>\r\n        </div>\r\n    </div>\r\n    \r\n    <div class=\"form-group\">\r\n        <div class=\"col-sm-offset-2 col-sm-10\">\r\n        <div class=\"panel-body\">\r\n            <button type=\"submit\" class=\"btn btn-default\">提交数据</button>\r\n        </div></div>\r\n    </div>\r\n</form> \r\n    </div>\r\n    <script>\r\n    function checkStr(){\r\n        var title = \$('[name=\"title\"]').val();\r\n        var content = \$('[name=\"content\"]').val();\r\n        if(title == \"\" || content ==　\"\"){\r\n            alert(\"标题与内容不得为空\");\r\n            return false;\r\n        }\r\n        return true;\r\n    }\r\n    </script>\r\n";
}
echo "                            </div> \r\n                        </div>\r\n                    </div>\r\n";
include 'copy.php';
function success_go($msg, $url)
{
    echo "<div class=\"alert alert-success alert-dismissable\">\r\n            <button type=\"button\" class=\"close\" data-dismiss=\"alert\"\r\n                    aria-hidden=\"true\">\r\n                &times;\r\n            </button>\r\n            " . $msg . ',系统将在3秒后跳转。<a href="' . $url . "\">等不及了！</a>\r\n        </div> ";
    echo "<script>setTimeout(function(){\r\n            window.location.href=\"" . $url . "\";\r\n        },3000)</script>";
    return null;
}
function error_go($msg, $url)
{
    echo "<div class=\"alert alert-danger alert-dismissable\">\r\n            <button type=\"button\" class=\"close\" data-dismiss=\"alert\"\r\n                    aria-hidden=\"true\">\r\n                &times;\r\n            </button>\r\n            " . $msg . ',系统将在3秒后跳转。<a href="' . $url . "\">等不及了！</a>\r\n        </div> ";
    echo "<script>setTimeout(function(){\r\n            window.location.href=\"" . $url . "\";\r\n        },3000)</script>";
    return null;
}