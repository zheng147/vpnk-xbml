<?php /* by:凌一 QQ:863963860*/

include 'nav.php';
echo "               <div class=\"static-content-wrapper\">\r\n                    <div class=\"static-content\">\r\n                        <div class=\"page-content\">\r\n                            <div class=\"page-heading\">            \r\n                                <h1>服务器配置</h1>\r\n                                <div class=\"options\">\r\n                            </div>\r\n                            </div>\r\n                            <div class=\"container-fluid\">\r\n";
$id = daddslashes($_GET['id']);
echo "            <div class=\"row\">\r\n                <div class=\"col-sm-12\">\r\n                    \r\n                  <div class=\"panel panel-default\">\r\n                    <div class=\"panel-heading\">进行服务器编号为 ";
echo $id;
echo " 的配置\r\n                    </div>\r\n                    <div class=\"panel-body\">\r\n";
$row = $DB->get_row('select * from `auth_fwq` where id=\'' . $id . '\' limit 1');
if ($_POST['type'] == 'update') {
    echo '<div class="alert ';
    $fwqid = daddslashes($_POST['fwqid']);
    $name = daddslashes($_POST['name']);
    $ipport = daddslashes($_POST['ipport']);
    if ($DB->query('update `auth_fwq` set `id`=\'' . $fwqid . '\',`name`=\'' . $name . '\',`ipport`=\'' . $ipport . '\' where id=\'' . $id . '\'')) {
        echo "alert-success\">\r\n                    <button type=\"button\" class=\"close\">\r\n                      <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>\r\n                  修改成功！ - 3秒后自动跳转<meta http-equiv=\"refresh\" content=\"3;URL=fwqlist.php\">";
    } else {
        echo "alert-danger\">\r\n                    <button type=\"button\" class=\"close\">\r\n                      <span aria-hidden=\"true\"><a href=\"javascript:history.go(-1)\">×</a></span>\r\n                      <span class=\"sr-only\">Close</span>\r\n                    </button>\r\n                  修改失败！" . $DB->error();
    }
    echo '</div>';
    echo '<style>#fwqset{display: none;}</style>';
}
echo "      \r\n                <form id=\"fwqset\" action=\"./fwqset.php?id=";
echo $id;
echo "\" method=\"post\" role=\"form\" class=\"form-horizontal\">\r\n                <input type=\"hidden\" name=\"type\" value=\"update\" />\r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\">服务器ID</label>\r\n                    <div class=\"col-sm-9\">\r\n                      <input type=\"text\" class=\"form-control\" id=\"field-1\" placeholder=\"请输入服务器ID\" name=\"fwqid\" data-validate=\"required\" value=\"";
echo $row['id'];
echo "\">\r\n                    </div>\r\n                  </div>  \r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\">服务器名称</label>\r\n                    <div class=\"col-sm-9\">\r\n                        <input type=\"text\" class=\"form-control\" name=\"name\" data-validate=\"required\" value=\"";
echo $row['name'];
echo "\">\r\n                    </div>\r\n                  </div>\r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\">IP：端口</label>\r\n                    <div class=\"col-sm-9\">\r\n                        <input type=\"text\" class=\"form-control\" name=\"ipport\" data-validate=\"required\" value=\"";
echo $row['ipport'];
echo "\">\r\n                    </div>\r\n                  </div>\r\n                  <div class=\"form-group\">\r\n                    <label class=\"col-sm-2 control-label\"></label>\r\n                    <div class=\"col-sm-9\">\r\n                      <button type=\"submit\" type=\"button\" class=\"btn btn-info btn-block\">修改</button>\r\n                    </div>\r\n                  </div>\r\n                  \r\n                </form>\r\n                      \r\n                    </div>\r\n                  \r\n                  </div>\r\n                    \r\n                </div>\r\n            </div>\r\n   \r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n";
include 'copy.php';