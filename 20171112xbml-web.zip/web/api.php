<?php /* by:凌一 QQ:863963860*/

require 'api/Conf/api.inc.php';
if (is_file(ROOT . '360safe/360webscan.php')) {
    require_once ROOT . '360safe/360webscan.php';
}
$msg = 'http://sq.xbaicai.net/xianlu/msg.php';
$line = 'http://sq.xbaicai.net/xianlu/line.php';