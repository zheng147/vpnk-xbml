<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,user-scalable=no, initial-scale=1">
    <title>PigCms</title>
    <link rel="stylesheet" href="css/style.css">
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/idangerous.swiper.js"></script>
</head>
<body>
<div class="page" style="margin:0;">
    <div class="device">
        <a class="arrow-left" href="javascript:;"></a>
        <a class="arrow-right" href="javascript:;"></a>
        <div class="swiper-container">
            <div class="swiper-wrapper">
                <!-- 幻灯片 -->
                <a href="" class="swiper-slide">
                    <img src="images/slide1.png" alt="">
                </a>
                <a href="" class="swiper-slide">
                    <img src="images/slide2.png" alt="">
                </a>
                <a href="" class="swiper-slide">
                    <img src="images/slide3.png" alt="">
                </a>
                <a href="" class="swiper-slide">
                    <img src="images/slide4.png" alt="">
                </a>
            </div>
        </div>
        <div class="points">
            <span class="swiper-pagination-switch"></span>
        </div>
    </div>
    <div class="scrollNews">
        <div class="yy">
            <!-- 轮播通知 -->
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量(http://www.chlieg.cn/)
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏云流量专业流量之家、
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            欢迎使用华夏流量卫士、
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            只要加入我们即可让你随时随地看电影、
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            华夏流量卫士为您定制了各种套餐、
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            再也不用担心流量不够用了、
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            我们为客户定制低价流量套餐、
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            请记住我们的官方http://www.chlieg.cn
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            感谢您的支持、
                        </p>
                    </div>
                </a>
            </div>

        </div>
    </div>
    <div class="content" style="width:100%; min-height:350px;margin-top: -30px;">
        <div class="gun" style="width:100%; height:100px;">
            <div id="slides">
                <ul class="slides_container swiper-wrapper" id="ul1" style="">
                    <!-- 顶部栏目 -->
                    <li class="swiper-slide swiper-slide-visible" style="">
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon1.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>全部功能</h2>
                            <br>
                            Function Module</span>
                            </div>
                        </a>
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon2.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>流量购买</h2>
                            <br>
                            Product System</span>
                            </div>
                        </a>
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon3.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>旗下品牌</h2>
                            <br>
                            The solution</span>
                            </div>
                        </a>
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon4.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>售后顾问</h2>
                            <br>
                            Customer service system</span>
                            </div>
                        </a>
                    </li>
                    <li class="swiper-slide" style="">
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon5.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>待添加</h2>
                            </span>
                            </div>
                        </a>
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon6.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>待添加</h2>
                            </span>
                            </div>
                        </a>
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon7.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>待添加</h2>
                            </span>
                            </div>
                        </a>
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon8.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>待添加</h2>
                            </span>
                            </div>
                        </a>
                    </li>
                    <li class="swiper-slide" style="">
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon9.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>待添加</h2>
                            </span>
                            </div>
                        </a>
                    </li>
                </ul>
                <a href="javascript:;" class="prev"> prev </a>
                <a href="javascript:;" class="next" id="soso"> next </a>
            </div>
        </div>
        <ul class="neir" style="width:95%; margin-left:2%;border: rgba(37, 195, 137, 0) 1px solid;overflow:hidden; min-height:240px;padding-bottom: 80px;" id="ul2">
            <li class="active">
                <div class="newTit clearfix">
                    <div class="fr moreLink">
                        <a href="javascript:;">更多功能<i></i></a>
                        <ul>
                            <li><a href="javascript:;" onclick="tagsFilter($(this),'all')">全部功能</a></li>
                            <li><a href="javascript:;" onclick="tagsFilter($(this),'new')">最新功能</a></li>
                        </ul>
                    </div>
                    <h3>最新功能</h3>
                    <!-- 所有功能，这里的标题全部动态改变填充 -->
                </div>
                <div class="row" style="min-height: 330px;">
                    <!-- 所有功能 -->
                    <a href="<?php echo '?act=theme&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>" class="item_one" style="display: block;" data-type="all">
                        <img class="gntub" src="images/two1.png">
                        <div class="tet2">
                            <span>主题切换</span>
                        </div>
                    </a>
                    <a href="<?php echo '?act=top&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>" class="item_one" style="display: block;" data-type="all">
                        <img class="gntub" src="images/tu1.png">
                        <div class="tet2">
                            <span>流量排行</span>
                        </div>
                    </a>
                    <a href="<?php echo '?act=list_gg&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>" class="item_one" style="display: block;" data-type="all">
                        <img class="gntub" src="images/tu2.png">
                        <div class="tet2">
                            <span>消息通知</span>
                        </div>
                    </a>
                    <a href="<?php echo '?act=info&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>" class="item_one" style="display: block;" data-type="all">
                        <img class="gntub" src="images/two9.png">
                        <div class="tet2">
                            <span>使用记录</span>
                        </div>
                    </a>
                    <a href="<?php echo '?act=help&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>" class="item_one" style="display: block;" data-type="all">
                        <img class="gntub" src="images/zhu1.png">
                        <div class="tet2">
                            <span>客服中心</span>
                        </div>
                    </a>
                    <a href="<?php echo '?act=user_info&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>" class="item_one" style="display: block;" data-type="all">
                        <img class="gntub" src="images/two6.png">
                        <div class="tet2">
                            <span>个人中心</span>
                        </div>
                    </a>

                    <!--最新功能-->
                    <a href="html/help.html" class="item_one" style="display: block;" data-new="new">
                        <img class="gntub" src="images/tu3.png">
                        <div class="tet2">
                            <span>使用帮助</span>
                        </div>
                    </a>
                    <a href="javascript:void(0)" onclick="window.myObj.goUpdate()" class="item_one" style="display: block;" data-new="new">
                        <img class="gntub" src="images/two3.png">
                        <div class="tet2">
                            <span>检测更新</span>
                        </div>
                    </a>
                    <a href="javascript:void(0)" onclick="window.myObj.goLogin()" class="item_one" style="display: block;" data-new="new">
                        <img class="gntub" src="images/two2.png">
                        <div class="tet2">
                            <span>切换账号</span>
                        </div>
                    </a>
                    <a href="http://m.quankan.tv" class="item_one" style="display: block;" data-new="new">
                        <img class="gntub" src="images/two4.png">
                        <div class="tet2">
                            <span>全看视频</span>
                        </div>
                    </a>
                    <a href="http://1716dy.com" class="item_one" style="display: block;" data-new="new">
                        <img class="gntub" src="images/tu4.png">
                        <div class="tet2">
                            <span>逗逼羊</span>
                        </div>
                    </a>
                    <a href="http://ys.km.com/tv/" class="item_one" style="display: block;" data-new="new">
                        <img class="gntub" src="images/tu5.png">
                        <div class="tet2">
                            <span>影视大全</span>
                        </div>
                    </a>
                    </a>
                    <!--其他功能类 end-->
                </div>
                <div class="fixedBar">
                    <div class="SubLinks">
                        <ul>
                            <li><a href="javascript:;" onclick="tagsFilter($(this),'all')">全部功能</a></li>
                            <li><a href="javascript:;" onclick="tagsFilter($(this),'new')">最新功能</a></li>
                        </ul>
                        <span class="triangle"></span>
                    </div>
                    <a class="aClick" href="javascript:;"></a>
                </div>
            </li>
            <li class="pro">
                <div class="one_itme" id="li_two">
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/two1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">暂时没有提卡系统</h1>
                                <span>请联系客服购买流量！</span>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/two2.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">5G 流量卡</h1>
                                <span>30天使用期限 8元</span>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/two4.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">10G 流量卡</h1>
                                <span>30天试用期限 15元</span>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/two5.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">15G 流量卡</h1>
                                <span>30天试用期限 20元</span>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/two5.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">20G 流量卡</h1>
                                <span>30天试用期限 30元</span>
                            </div>
                        </div>
                    </a>
                    <a href="http://wpa.qq.com/msgrd?v=3&uin=707004625&site=qq&menu=yes">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/two5.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">联系客服</h1>
                                <span>请点击联系客服购买流量</span>
                            </div>
                        </div>
                    </a>

                </div>
            </li>
            <li class="pro">
                <div class="one_itme" id="li_three">
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/two6.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">华夏旗下流量</h1>
								<span>华夏SSR-VPN-云流量</span>
                            </div>
                        </div>
                    </a>
                    <a href="http://p.chlieg.cn">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/two6.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">华夏SSR免流流量</h1>
								<span>本流量为阿里云北京服务器</span>
                            </div>
                        </div>
                    </a>
                    <a href="http://ss.chlieg.cn">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/two6.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">华夏翻墙流量</h1>
								<span>本流量为日本东京服务器</span>
                            </div>
                        </div>
                    </a>
                   
                </div>
            </li>
            <li class="pro">
                <div class="one_itmelll" id="li_four">
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/two7.jpg">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">联系客服</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/two7.jpg">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">客服QQ：707004625</h1>
                            </div>
                        </div>
                    </a>
					<a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/two7.jpg">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">电话：135-8594-2566</h1>
                            </div>
                        </div>
                    </a>
                </div>
            </li>
            <li class="pro">
                <div class="one_itme" id="li_five">
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>华夏云流量</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>华夏云流量</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>华夏云流量</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>华夏云流量</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>华夏云流量</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>华夏云流量</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>华夏云流量</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>华夏云流量</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>华夏云流量</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>华夏云流量</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>华夏云流量</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>华夏云流量</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>华夏云流量</span>
                        </div>
                    </a>
                </div>
            </li>
            <li class="pro">
                <div>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/two9.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1sz" style="width: 96%;">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/two9.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1sz" style="width: 96%;">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/two9.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1sz" style="width: 96%;">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/two9.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1sz" style="width: 96%;">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/two9.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1sz" style="width: 96%;">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/two9.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1sz" style="width: 96%;">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                </div>
            </li>
            <li class="pro">
                <div class="one_itme" id="li_seven">
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">华夏云流量</h1>
                            </div>
                        </div>
                    </a>



                </div>
            </li>
            <li class="pro">
                <div class="one_itme" id="li_one">
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu.jpg">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1s">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu.jpg">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1s">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu.jpg">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1s">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu.jpg">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1s">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu.jpg">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1s">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu.jpg">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1s">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                </div>
            </li>
            <li class="pro">
                <div class="one_itme" id="li_nigth">
                    <a href="tel:0551-63474223">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu1.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="tel:0551-63474223">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu1.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                    <a href="tel:0551-63474223">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu1.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1">华夏云流量</h1>
                            </div>
                        </div>
                    </a>
                </div>
            </li>
        </ul>
    </div>
</div>
<div class="footer clearfix">
    <a href="13585942566"><i></i>电话咨询</a>
    <a href="http://wpa.qq.com/msgrd?v=3&uin=707004625&site=qq&menu=yes"><i></i>QQ咨询</a>
</div>
<script>
    var mySwiper = new Swiper('.swiper-container', {
        pagination: '.points',
        loop: true,
        autoplay: 3000,
        grabCursor: true,
        paginationClickable: true
    });
    $('.arrow-left').on('click',
            function(e) {
                e.preventDefault();
                mySwiper.swipePrev()
            });
    $('.arrow-right').on('click',
            function(e) {
                e.preventDefault();
                mySwiper.swipeNext()
            });
    var mySwiper2 = new Swiper('#slides', {
        pagination: false,
        paginationClickable: true,
    });
    $('.prev').on('click',
            function(e) {
                e.preventDefault();
                mySwiper2.swipePrev()
            });
    $('.next').on('click',
            function(e) {
                e.preventDefault();
                mySwiper2.swipeNext()
            });
    //tab切换
    window.onload = function() {
        var a=$("#slides a");
        var b=$(".neir>li");
        var c='active';
        tab(a,b,c);
    };
    function tab(a,b,c){
        var len=$(a);
        len.bind("click",function(){
            var index = 0;
            $(this).addClass(c).siblings().removeClass(c);
            index = len.index(this);
            $(b).eq(index).show().siblings().hide();
            return false;
        }).eq(0).trigger("click");
    }
    $(function(){
        $(".newTit .moreLink>a").click(function(){
            if($(this).hasClass('on')){
                $(this).removeClass('on').next().hide();
            }else{
                $(this).addClass('on').next().show();
            }
        });
        $(".fixedBar a.aClick").click(function() {
            $(".fixedBar .SubLinks").toggle();
            return false;
        });
    });
    $(".neir .row a[data-new=new]").show();//默认显示最新的项目
    function tagsFilter(obja,type){//obja是当前的a标签，type是项目类型从0-6，all,new,all是所有项目，new是最新的
           var oText=obja.text();
           var newTit=$('.newTit h3').text(oText);
           $(".item_one").hide();
           if(typeof type === 'number'){
           $(".neir .row a[data-type="+type+"]").show();
           }else if(type === 'all'){
             $(".item_one").show();
           }else if(type==='new'){
             $(".neir .row a[data-new=new]").show();
           }
           $(".fixedBar .SubLinks").hide();
           $(".newTit .moreLink>a").removeClass('on').next().hide();
           $("html,body").stop().animate({scrollTop:$(".newTit").offset().top},1000);
    }
//    function tagsFilter(obja,data){
//        var oText=obja.text();
//        var newTit=$('.newTit h3').text(oText);
//        var tokenn='yicms';
//        $.ajax({
//            type:"post",
//            url:"ajax地址",
//            dataType:"json",
//            data:{
//                info:data
//            },
//            success:function(sta){
//                // alert(sta);
//                $(".row").html(sta)
//                $(".fixedBar .SubLinks").hide();
//                $(".newTit .moreLink>a").removeClass('on').next().hide();
//                $("html,body").stop().animate({scrollTop:$(".newTit").offset().top},1000);
//            }
//        })
//    }
    $(function(){
        var $this = $(".scrollNews");
        var t=null;
        $this.hover(function(){
            clearInterval(t);
        },function(){
            t = setInterval(function(){
                scrollNews( $this );
            }, 4000 );
        }).trigger("mouseleave");
    });
    function scrollNews(obj){
        var $self = obj.find(".yy");
        var lineHeight = $self.find(".tongzhi").eq(0).height();
        $self.animate({"marginTop": -lineHeight +"px"}, 600 , function(){
            $self.css({marginTop:0}).find(".tongzhi").eq(0).appendTo($self);
        })
    }
</script>

</body>
</html>