<?php

   
    	function success_go($msg,$url){
		echo '<div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert"
                    aria-hidden="true">
                &times;
            </button>
            '.$msg.',系统将在3秒后跳转。<a href="'.$url.'">等不及了！</a>
        </div> ';
        echo '<script>setTimeout(function(){
        	window.location.href="'.$url.'";
        },3000)</script>';
	}
	function error_go($msg,$url){
		echo '<div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert"
                    aria-hidden="true">
                &times;
            </button>
            '.$msg.',系统将在3秒后跳转。<a href="'.$url.'">等不及了！</a>
        </div> ';
        echo '<script>setTimeout(function(){
        	window.location.href="'.$url.'";
        },3000)</script>';
	}
	
 	include('head.php');
	include('nav.php'); 
	$require = true;
	include("Splash.php");
 	if($_GET['act'] == 'update'){
		$content = '<?php	$data["status"] = "'.$_POST["status"].'";
	$data["url"] = "'.$_POST["url"].'"; //请在此填写下载地址
	';
		file_put_contents(R."/Splash.php",$content);
		success_go("修改成功",'AdminSplash.php?act=mod&id='.$_GET['id']);
		
	}else{
	
	$action = '?act=update';
	
		
 ?>
<div class="main">
<span class="label label-default">启动图设计</span>
<div style="clear:both;height:10px;"></div>
<div class="alert alert-danger">请保证您的图片尽可能的小！因为如果超过2秒APP无法全部加载图片，为了用户体验，就会放弃加载！</div>
	<form class="form-horizontal" role="form" method="POST" action="<?php echo $action?>" onsubmit="return checkStr()">
    <div class="form-group">
        <label for="firstname" class="col-sm-2 control-label">功能开关</label>
        <div class="col-sm-10">
            <div class="col-sm-10">
			<select name="status">
				<option value="error">关闭</option>
				<option value="success">开启</option>
			</select>
		【当前】<b style="color:red"><?php echo $data["status"]=="success" ? "已开启" :"已关闭";?></b>
        </div>
        </div>
    </div>
    
    
    
   
    <div class="form-group" >
        <label for="firstname" class="col-sm-2 control-label">启动图地址</label>
        <div class="col-sm-10">
            <div class="col-sm-10"><input class="form-control" rows="10" name="url" value="<?php echo $data["url"] ?>"></div>
        </div>
    </div>
    
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-default">提交数据</button>
        </div>
    </div>
</form> 
	</div>
	<script>
	function checkStr(){
		var title = $('[name="title"]').val();
		var content = $('[name="content"]').val();
		if(title == "" || content ==　""){
			alert("标题与内容不得为空");
			return false;
		}
		return true;
	}
	</script>
<?php
	}
	include('footer.php');
	
?>
