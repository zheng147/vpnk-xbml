
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="user-scalable=no,width=device-width">
    <meta name="baidu-site-verification" content="W8Wrhmg6wj" />
    <meta content="telephone=no" name="format-detection">
	<meta content="1" name="jfz_login_status">
    <script type="text/javascript" src="/www.jfz.com/static/js/common/record.origin.js"></script>
	<meta name="keywords" content="财富汇聚，价值成长，高端投资者俱乐部" />
<meta name="description" content="财富汇聚，价值成长，高端投资者俱乐部" />
<link rel="stylesheet" type="text/css" href="css/common2.css?v=1.2" />
<link rel="stylesheet" type="text/css" href="css/new_cfb.css?v=1.2" />
<script type="text/javascript" src="js/jquery.min1.js"></script>
<script type="text/javascript" src="js/jquery-1.7.2.js?v=1.2"></script>
<script type="text/javascript" src="js/global.js?v=1.2"></script>
<script type="text/javascript" src="js/common.v3.js?v=1.2"></script>
<script type="text/javascript" src="js/jweixin-1.0.0.js"></script>
<title>个人中心</title>
</head>
<body>


<script type="text/javascript">
    function close_a(){
        var obj=document.getElementById("div_none");
        obj.style.display="none";
    }
</script>
<script>var _jfz_paq = _jfz_paq || [];</script>
		<div data-content="0" id="jfz_wechat_bind_openId" style="display: none"></div>
<script>
    wx.config({
        debug: false,
        appId: 'wx46d763374191130c',
        timestamp: 1473834822,
        nonceStr: '7Tu5OVBeULfuTKRu',
        signature: '680f085ed94767775c56db17f98b1f7e33201cc1',
        jsApiList: ["checkJsApi","onMenuShareTimeline","onMenuShareAppMessage","onMenuShareQQ"]    });
</script><script>
    wx.ready(function(){
        //朋友圈        wx.onMenuShareTimeline({
            title: '财斧邦-互联网首选VIP私人银行',
            link: 'http://m.jinfuzi.com/wxcfb/cfbHome.html',
            imgUrl: 'http://jfz-static2.oss-cn-hangzhou.aliyuncs.com/edit/1442976529.jpeg',
            trigger: function (res) {},
            success: function (res) {
                            },
            cancel: function (res) {},
            fail: function (res) {}
        });
        //朋友
        wx.onMenuShareAppMessage({
            title: '财斧邦-互联网首选VIP私人银行',
            desc: '财富汇聚，价值成长，高端投资者俱乐部',
            link: 'http://m.jinfuzi.com/wxcfb/cfbHome.html',
            imgUrl: 'http://jfz-static2.oss-cn-hangzhou.aliyuncs.com/edit/1442976529.jpeg',
            type: 'link',
            dataUrl: '',
            trigger: function (res) {},
            success: function (res) {
            	            },
            cancel: function (res) {},
            fail: function (res) {}
        });
        //QQ
        wx.onMenuShareQQ({
            title: '财斧邦-互联网首选VIP私人银行',
            desc: '财富汇聚，价值成长，高端投资者俱乐部',
            link: 'http://m.jinfuzi.com/wxcfb/cfbHome.html',
            imgUrl: 'http://jfz-static2.oss-cn-hangzhou.aliyuncs.com/edit/1442976529.jpeg',
            trigger: function (res) {},
            success: function (res) {
            	            },
            cancel: function (res) {},
            fail: function (res) {}
        });
    });
    wx.error(function(res){});
</script><div class="wx_cfb_container wx_cfb_account_center_container">
	<div class="wx_cfb_account_center_wrap">
        <!--资产明细-->
        <div class="wx_cfb_ac_fund_detail">
            <div class="user_info clearfix">
                <div class="user_photo"><img src="http://m.jinfuzi.com/static2.0/img/cfb/mili.png"></div>
                <div class="user_txt">
                	<div class="p1">当前账号：<?php echo $res['iuser'];?></div>
                    <div class="p2">您的ID号：<?php echo $res['id']?></div>
                </div>
            </div>
            <div class="fund_info">
                <div class="kv_tb_list clearfix">
                    <div class="kv_item">
                        <span class="val"><?php echo round($res['maxll']/1024/1024);?> MB</span>
                        <span class="key">流量总额</span>
                    </div>
                    <div class="kv_item">
                        <span class="val"><?php echo round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024);?> MB</span>
                        <span class="key">剩余流量</span>
                    </div>
                    <div class="kv_item">
                        <span class="val"><?php echo round(($res['endtime']-time())/86400);?> 天</span>
                        <span class="key">到期时间</span>
                    </div>
                </div>
            </div>
        </div>
        <!--入口-->
        <div class="wx_cfb_entry_list">
            <div class="space_5"></div>
            <a href="" data-toggle="modal" data-target="#wxtipsDialog" class="entry_item clearfix">
                <div class="entry_name">
                    <span class="ui_ico_size_60 ui_entry_ico ui_entry_ico_1"></span>
                    <span class="name">到期时间</span>
                </div>
                <div class="entry_tips">
                    <span class="ui_entry_arrow"></span>
                    <span class="tips"><em class="num"><?php echo date('Y-m-d',$res['endtime']);?></em></span>
                </div>
            </a>
<!--            <a --><!-- class="entry_item entry_item_no_border clearfix">-->
<!--                <div class="entry_name">-->
<!--                    <span class="ui_ico_size_60 ui_entry_ico ui_entry_ico_2"></span>-->
<!--                    <span class="name">我的奖励</span>-->
<!--                </div>-->
<!--                <div class="entry_tips">-->
<!--                    <span class="ui_entry_arrow"></span>-->
<!--                    <span class="tips">可提现<em class="num">--><!----><!--</em>元</span>-->
<!--                </div>-->
<!--            </a>-->
            <div class="space_10"></div>
<!--            <a --><!-- class="entry_item clearfix">-->
<!--                <div class="entry_name">-->
<!--                    <span class="ui_ico_size_60 ui_entry_ico ui_entry_ico_3"></span>-->
<!--                    <span class="name">我的优惠券</span>-->
<!--                </div>-->
<!--                <div class="entry_tips">-->
<!--                    <span class="ui_entry_arrow"></span>-->
<!--                    <span class="tips">可使用<em class="num">--><!--</em>张</span>-->
<!--                </div>-->
<!--            </a>-->
            <a href="javascript:void(0)javascript:;" data-toggle="modal" data-target="#wxtipsDialog" class="entry_item clearfix">
                <div class="entry_name">
                    <span class="ui_ico_size_60 ui_entry_ico ui_entry_ico_4"></span>
                    <span class="name">我的投顾</span>
                </div>
                <div class="entry_tips">
                    <span class="ui_entry_arrow"></span>
                    <span class="tips">查看</span>
                </div>
            </a>
            <a href="javascript:void(0)/vip/wm-hdzx.html" class="entry_item entry_item_no_border clearfix">
                <div class="entry_name">
                    <span class="ui_ico_size_60 ui_entry_ico ui_entry_ico_5"></span>
                    <span class="name">活动中心</span>
                </div>
                <div class="entry_tips">
                    <span class="ui_entry_arrow"></span>
                    <span class="tips">查看</span>
                </div>
            </a>
            <div class="space_10"></div>
                        <a href="javascript:void(0)/wxcfb/cfbWealthCenter/changeAccount.html" class="entry_item entry_item_no_border clearfix">
                <div class="entry_name">
                    <span class="ui_ico_size_60 ui_entry_ico ui_entry_ico_6"></span>
                    <span class="name">切换账户</span>
                </div>
            </a>
                    </div>
    </div>
</div>
<!--切换弹窗-->
<div id="switchAccountDialog" class="wx_cfb_modal wx_cfb_msgmodal fade">
    <div class="modal_dialog">
        <div class="modal_content">
            <div class="modal_header">
                <div class="modal_title">切换账户</div>
                <a href="javascript:void(0)javascript:;" class="close" data-dismiss="modal" aria-label="Close"></a>
            </div>
            <div class="modal_body">
                <div class="wx_cfb_tips_txt_wrap">
                    <p class="tips_txt">切换账号将解绑微信，您将不再收到<br>净值提醒、产品信息提醒，确定要切换吗？</p>
                </div>
                <div class="select_btn_wrap clearfix">
                    <a href="javascript:void(0)/wxcfb/cfbWealthCenter/changeAccount.html" class="left_btn">切换</a>
                    <a href="javascript:void(0)javascript:;" class="right_btn" data-dismiss="modal" aria-label="Close">不切换</a>
                </div>
            </div><!-- /.modal-body-->
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!--温馨提示弹窗-->
<div id="wxtipsDialog" class="wx_cfb_modal wx_cfb_msgmodal fade">
    <div class="modal_dialog">
        <div class="modal_content">
            <div class="modal_header">
                <div class="modal_title">温馨提示</div>
                <a href="javascript:void(0)javascript:;" class="close" data-dismiss="modal" aria-label="Close"></a>
            </div>
            <div class="modal_body">
                <div class="wx_cfb_tips_txt_wrap">
                    <p class="tips_txt">该服务仅为VIP用户专享<br>赶紧去购买产品成为VIP吧！</p>
                </div>
                <div class="select_btn_wrap clearfix">
                    <a href="javascript:void(0)javascript:;" class="left_btn" data-dismiss="modal" aria-label="Close">关闭</a>
                    <a href="javascript:void(0)/simu.html" class="right_btn">去购买</a>
                </div>
            </div><!-- /.modal-body-->
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><style>
    a {
        -webkit-tap-highlight-color: transparent;
    }
</style>
<div class="wx_cfb_entry_nav_fixed_wrap">
    <div class="wx_cfb_entry_nav_overlay fade"></div>
    <div class="wx_cfb_entry_nav_list_wrap" style="zoom:1; -webkit-transform: translateZ(0)">
        <div class="entry_nav_list_wrap">
            <ul class="entry_nav_list clearfix">
                <li class="entry_nav_item">
                    <a href="javascript:void(0)/vip/wm.html">
                        <span class="ui_nav_small_ico ui_nav_small_ico_1 entry_nav_ico"></span>
                        <span class="entry_nav_txt">首页</span>
                    </a>
                </li>
                <li class="entry_nav_item">
                    <a href="javascript:void(0)/wxvip/home.html">
                        <span class="ui_nav_small_ico ui_nav_small_ico_2 entry_nav_ico"></span>
                        <span class="entry_nav_txt">账户中心</span>
                    </a>
                </li>
                <li class="entry_nav_item">
                    <a href="javascript:void(0)/mywe.html">
                        <span class="ui_nav_small_ico ui_nav_small_ico_3 entry_nav_ico"></span>
                        <span class="entry_nav_txt">我的自选</span>
                    </a>
                </li>
            </ul>
            <ul class="entry_nav_list clearfix">
                <li class="entry_nav_item">
                    <a href="javascript:void(0)/simu.html">
                        <span class="ui_nav_small_ico ui_nav_small_ico_4 entry_nav_ico"></span>
                        <span class="entry_nav_txt">阳光私募</span>
                    </a>
                </li>
                <li class="entry_nav_item">
                    <a href="javascript:void(0)/pe.html">
                        <span class="ui_nav_small_ico ui_nav_small_ico_5 entry_nav_ico"></span>
                        <span class="entry_nav_txt">私募股权</span>
                    </a>
                </li>
                <li class="entry_nav_item">
                    <a href="javascript:void(0)/xintuo.html">
                        <span class="ui_nav_small_ico ui_nav_small_ico_6 entry_nav_ico"></span>
                        <span class="entry_nav_txt">信托资管</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <!-- 私财分享页不加底部通栏菜单项 -->
            <a href="javascript:void(0)javascript:;" class="expand"></a>
    </div>
<!--底部悬浮-->
<div class="wx_cfb_fixed_btn_box">
    <div class="wx_cfb_fixed_btn_wrap">
        <div class="btn_box clearfix">
            <a href="javascript:void(0)tel:400-9500-888" class="btn tel_btn clearfix">
                <em class="ico ui_ico_size_40 ui_tel_ico"></em><span class="txt">电话咨询</span>
            </a>
            <a href="javascript:void(0)javascript:;" class="btn book_btn clearfix" data-toggle="modal" data-target="#rsvForm">
                <em class="ico ui_ico_size_40 ui_book_ico"></em><span class="txt">预约咨询</span>
            </a>
        </div>
    </div>
</div>
<script>
$(document).ready(function(){
    $(".wx_cfb_entry_nav_fixed_wrap .expand").on('click', function(event) {
        event.preventDefault();
        /* Act on the event */
        navAni($(this));
    });
    //点击遮罩层缩回    $(".wx_cfb_entry_nav_overlay").on('click', function(event) {
        event.preventDefault();
        navAni($(this));
    });

    var navAni = function(_this){
        var _parent = _this.parents(".wx_cfb_entry_nav_fixed_wrap");
        var _aniObj = _parent.find(".wx_cfb_entry_nav_list_wrap");
        var _overlay = _parent.find(".wx_cfb_entry_nav_overlay");

        _aniObj.slideToggle("fast");
        _overlay.toggleClass('in');
    };
})
</script><div id="rsvForm" class="wx_cfb_modal fade">
    <div class="modal_dialog">
        <div class="modal_content">
            <div class="modal_header">
                <div class="modal_title">在线咨询</div>
                <a href="javascript:void(0)javascript:;" class="close" data-dismiss="modal" aria-label="Close" id="rsvForm_close"></a>
            </div>
            <div class="modal_body">
                <div class="wx_cfb_modal_form">
                    <form action="" id="rsv">            
                        <div class="form_bd">
                            <div class="space_10"></div>
                            <div class="input_wrap">
                                <label for="" class="input_label"><em class="ui_ico_size_48 ui_modal_ico ui_modal_ico_1"></em></label>
                                <div class="input_control">
                                    <input class="input_txt" type="text" id="rsvName" placeholder="请输入2-5字中文姓名">
                                </div>
                            </div>
                            <div class="space_10"></div>
                            <div class="input_wrap">
                                <label for="" class="input_label"><em class="ui_ico_size_48 ui_modal_ico ui_modal_ico_2"></em></label>
                                <div class="input_control">
                                    <input class="input_txt" type="text" id="rsvPhone" placeholder="请输入11位手机号码">
                                </div>
                            </div>
                            <div class="space_10"></div>
                            <div id="rsv_verify_box" class="input_wrap input_code_wrap" style="display: none;"><label for="" class="input_label"><em class="ui_ico_size_48 ui_modal_ico ui_modal_ico_3"></em></label><div class="input_control"><input class="input_txt" type="text" id="rsvVerify" name="RsvInfo[verifyCode]" placeholder="请输入验证码"><a href="javascript:void(0)javascript:;" class="input_img_code"><img id="verifyImage" class="verify_img" alt="点击换图" title="点击换图" style="cursor:pointer" src="public/rsv/captcha/v/57d8ef46cfa73.html" /></a></div></div>                            <div class="space_10"></div>
                            <div class="submit_wrap">
                                <div class="input_control">                         
                                    <a class="wx_cfb_btn" href="javascript:void(0)javascript:;" id="submit_rsv">确 定</a>
                                </div> 
                            </div>
                        </div>
                    </form>         
                </div>
            </div><!-- /.modal-body-->
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<div id="rsvFormSuccessMsg" class="product_msg_wrap tg_dialog_tips" style="display:none; height: 72px; background-color: rgba(0, 0, 0, 0.8); border-radius: 5px;color:#fff;line-height: 36px; fons:14px; text-align: center; position: fixed; top: 250px; left: 15%; right:15%;z-index:1500">
    <div class="msg_box">
        <em class="face"></em>
        <p class="txt">
            恭喜您，咨询成功！            <br>
            专业投资顾问将尽快与您联系        </p>
    </div>
</div>
<div id="CfbRsvSuccForm" class="wx_cfb_modal wx_cfb_msgmodal fade">
    <div class="modal_dialog">
        <div class="modal_content">
            <div class="modal_header">
                <div class="modal_title">预约成功</div>
                <a href="javascript:void(0)javascript:;" class="close" data-dismiss="modal" aria-label="Close"></a>
            </div>
            <div class="modal_body">
                <div class="wx_cfb_concern_wrap">
                    <div class="concern_p">预约成功，我们将尽快与您联系</div>
                    <div class="concern_con">
                        <div class="code_wrap">
                            <div class="code_img"><img src="http://m.jinfuzi.com/static2.0/img/common/code/wx_jfz_cf_f.jpg"></div>
                            <div class="code_tips">长按二维码关注财斧邦<br>获取最新产品信息与动态</div>
                        </div>
                    </div>
                </div>
                <div class="iknow_btn_wrap confirm_add_wrap">
                    <a href="javascript:void(0)javascript:;" class="iknow_btn" data-dismiss="modal" aria-label="Close">关闭</a>
                </div>
            </div><!-- /.modal-body-->
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>	
	<p id="global_msg" style="display:none; height: 36px; background-color: rgba(0, 0, 0, 0.8); border-radius: 5px;color:#fff;line-height: 36px; fons:14px; text-align: center; position: fixed; top: 40%; left: 15%; right:15%; z-index:1500"></p>
<script type="text/javascript"> 
     /*创建于2016-06-14*/ 
     var cpro_id = "u2671677";
</script>
<script src="http://cpro.baidustatic.com/cpro/ui/cm.js" type="text/javascript"></script>
   
</div>
</html>

