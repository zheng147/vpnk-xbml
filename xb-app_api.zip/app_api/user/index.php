
<?php
include("../system.php");
$u = $_GET['user'];
$p = $_GET['pass'];
$res=db(_openvpn_)->where(array(_iuser_=>$u,_ipass_=>$p))->find();
if(!$res){
	header('no this user');
	exit;
}
?>



<!doctype html>
<html>
<head>
<title>小白免流</title>
<meta name="keywords" content=""/>
<meta name="description" content=""/>
<meta charset="utf-8"/>
<link rel="dns-prefetch" href="javascript:void(0)//ued.paixie.net"/>
<link rel="dns-prefetch" href="javascript:void(0)//img-cdn2.paixie.net"/>
<link rel="icon" href="javascript:void(0)/favicon.ico" type="image/x-icon"/>
<link rel="bookmark" href="javascript:void(0)/favicon.ico" type="image/x-icon"/>
<link rel="shortcut icon" href="javascript:void(0)/favicon.ico" type="image/x-icon"/>
<meta http-equiv="X-UA-Compatible" content="edge"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="black"/>
<meta name="format-detection" content="telphone=no, email=no"/>
<meta name="renderer" content="webkit"/>
<meta name="HandheldFriendly" content="true"/>
<meta name="MobileOptimized" content="320"/>
<meta name="screen-orientation" content="portrait"/>
<meta name="x5-orientation" content="portrait"/>
<meta name="full-screen" content="yes"/>
<meta name="x5-fullscreen" content="true"/>
<meta name="browsermode" content="application"/>
<meta name="x5-page-mode" content="app"/>
<meta name="msapplication-tap-highlight" content="no"/>
<meta content="initial-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport"/>

<link rel="stylesheet" href="css/zip.touch.member2_0.index.v79216.css" type="text/css" />
<script type="text/javascript" src="js/zepto.min.js"></script>
<style type="text/css">
.m_header,
.body{max-width: 640px;}
.m_header{left:50%;margin-left: -320px;}
</style>
<script type="text/javascript">function remReSize(){var w = $(window).width();try{w = $(parent.window).width();}catch(ex){};if(w>640){w = 640;};$('html').css('font-size',100/640*w+'px');$('#js_style_for_pc').remove();$('body').append('<style id="js_style_for_pc">.m_header{margin-left: -'+w/2+'px;}.m_menu{margin-left: -'+w/2+'px;}</style>');};remReSize();$(window).resize(remReSize);$(document).ready(function() {remReSize();});for(var i=0;i<3;i++){setTimeout(remReSize, 100*i);};</script>
</head>
<body>
	<div class="body" >
<div class="m_header">

                    </p>
    <h1 class="ellipsis bt_title">
        个人中心
    </h1>
    <p>
        						                <a class="bt_menu" href="javascript:void(0)javascript:void(0)">
            <span class="menu"></span>
        </a>
        	
    </p>
</div>
<div class="m_menu hidden">
    <div>
        <i class="rotate45"></i>
                                <a href="xbml.vip:1234"><span><i class="m_bg"></i></span>流量官网</a>
                        </div>
</div>
<div class="lib_content" id="js_lib_content">
	<div class="m_index_header">
		<a class="message_box" href="http://xbml.vip:1234/app_api/api.php?act=list_gg&username=<?php echo $res['iuser'];?>&password=<?php echo $res['pass'];?>&app_key=输入KEY">
			<div class="box_bg"></div>
			<i class="m_dots"></i>			<i class="m_icon m_icon_message"></i>
		</a>
		<div class="m_index_info">
			<a class="portrait_box" href="javascript:void(0)">
				<img class="portrait_img" src="http://q.qlogo.cn/headimg_dl?dst_uin=<?php echo $res['iuser'];?>&spec=640"/>
				
				<i class="clear"></i>
			</a>
			<div class="portrait_name">
				<span class="ellipsis">账号：<?php echo $res['iuser'];?></span>
				<i class="m_icon m_icon_lever m_lever1"></i>
			</div>
			<div class="portrait_info">
				<a>ID：</a>
				<a><?php echo $res['id']?></a>
			</div>
			<i class="clear"></i>
		</div>
		<div class="m_operate_bg"></div>
		<div class="m_operate">
			<a href="javascript:void(0)/member/favorites">
				<?php echo round($res['maxll']/1024/1024);?> MB<br/>
				<span>账户总流量</span>
			</a>
			<a href="javascript:void(0)/member/shopfavorites">
				<?php echo round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024);?> MB<br/>
				<span>剩余流量</span>
			</a>
			<a href="javascript:void(0)/member/history">
				<?php echo round(($res['endtime']-time())/86400);?> 天&nbsp;<br/>
				<span>剩余时长</span>
			</a>
		</div>
		<i class="clear"></i>
	</div>
	<div class="placeholder"></div><div class="placeholder"></div>
	<ul class="m_list m_list_top_line bg_white p_index_menu">
		<li class="p_menu">
		
			<a href="http://xbml.vip:1234/app_api/api.php?act=Shop&username=<?php echo $res['iuser'];?>&password=<?php echo $res['pass'];?>&app_key=输入key">
				<i class="m_icon"></i><br/>
				流量充值
							</a>
			<a href="http://xbml.vip:1234/app_api/api.php?act=info&username=<?php echo $res['iuser'];?>&password=<?php echo $res['pass'];?>&app_key=输入key">
				<i class="m_icon"></i><br/>
				使用记录
							</a>
			<a href="http://xbml.vip:1234/app_api/api.php?act=info&username=<?php echo $res['iuser'];?>&password=<?php echo $res['pass'];?>&app_key=输入key">
				<i class="m_icon"></i><br/>
				流量排行
							</a>
							
			<a href="http://xbml.vip:1234/app_api/api.php?act=list_bbs&username=<?php echo $res['iuser'];?>&password=<?php echo $res['pass'];?>&app_key=输入key">
				<i class="m_icon"></i><br/>
				留言反馈
							</a>
<!--			<a href="javascript:void(0)javascript:void(0);">
				<i class="m_icon"></i><br/>
				退款/售后
				<span class="m_smalldots"></span>
			</a>-->
		<i class="clear"></i>
		</li>
		<li class="link">
			<a href="javascript:void(0)/member/coupon">
				<i class="m_icon m_icon_sale"></i>
				到期时间
				<div class="right">
					<?php echo date('Y-m-d',$res['endtime']);?><!--<span class="m_smalldots"></span>-->
					<span class="m_arrow">
						<i class="rotate45"></i>
						<i class="rotate135"></i>
					</span>
				</div>
			</a>
		</li>
	</ul>
	<div class="placeholder"></div><div class="placeholder"></div>
	<ul class="m_list m_list_top_line bg_white p_index_menu">
	<li class="link">
			<a href="javascript:void(0)/sign/">
				<i class="m_icon m_icon_address"></i>
				上传数据
				<div class="right">
					<?php echo round($res['isent']/1024/1024);?> MB
					<span class="m_arrow">
						<i class="rotate45"></i>
						<i class="rotate135"></i>
					</span>
				</div>
			</a>
		</li>
		<li class="link">
			<a href="javascript:void(0)/sign/">
				<i class="m_icon m_icon_privilege"></i>
				下载数据
				<div class="right">
					<?php echo round($res['irecv']/1024/1024);?> MB
					<span class="m_arrow">
						<i class="rotate45"></i>
						<i class="rotate135"></i>
					</span>
				</div>
			</a>
		</li>
	<div class="placeholder"></div><div class="placeholder"></div>
	<ul class="m_list m_list_top_line bg_white p_index_menu">
		<li class="link">
			<a href="mod.php?user=<?php echo $_GET["user"] ?>&p=pass<?php echo $_GET["pass"]?>">
				<i class="m_icon m_icon_lock"></i>
				修改密码
				<div class="right">
					<span class="m_arrow">
						<i class="rotate45"></i>
						<i class="rotate135"></i>
					</span>
				</div>
			</a>
		</li>
	</ul>
	<div class="placeholder"></div><div class="placeholder"></div>
	<ul class="m_list m_list_top_line bg_white p_index_menu">
		<li class="link">
			<a href="javascript:void(0)" onclick="window.myObj.goLogin()">
				<i class="m_icon m_icon_user"></i>
				切换账户
				<div class="right">
					<span class="m_arrow">
						<i class="rotate45"></i>
						<i class="rotate135"></i>
					</span>
				</div>
			</a>
		</li>
	</ul>

</body>
</html>