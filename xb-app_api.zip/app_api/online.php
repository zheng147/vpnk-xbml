﻿<?php
if($_GET['act'] == 'save'){
include('system.php');
	//执行数据保存
	$status1 = setSystemData("TCP_PATH",$_POST["tcp"]);
	$status2 = setSystemData("UDP_PATH",$_POST["udp"]);
	die(json_encode(array(
		"status"=>"success"
	)));
}elseif($_GET['act'] == 'data'){
	
include('system.php');

$tcp_file = getSystemData("TCP_PATH");
$udp_file = getSystemData("UDP_PATH");
$tcp_file = $tcp_file == "" ? "res/tcp.txt" : $tcp_file;
$udp_file = $udp_file == "" ? "udp/udp.txt" : $udp_file;

$status_file = $_GET["t"] == "udp" ? $udp_file:$tcp_file;
if(!is_file(dirname(R)."/".$status_file)){
	die(json_encode(array('status'=>"error",'mes'=>"状态文件(".dirname(R)."/".$status_file.")未找到 请点击设置重新配置","html"=>"")));
}
if(isset($_GET['id'])){
	$id = $_GET['id'];
	//$rs = $DB->get_row("SELECT * FROM `auth_fwq` WHERE `id`='$id' limit 1");
	$rs = db("auth_fwq")->where(array("id"=>$id))->find();
	if(!$rs){
		echo "此服务器不存在";
	}else{
		$file = 'http://'.$rs['ipport'].'/'.$status_file;
	}
}else{
	$file = dirname(R).'/'.$status_file;
}

$html ='
<table class="table table-striped">
   <thead>
      <tr>
	   <th>ID</th>
         <th>用户名</th>
         <th>上传</th>
	<th>下载</th>
	<th>剩余(实时)</th>
	<th>IP</th>
	<th>操作</th>
      </tr>
   <tbody>';


$str=file_get_contents($file);
$num = (substr_count($str,date('Y'))-1)/2;
$num = round($num,0);

$fp=fopen($file,"r");
fgets($fp);
fgets($fp);
fgets($fp);
for($i=0;$i<$num;$i++){
$j=$i+1;
$line=fgets($fp);
	$arr=explode(",",$line);
	$recv=round($arr[2]/1024)/1000;
	$sent=round($arr[3]/1024)/1000;
	//$row = $DB->get_row("select * from `openvpn` where `iuser`='".$arr[0]."' limit 1");
	$row = db(_openvpn_)->where(array("iuser"=>$arr[0]))->find();
	$sy = ($row['maxll']-$row['isent']-$row['irecv']-$arr[2]-$arr[3]);
	$value = round($sy/1024/1024,3);
	$pre = $sy < 1024*1024*100 ? '<span class="label label-warning">流量不足</span':'';
	$pre = $sy < 0 ? '<span class="label label-danger">流量超额</span':$pre;
	
	$username = $arr[0] == "UNDEF"?"未知用户(UNDEF)":$arr[0];
	
$html .= "<tr class=\"line-id-{$arr[0]}\">";
$html .= "<td>".$j."</td>";
$html .= "<td>".$username."</td>";
$html .= "<td>".$recv."MB</td>";
$html .= "<td>".$sent."MB</td>";
$html .= "<td>".round($value,3)."MB&nbsp;".$pre."</td>";
$html .= "<td>".$arr[1]."</td>";
$html .= '<td><a class="btn btn-xs btn-success" href="./qset.php?user='.$arr[0].'">查看用户</a>&nbsp;<button type="button" class="btn btn-danger btn-xs" onclick="if(!confirm(\'强制下线只用于更新数据。对方可能自动重新连接。另外因为流控兼容问题可能此功能并不起作用\')){return false;}else{outline(\''.$arr[0].'\')}">强制下线</button></td>';
$html .= "</tr>";
}
$html .="
     </tbody>
   </thead>
</table>";
die(json_encode(array('status'=>"success",'nums'=>$num,"html"=>$html)));


}else{
$title='当前在线用户';
include('head.php');
include('nav.php');
$tcp_file = getSystemData("TCP_PATH");
$udp_file = getSystemData("UDP_PATH");
$tcp_file = $tcp_file == "" ? "res/tcp.txt" : $tcp_file;
$udp_file = $udp_file == "" ? "udp/udp.txt" : $udp_file;
if(isset($_GET['id'])){
	$id = $_GET['id'];
	//$rs = $DB->get_row("SELECT * FROM `auth_fwq` WHERE `id`='$id' limit 1");
	$rs = db("auth_fwq")->where(array("id"=>$id))->find();
	if(!$rs){
		echo "此服务器不存在";
	}else{
		$file = 'http://'.$rs['ipport'].'/res/'.$status_file.'.txt';
	}
}else{
	$file = '../res/'.$status_file.'.txt';
}

?>


<div class="col-xs-12 center-block" style="float: none;">
<button type="button" class="btn btn-success">当前在线&nbsp;<span class="oln">0</span>&nbsp;人</button>&nbsp;
<button type="button" class="btn btn-warning" onclick="window.location.href='online.php?<?php echo $_GET['id'] == "" ? "" : "id=".$_GET['id']; ?><?php echo $_GET['t'] == "udp" ? "&t=tcp" : "&t=udp" ?>'">切换至<?php echo $_GET["t"] == "udp" ? "TCP":"UDP" ?>模式</button>&nbsp;
<button class="btn btn-primary" data-toggle="modal" data-target="#myModal" id="setting">
	扫描设置
</button>&nbsp;
十秒钟自动刷新一次数据
<div style="height:10px;"></div>
<div class="alert alert-danger">
	本功能通过定时扫描 用户状态文件 实现，如果提示无法检测到您的状态文件 请打开【扫描设置】进行配置。【强制下线功能测试中 目前仅支持 主机】
</div>
<button type="button" class="btn btn-primary btn-xs">节点</button>
<?php
if($_GET["id"] == ""){
	echo '&nbsp;&nbsp;&nbsp;&nbsp;<span class="label label-info" ><a href="?'.$t_str.'" style="color:#fff">当前服务器</a></span>';
}else{
	echo '&nbsp;&nbsp;&nbsp;&nbsp;<span ><a href="?'.$t_str.'" >当前服务器</a></span>';
}
//$rs=$DB->query("SELECT * FROM `auth_fwq`  order by id desc limit 20");
$rs = db("auth_fwq")->order("id DESC")->select();
foreach($rs as $res)
{
	$id_str = $res['id'] == "" ? "" : "id=".$res['id'];
	$t_str = $_GET['t'] == "" ? "" : "&t=".$_GET['t'];
	if($res['id'] == $_GET["id"]){
		echo '&nbsp;&nbsp;&nbsp;&nbsp;<span class="label label-info" ><a href="?'.$id_str.$t_str.'" style="color:#fff">'.$res['name'].'</a></span>';
	}else{
		echo '&nbsp;&nbsp;&nbsp;&nbsp;<span><a href="?'.$id_str.$t_str.'">'.$res['name'].'</a></span>';
	}
}
?>
<div style="height:10px;"></div>
<div class="table-responsive">
<center>
<br>
<br>
<br>
<b>请稍等...加载中...</b>
</center>
</div>
	  
	 
    </div>
	<!-- 模态框（Modal） -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×
				</button>
				<h4 class="modal-title" id="myModalLabel">
					在线监控设置
				</h4>
			</div>
			<div class="modal-body">
				使用此功能来配置您的流控在线用户状态文件的位置，只有正确的配置路径程序才能扫描出正确的结果。
				 <div class="form-group">
					<label for="name">请输入TCP协议状态文件的位置</label>
					<input type="text" class="form-control" id="tcp_path" placeholder="" value="<?php echo $tcp_file?>">
					
					
				  </div>
				  <div class="form-group">
					<label for="name">请输入UDP协议状态文件的位置</label>
				<input type="text" class="form-control" id="udp_path" placeholder=""  value="<?php echo $udp_file?>">
					
				  </div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">
					关闭
				</button>
				<button type="button" class="btn btn-primary save">
					提交更改
				</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script>
   $(function(){
	   $('#myModal').modal('hide');
	   });
</script>
<script>
   $(function () { $('#myModal').on('hide.bs.modal', function () {
      //alert('嘿，我听说您喜欢模态框...');
	  })
   });
   $(function(){
	   
	   $(".save").click(function(){
		   var tcp_path = $("#tcp_path").val();
		   var udp_path = $("#udp_path").val();
		   if(udp_path == "" || tcp_path == ""){
			   alert("检测到您可能流控了某目录，那么对应的扫描就不会启动。当然如果您的流控本身没有提供相对于的协议监控，流控与否也无所谓");
		   } 
		   $.post('?act=save&<?php echo $_GET['id'] == "" ? "" : "id=".$_GET['id']; ?><?php echo $_GET['t'] == "" ? "" : "&t=".$_GET['t']; ?>',{
			   "tcp":tcp_path,
			   "udp":udp_path
			},function(data){
				if(data.status == "success"){
					 $('#setting').click();
					 location.reload(true);
				}else{
					alert(data.msg);
				}
			},"JSON");
	   });
   });
</script>
	<script>
	var fun = function(){
			$.post('?act=data&<?php echo $_GET['id'] == "" ? "" : "id=".$_GET['id']; ?><?php echo $_GET['t'] == "" ? "" : "&t=".$_GET['t']; ?>',{
			},function(data){
				if(data.status == "success"){
					$('.table-responsive').html(data.html);
					$('.oln').html(data.nums);
				}else{
					$('.table-responsive').html(data.mes);
				}
			},"JSON");
	}
	$(function(){
		fun();
		setInterval(fun,10000);
	});
	</script>
<?php 
include("footer.php");
}?>