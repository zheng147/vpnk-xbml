<?php
if($_GET["op"] == "del"){
	db("app_bbs")->where(array("id"=>$_POST["id"]))->delete();
	db("app_bbs")->where(array("to"=>$_POST["id"]))->delete();
	die(json_encode(array("status"=>"success")));
	exit;
}

?>
<script>
var to_id=0;
var del_id=0;
</script>
<?php
$u = $_GET['username'];
		$p = $_GET['password'];
		$db = db('app_bbs');
		$list = $db->order('id DESC')->fpage($_GET["page"],10)->select();
		echo '<div style="margin:10px 10px;">';
		echo '<button class="btn btn-primary " data-toggle="modal" data-target="#myModal">发布新留言</button>';

		echo '</div>';
		$numrows = $db->getnums();
$pagesize=10;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);

		if($list){
			echo '<ul class="list-group">';
			foreach($list as $v){

				echo '<li class="list-group-item line-id-'.$v["id"].'"><span class="glyphicon glyphicon-user"></span>'.substr_replace($v["username"],'****',3,4).'于 '.date("Y/m/d H:i:s",$v["time"]).'发表留言<hr>'.$v["content"];
				$list_re = db("app_bbs")->where(array('to'=>$v["id"]))->order('id DESC')->select();
				echo "<p>$v[name]</p>";
				if($v['to'] == 1){
					echo "<p>可以免</p>";
				}elseif($v['to'] == 3){
					echo "<p>不能免</p>";
				}elseif($v['to'] == 2){
					echo "<p>免部分</p>";
				}
				foreach($list_re as $ve){
					echo '<pre><span class="glyphicon glyphicon-user"></span>'.substr_replace($ve["username"],'****',3,4).'于 '.date("Y/m/d H:i:s",$ve["time"]).'回复<br>'.$ve["content"].'</pre>';
				}
				echo '<hr><button class="btn btn-primary btn-xs" data-toggle="modal" data-target="#rep" onclick="javascript:to_id='.$v["id"].';">回复</button>';
				if($v["username"] == $_GET["username"]){
					echo '&nbsp;<button class="btn btn-primary btn-xs" data-toggle="modal" data-target="#del"onclick="javascript:del_id='.$v["id"].';" >删除</button>';
				}
				echo '</li>
				';
			}
		echo '</ul>';
		}else{
			echo '消息已经删除或者不存在！';
		}
		?>

		<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="?act=list_bbs&username='.$_GET["username"].'&password='.$_GET["password"].'&page='.$first.$link.'">首页</a></li>';
echo '<li><a href="?act=list_bbs&username='.$_GET["username"].'&password='.$_GET["password"].'&page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="?act=list_bbs&username='.$_GET["username"].'&password='.$_GET["password"].'&page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="?act=list_bbs&username='.$_GET["username"].'&password='.$_GET["password"].'&page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="?act=list_bbs&username='.$_GET["username"].'&password='.$_GET["password"].'&page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="?act=list_bbs&username='.$_GET["username"].'&password='.$_GET["password"].'&page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';

?>
<!-- 模态框（Modal） -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">



    <!-- General Elements Block -->
    <div class="list-group-item">
        <!-- General Elements Title -->
		 <div class="alert alert-info">


       <p><a href="http://yan.chaojiyun456.cn:808/yanz/css/help.html">提示：地区线路不免流请测试全国线路，标注Wap的请使用Wap接入点，未标注的请使用Net接入点，点击查看。</a></p>    </div> <div class="block-title">

           <div class="block-options pull-right">
                <a href="javascript:void(0)" onclick="history.go(-1)" class="btn btn-default ">返回上一页</a>

            </div>
        </div>
        <!-- General Elements Content -->
        <form action="<?php echo '?act=new_add_bbs&username='.$_GET['username'].'&password='.$_GET['password']?>" method="post" enctype="multipart/form-data" class="form-horizontal form-bordered">
            <div class="form-group">
                <label class="col-md-3 control-label">反馈线路线路名称：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
                <div class="col-md-6">
                    <input type="text" name="nama" class="form-control" value="<?php echo $_GET["id"] ?>" placeholder="<?php echo $_GET["id"] ?>" disabled>
					<input type="hidden" name="name" class="form-control" value="<?php echo $_GET["id"] ?>">
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-3 control-label" for="city">所在城市：&nbsp;<a  class="btn btn-xs btn-info">请仔细补全至：省份-市区</a> </label>
                <div class="col-md-6">
 <!-- ######################################################################################### 有没有办法让下面的默认举例是真实的客户不用填写就可以正常写入数据库 -->
                    <input type="text" id="city" name="city" class="form-control" value="" placeholder="例如：<?php echo $_GET["id"] ?>" maxlength="15" required>
  <!-- ################################################################################################################### -->
                <span class="help-block">若系统定位的地区错误请手动编辑修改</span>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-3 control-label" for="beizhu">说点什么：</label>
                <div class="col-md-9">
                    <textarea id="beizhu" name="beizhu" rows="2" class="form-control" placeholder="务必注明详细地区，您的反馈对我们的研发很重要" maxlength="40"></textarea>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-3 control-label">是否可免流？</label>
                <div class="col-md-9">
                    <div class="radio">
                        <label for="isml1">
                            <input type="radio" id="isml1" name="isml" value="1" required> 可以免
                        </label>
                    </div>
                    <div class="radio">
                        <label for="isml0">
                            <input type="radio" id="isml1" name="isml" value="3" required> 不能免
                        </label>
                    </div>
                    <div class="radio">
                        <label for="isml2">
                            <input type="radio" id="isml1" name="isml" value="2" required> 免部分
                        </label>
                    </div>
                </div>
            </div>
            <div class="form-group form-actions">
                <div class="col-md-9 col-md-offset-3">
                    <button type="submit" class="btn btn-effect-ripple btn-primary">提交</button>
                    <button type="reset" class="btn btn-effect-ripple btn-danger">重置</button>
					<div class="text-center push-bit-top-bottom">
            <small class="help-block">当前用户：<?php echo $_GET["username"] ?><br/>© 小白免流线路定位系统</small>
        </div>
                </div>
            </div>
        </form>

    </div>

</div>


        </div>

<div class="modal fade" id="rep" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">回复留言</h4>
            </div>
            <div class="modal-body">
			 <div class="form-group">
    <label for="name">请输入留言内容(文明社会 文明评论)</label>
    <textarea class="form-control" rows="3" id="contents"></textarea>
  </div>
			</div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
                <button type="button" class="btn btn-primary rep">确认发布</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal -->
</div>

<div class="modal fade" id="del" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">删除留言</h4>
            </div>
            <div class="modal-body">
			 <div class="form-group">
   删除后其回复也会一起删除！
  </div>
			</div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
                <button type="button" class="btn btn-primary " onclick="javascript:delBbs(del_id)">确认删除</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal -->
</div>
<script>
<?php if($_GET['istrue'] == 1){ ?>
	$(function(){
		$('#myModal').modal('show');
	})
<?php } ?>

$(function(){
	$(".add").click(function(){
		var content = $("#content").val();
		if(content.length >= 5 && content.length <= 250 ){
			$.post("?act=add_bbs&username=<?php echo $_GET["username"]?>&password=<?php echo $_GET["password"]?>",{
				"content":content
			},function(data){
				if(data.status == "success"){
					 location.reload(true);
				}else{
					alert("新增失败");
				}
			},"JSON");
		}else{
			alert("内容必须在5个字符以上并且250个字符以下");
		}
	});

	$(".rep").click(function(){
		var content = $("#contents").val();
		if(content.length >= 5 && content.length <= 250 ){

			$.post("?act=re_bbs&username=<?php echo $_GET["username"]?>&password=<?php echo $_GET["password"]?>",{
				"content":content,
				"to":to_id
			},function(data){
				if(data.status == "success"){
					 location.reload(true);
				}else{
					alert("新增失败");
				}
			},"JSON");
		}else{
			alert("内容必须在5个字符以上并且250个字符以下");
		}
	});
});
function delBbs(id){
	$.post("?act=list_bbs&op=del&username=<?php echo $_GET["username"]?>&password=<?php echo $_GET["password"]?>",{
				"id":id
			},function(data){

					 location.reload(true);

			})
}
</script>
