<?php
$u = $_GET["username"];
$p = $_GET["password"];
$res=db(_openvpn_)->where(array(_iuser_=>$u,_ipass_=>$p))->find();
if(!$res){
	die("登录信息错误");
}
if(isset($_POST['km'])){
	$km = $_POST['km'];
	$myrow=db("auth_kms")->where(array("kind"=>"1","km"=>$km))->find();
	if(!$myrow){
		die('此激活码不存在');
	}elseif($myrow['isuse']==1){
		die('此激活码已被使用');
	}else{
		$duetime = time() + $myrow['value']*24*60*60;
		$addll = $myrow['values']*1024*1024*1024;
		//已到期 清空全部流量
		$update[_maxll_] = $addll;
		$update[_endtime_] = $duetime;
		$update[_isent_] = "0";
		$update[_irecv_] = "0";
		$update["dlid"] = $myrow['daili'];
		$update[_i_] = "1";
		if(db(_openvpn_)->where(array(_iuser_=>$u))->update($update)){
			db("auth_kms")->where(array("id"=>$myrow['id']))->update(array("isuse"=>"1","user"=>$u,"usetime"=>date("Y-m-d H:i:s",time())));
			die('开通成功！');
		}else{
			die('开通失败！');
		}
	}
}
$key = explode("_",$_GET["app_key"]);
?>
<!doctype html>
<html>
<head>
<title>小白免流流量卫士</title>
<meta name="keywords" content=""/>
<meta name="description" content=""/>
<meta charset="utf-8"/>
<link rel="dns-prefetch" href="javascript:void(0)//ued.paixie.net"/>
<link rel="dns-prefetch" href="javascript:void(0)//img-cdn2.paixie.net"/>
<link rel="icon" href="javascript:void(0)/favicon.ico" type="image/x-icon"/>
<link rel="bookmark" href="javascript:void(0)/favicon.ico" type="image/x-icon"/>
<link rel="shortcut icon" href="javascript:void(0)/favicon.ico" type="image/x-icon"/>
<meta http-equiv="X-UA-Compatible" content="edge"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="black"/>
<meta name="format-detection" content="telphone=no, email=no"/>
<meta name="renderer" content="webkit"/>
<meta name="HandheldFriendly" content="true"/>
<meta name="MobileOptimized" content="320"/>
<meta name="screen-orientation" content="portrait"/>
<meta name="x5-orientation" content="portrait"/>
<meta name="full-screen" content="yes"/>
<meta name="x5-fullscreen" content="true"/>
<meta name="browsermode" content="application"/>
<meta name="x5-page-mode" content="app"/>
<meta name="msapplication-tap-highlight" content="no"/>
<meta content="initial-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport"/>

<link rel="stylesheet" href="css/zip.touch.member2_0.index.v79216.css" type="text/css" />
<script type="text/javascript" src="js/zepto.min.js"></script>
<style type="text/css">
.m_header,
.body{max-width: 640px;}
.m_header{left:50%;margin-left: -320px;}
</style>
<script type="text/javascript">function remReSize(){var w = $(window).width();try{w = $(parent.window).width();}catch(ex){};if(w>640){w = 640;};$('html').css('font-size',100/640*w+'px');$('#js_style_for_pc').remove();$('body').append('<style id="js_style_for_pc">.m_header{margin-left: -'+w/2+'px;}.m_menu{margin-left: -'+w/2+'px;}</style>');};remReSize();$(window).resize(remReSize);$(document).ready(function() {remReSize();});for(var i=0;i<3;i++){setTimeout(remReSize, 100*i);};</script>
</head>
<body>
	<div class="body" >
<div class="m_header">

                    </p>
    <h1 class="ellipsis bt_title">
        <br>充值中心
    </h1>
    <p>


                        </div>
</div>
<div class="lib_content" id="js_lib_content">
	<div class="m_index_header">
		<a class="message_box" href="<?php echo '?act=list_gg&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?><?php echo $res['iuser'];?>&password=<?php echo $res['pass'];?>&app_key=361cde25554019d7d9c14593009243b2">
			
			<i class="m_dots"></i>			<i class="m_icon m_icon_message"></i>
		</a>
		<div class="m_index_info">
			<a class="portrait_box" href="javascript:void(0)">
				<img class="portrait_img" src="http://q.qlogo.cn/headimg_dl?dst_uin=<?php echo $res['iuser'];?>&spec=640"/>
				
				<i class="clear"></i>
			</a>
			<div class="portrait_name">
				<span class="ellipsis">账号：<?php echo $res['iuser'];?></span>
				<i class="m_icon m_icon_lever m_lever1"></i>
			</div>
			<div class="portrait_info">
				<a>亲爱的：</a>
				<a><?php echo $res['id']?></a>
			</div>
			<i class="clear"></i>
		</div>
		<div class="m_operate_bg"></div>
		<div class="m_operate">
			<a href="javascript:void(0)/member/favorites">
				<?php echo round($res['maxll']/1024/1024);?> MB<br/>
				<span>账户总流量</span>
			</a>
			<a href="javascript:void(0)/member/shopfavorites">
				<?php echo round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024);?> MB<br/>
				<span>剩余流量</span>
			</a>
			<a href="javascript:void(0)/member/history">
				<?php echo round(($res['endtime']-time())/86400);?> 天&nbsp;<br/>
				<span>剩余时长</span>
			</a>
		</div>
		<i class="clear"></i>
	</div>
	<div class="placeholder"></div><div class="placeholder"></div>
	<ul class="m_list m_list_top_line bg_white p_index_menu">

		<link rel="stylesheet" type="text/css" href="css/common.css">
		<link rel="stylesheet" type="text/css" href="css/index.css">

		
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,user-scalable=no, initial-scale=1">
    <title>PigCms</title>
    <link rel="stylesheet" href="css/style2.css">
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/idangerous.swiper.js"></script>
</head>
		
		        <div class="points">
            <span class="swiper-pagination-switch"></span>
        </div>
    </div>
    <div class="scrollNews">
        <div class="yy">
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                                   <marquee width=100%> <a href="https://jq.qq.com/?_wv=1027&k=430TFyt"　target=_blank><font color="#FF0000">欢迎使用小白免流云流量-使用过程中有任何疑问请咨询联系客服！</font></a></marquee>
                        </p>
                    </div>
                </a>
            </div>
		
		<i class="clear"></i>
	</div>
	  </div>
	</div>


<div class="alert alert-success" style="display:none;margin:0px;" >
		请在此输入您购买的流量卡密。
	</div>
	<div style="margin:10px">
				<div class="form-group">
					<input type="text" class="form-control" name="km" placeholder="请输入激活码卡密">
				</div>
				<button type="submit" class="btn btn-success btn-block cz" onclick="kmcz()">
					充值到我的账户
				</button>
 <script>
 var old_html = "";
 function kmcz(){
	 if($("[name=km]").val() == ""){
		 $(".alert").html("卡密不能为空").show();
	 }else{
		 old_html = $(".cz").html();
		 $(".cz").html("处理中...");
		 $.post("?act=Shop&username=<?php echo $_GET['username']?>&password=<?php echo $_GET['password']?>&app_key=<?php echo $_GET['app_key']?>",{
			 "km":$("[name=km]").val()
		 },function(data){
			 $(".cz").html(old_html);
			  $(".alert").show();
			  $(".alert").html(data);
		 })
	 }
 }



</script>
 <script>
<!--
</script>
					

	<script src="js/other.js" type="text/javascript" charset="utf-8"></script>
</html>
		<!--首页限时抢购开始-->
						<div class="sy_title"><span class="left"><font size="2">降价倒计时</font></span>
							<div class="sy_limit_buy_time left">
								
								<span class="time" remaintime="1442800030">
<DIV id="CountMsg" class="HotDate">
    <span id="t_d"><font size="3">4天</font></span>
    <span id="t_h"><font size="3">7时</font></span>
    <span id="t_m"><font size="3">56分</font></span>
    <span id="t_s"><font size="3">00秒</font></span>
</DIV>
<script type="text/javascript">
    function getRTime(){
        var EndTime= new Date('2016/12/15 10:00:00'); //截止时间 前端路上 http://www.51xuediannao.com/qd63/
        var NowTime = new Date();
        var t =EndTime.getTime() - NowTime.getTime();
        /*var d=Math.floor(t/1000/60/60/24);
        t-=d*(1000*60*60*24);
        var h=Math.floor(t/1000/60/60);
        t-=h*60*60*1000;
        var m=Math.floor(t/1000/60);
        t-=m*60*1000;
        var s=Math.floor(t/1000);*/

        var d=Math.floor(t/1000/60/60/24);
        var h=Math.floor(t/1000/60/60%24);
        var m=Math.floor(t/1000/60%60);
        var s=Math.floor(t/1000%60);

        document.getElementById("t_d").innerHTML = d + "天";
        document.getElementById("t_h").innerHTML = h + "时";
        document.getElementById("t_m").innerHTML = m + "分";
        document.getElementById("t_s").innerHTML = s + "秒";
    }
    setInterval(getRTime,1000);
    </script>
	</body>
</div></div>		<link rel="stylesheet" type="text/css" href="css/index.css">	
					<section class="slider">

	
							
								
									<ul class="icon-list">
									
										<li class="icon">
											<a href="<?php echo '?act=top&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>">
												<span class="icon-circle">
													<img src="images/b1.png">
												</span>
												<span class="icon-desc">流量排行</span>
											</a>
										</li>
										<li class="icon">
											<a href="<?php echo '?act=info&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>">
												<span class="icon-circle">
													<img src="images/b2.png">
												</span>
												<span class="icon-desc">使用记录</span>
											</a>
										</li>
										<li class="icon">
											<a href="<?php echo '?act=list_gg&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>">
												<span class="icon-circle">
													<img src="images/b3.png">
												</span>
												<span class="icon-desc">消息通知</span>
											</a>
										</li>
										<li class="icon">
											<a href="<?php echo '?act=user_info&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>">
												<span class="icon-circle">
													<img src="images/b4.png">
												</span>
												<span class="icon-desc">个人中心</span>
											</a>
										</li>
										<li class="icon">
											<a href="xbml.vip:1234">
												<span class="icon-circle">												
													<img src="images/b5.png">
												</span>
												<span class="icon-desc">官方网站</span>
											</a>
										</li>
										<li class="icon">
											<a href="html/help.html">
												<span class="icon-circle">												
													<img src="images/b6.png">
												</span>
												<span class="icon-desc">使用帮助</span>
											</a>
										</li>
										<li class="icon">
											<a href="xbml.vip:1234">
												<span class="icon-circle">
													<img src="images/b7.png">
												</span>
												<span class="icon-desc">服务支持</span>
											</a>
										</li>
										<li class="icon">
											<a href="xbml.vip:1234">
												<span class="icon-circle">
													<img src="images/b8.png">
												</span>
												<span class="icon-desc">售后Q群</span>
											</a>
				
