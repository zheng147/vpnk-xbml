﻿<?php
$u = $_GET["username"];
$p = $_GET["password"];
$res=db(_openvpn_)->where(array(_iuser_=>$u,_ipass_=>$p))->find();
if(!$res){
	die("登录信息错误");
}
if(isset($_POST['km'])){
	$km = $_POST['km'];
	$myrow=db("auth_kms")->where(array("kind"=>"1","km"=>$km))->find();
	if(!$myrow){
		die('此激活码不存在');
	}elseif($myrow['isuse']==1){
		die('此激活码已被使用');
	}else{
		$duetime = time() + $myrow['value']*24*60*60;
		$addll = $myrow['values']*1024*1024*1024;
		//已到期 清空全部流量
		$update[_maxll_] = $addll;
		$update[_endtime_] = $duetime;
		$update[_isent_] = "0";
		$update[_irecv_] = "0";
		$update["dlid"] = $myrow['daili'];
		$update[_i_] = "1";
		if(db(_openvpn_)->where(array(_iuser_=>$u))->update($update)){
			db("auth_kms")->where(array("id"=>$myrow['id']))->update(array("isuse"=>"1","user"=>$u,"usetime"=>date("Y-m-d H:i:s",time())));
			die('开通成功！');
		}else{
			die('开通失败！');
		}
	}
}
$key = explode("_",$_GET["app_key"]);
?>
<html>
<head>
<meta charset="gb2312"/>
<title>小白免流QQ 123456</title>
<meta name="keywords" content="小白免流"/>
<meta name="description" content="小白免流"/>
<meta name="generator" content="小白免流"/>
<meta name="author" content="小白免流"/>

<link rel="stylesheet" type="text/css" href="css/indexchannel.css?2014051504"/>
<script type="text/javascript" src="js/min.js"></script>
<script type="text/javascript" src="js/cookie_fixed.js?2014051504"></script>
<script type="text/javascript" src="js/index.js?2014051504"></script>
<script type="text/javascript" src="js/scroll.js?2014051504"></script>
<script type="text/javascript" src="js/rMenu.js?2014051504"></script>

<script type="text/javascript">
/**
 * 全局变量
 */
var _global_var={
	_curpage:2, //当前页码+1	
	_picdomain:"http//img10.fblife.com/", //图片域名
	_wapdomain:"./", //wap域名
	_staticdomain:"../static.fblife.com/", //静态资源域名
	_channelid:0, //频道id
	_default_headpic:function(){return _global_var._staticdomain+'/static/wapnews/images/tag.png';}
};
</script>
<script type="text/javascript">
$(document).ready(function(){
	//wap首页焦点图片滚动
	if(document.getElementById("slide_01")){
		var slide_01 = new ScrollPic();
		slide_01.scrollContId   = "slide_01"; //内容容器ID
		slide_01.dotListId      = "slide_01_dot";//点列表ID
		slide_01.dotOnClassName = "f_ifocus_cur";
		slide_01.arrLeftId      = "sl_left"; //左箭头ID
		slide_01.arrRightId     = "sl_right";//右箭头ID
		slide_01.frameWidth     = 520;
		slide_01.pageWidth      = 520;
		slide_01.upright        = false;
		slide_01.speed          = 10;
		slide_01.space          = 30; 
		slide_01.initialize(); //初始化
	}
});
</script>
</head>
<body>
<!-----最外层---->
<div class="outter">
	<div class="wrap">
		<!-- 主体内容 -->
		<div class="lay-left">
			<div class="pos">
				<div class="f_iheader">
					<a class="f_ilogo" href="#"><img src="images/w_logo.png"/></a>
					<a class="f_imenu" href="javascript:void(0)"><img src="http://q.qlogo.cn/headimg_dl?dst_uin=<?php echo $res['iuser'];?>&spec=640" />
                            
                        </a>
				</div>
				<div class="f_inav">
					<table align="center">

                
                <html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,user-scalable=no, initial-scale=1">
    <title>PigCms</title>
    <link rel="stylesheet" href="css/style2.css">
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/idangerous.swiper.js"></script>
</head>
<body>
<div class="page" style="margin:0;">
    <div class="device">
        <a class="arrow-left" href="javascript:;"></a>
        <a class="arrow-right" href="javascript:;"></a>
        <div class="swiper-container">
            <div class="swiper-wrapper">
                <!-- 幻灯片 -->
                <a href="" class="swiper-slide">
                    <img src="images/slide1.png" alt="">
                </a>
                <a href="" class="swiper-slide">
                    <img src="images/slide2.png" alt="">
                </a>
                <a href="" class="swiper-slide">
                    <img src="images/slide3.png" alt="">
                </a>
                <a href="" class="swiper-slide">
                    <img src="images/slide4.png" alt="">
                </a>
            </div>
        </div>
        <div class="points">
            <span class="swiper-pagination-switch"></span>
        </div>
    </div>
    <div class="scrollNews">
        <div class="yy">
            <!-- 轮播通知 -->
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            小白设计、
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            欢迎使用小白免流、
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            只要加入我们即可让你随时随地看电影、
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            小白免流为您定制了各种套餐、
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            再也不用担心流量不够用了、
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            我们为客户定制低价流量套餐、
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            请记住我们的官方
                        </p>
                    </div>
                </a>
            </div>
            <div class="tongzhi">
                <a href="">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="images/template_0.png">
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            感谢您的支持、
                        </p>
                    </div>
                </a>
            </div>

        </div>
    </div>
    <div class="content" style="width:100%; min-height:350px;margin-top: -30px;">
        <div class="gun" style="width:100%; height:100px;">
            <div id="slides">
                <ul class="slides_container swiper-wrapper" id="ul1" style="">
                    <!-- 顶部栏目 -->
                    <li class="swiper-slide swiper-slide-visible" style="">
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon1.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>全部功能</h2>
                            <br>
                            Function Module</span>
                            </div>
                        </a>
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon2.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>流量购买</h2>
                            <br>
                            Product System</span>
                            </div>
                        </a>
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon3.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>旗下品牌</h2>
                            <br>
                            The solution</span>
                            </div>
                        </a>
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon4.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>售后顾问</h2>
                            <br>
                            Customer service system</span>
                            </div>
                        </a>
                    </li>
                    <li class="swiper-slide" style="">
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon5.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>行业案例</h2>
                            </span>
                            </div>
                        </a>
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon6.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>六大优势</h2>
                            </span>
                            </div>
                        </a>
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon7.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>开发动态</h2>
                            </span>
                            </div>
                        </a>
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon8.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>关于我们</h2>
                            </span>
                            </div>
                        </a>
                    </li>
                    <li class="swiper-slide" style="">
                        <a href="javascript:;" target="_blank">
                            <div class="tub">
                                <img class="tub1" src="images/icon9.png" alt="">
                            </div>
                            <div class="tet">
                            <span>
                            <h2>联系我们</h2>
                            </span>
                            </div>
                        </a>
                    </li>
                </ul>
                <a href="javascript:;" class="prev"> prev </a>
                <a href="javascript:;" class="next" id="soso"> next </a>
            </div>
        </div>
        <ul class="neir" style="width:95%; margin-left:2%;border: rgba(37, 195, 137, 0) 1px solid;overflow:hidden; min-height:240px;padding-bottom: 80px;" id="ul2">
            <li class="active">
                <div class="newTit clearfix">
                    <div class="fr moreLink">
                        <a href="javascript:;">更多功能<i></i></a>
                        <ul>
                            <li><a href="javascript:;" onclick="tagsFilter($(this),'all')">全部功能</a></li>
                            <li><a href="javascript:;" onclick="tagsFilter($(this),'new')">最新功能</a></li>
                        </ul>
                    </div>
                    <h3>最新功能</h3>
                    <!-- 所有功能，这里的标题全部动态改变填充 -->
                </div>
                <div class="row" style="min-height: 330px;">
                    <!-- 所有功能 -->
                    <a href="<?php echo '?act=theme&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>" class="item_one" style="display: block;" data-type="all">
                        <img class="gntub" src="images/two1.png">
                        <div class="tet2">
                            <span>主题切换</span>
                        </div>
                    </a>
                    <a href="<?php echo '?act=top&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>" class="item_one" style="display: block;" data-type="all">
                        <img class="gntub" src="images/tu1.png">
                        <div class="tet2">
                            <span>流量排行</span>
                        </div>
                    </a>
                    <a href="<?php echo '?act=list_gg&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>" class="item_one" style="display: block;" data-type="all">
                        <img class="gntub" src="images/tu2.png">
                        <div class="tet2">
                            <span>消息通知</span>
                        </div>
                    </a>
                    <a href="<?php echo '?act=info&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>" class="item_one" style="display: block;" data-type="all">
                        <img class="gntub" src="images/two9.png">
                        <div class="tet2">
                            <span>使用记录</span>
                        </div>
                    </a>
                    <a href="<?php echo '?act=help&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>" class="item_one" style="display: block;" data-type="all">
                        <img class="gntub" src="images/zhu1.png">
                        <div class="tet2">
                            <span>客服中心</span>
                        </div>
                    </a>
                    <a href="<?php echo '?act=user_info&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>" class="item_one" style="display: block;" data-type="all">
                        <img class="gntub" src="images/two6.png">
                        <div class="tet2">
                            <span>个人中心</span>
                        </div>
                    </a>

                    <!--最新功能-->
                    <a href="html/help.html" class="item_one" style="display: block;" data-new="new">
                        <img class="gntub" src="images/tu3.png">
                        <div class="tet2">
                            <span>使用帮助</span>
                        </div>
                    </a>
                    <a href="javascript:void(0)" onclick="window.myObj.goUpdate()" class="item_one" style="display: block;" data-new="new">
                        <img class="gntub" src="images/two3.png">
                        <div class="tet2">
                            <span>检测更新</span>
                        </div>
                    </a>
                    <a href="javascript:void(0)" onclick="window.myObj.goLogin()" class="item_one" style="display: block;" data-new="new">
                        <img class="gntub" src="images/two2.png">
                        <div class="tet2">
                            <span>切换账号</span>
                        </div>
                    </a>
                    <a href="http://m.quankan.tv" class="item_one" style="display: block;" data-new="new">
                        <img class="gntub" src="images/two4.png">
                        <div class="tet2">
                            <span>全看视频</span>
                        </div>
                    </a>
                    <a href="http://1716dy.com" class="item_one" style="display: block;" data-new="new">
                        <img class="gntub" src="images/tu4.png">
                        <div class="tet2">
                            <span>逗逼羊</span>
                        </div>
                    </a>
                    <a href="http://ys.km.com/tv/" class="item_one" style="display: block;" data-new="new">
                        <img class="gntub" src="images/tu5.png">
                        <div class="tet2">
                            <span>影视大全</span>
                        </div>
                    </a>
                    </a>
                    <!--其他功能类 end-->
                </div>
                <div class="fixedBar">
                    <div class="SubLinks">
                        <ul>
                            <li><a href="javascript:;" onclick="tagsFilter($(this),'all')">全部功能</a></li>
                            <li><a href="javascript:;" onclick="tagsFilter($(this),'new')">最新功能</a></li>
                        </ul>
                        <span class="triangle"></span>
                    </div>
                    <a class="aClick" href="javascript:;"></a>
                </div>
            </li>
            <li class="pro">
                <div class="one_itme" id="li_two">
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/icon6.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">暂时没有提卡系统</h1>
                                <span>请联系客服购买流量！</span>
                            </div>
                        </div>
                    </a>
                </div>
            </li>
            <li class="pro">
                <div class="one_itme" id="li_three">
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/icon3.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">小白免流旗下产品</h1>
								<span>小白免流-VPN-云流量</span>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/icon3.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">小白免流SSR流量</h1>
								<span>本流量为阿里云服务器</span>
                            </div>
                        </div>
                    </a>
            <li class="pro">
                <div class="one_itmelll" id="li_four">
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/icon9.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">联系客服</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/icon9.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">客服QQ：123456</h1>
                            </div>
                        </div>
                    </a>
					<a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/icon9.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1ll">电话：10086</h1>
                            </div>
                        </div>
                    </a>
                </div>
            </li>
            <li class="pro">
                <div class="one_itme" id="li_five">
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>小白免流</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>小白免流</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>小白免流</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>小白免流</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>小白免流</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>小白免流</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>小白免流</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>小白免流</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>小白免流</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>小白免流</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>小白免流</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>小白免流</span>
                        </div>
                    </a>
                    <a href="" class="item_one">
                        <img class="gntub" src="images/two8.png">
                        <div class="tet2">
                            <span>小白免流</span>
                        </div>
                    </a>
                </div>
            </li>
            <li class="pro">
                <div>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/two9.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1sz" style="width: 96%;">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/two9.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1sz" style="width: 96%;">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/two9.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1sz" style="width: 96%;">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/two9.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1sz" style="width: 96%;">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/two9.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1sz" style="width: 96%;">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/two9.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1sz" style="width: 96%;">小白免流</h1>
                            </div>
                        </div>
                    </a>
                </div>
            </li>
            <li class="pro">
                <div class="one_itme" id="li_seven">
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_onell">
                            <div class="list_one_picll">
                                <img class="banner_pic1" src="images/img1.png">
                            </div>
                            <div class="list_one_txtll">
                                <h1 class="list_h1lls">小白免流</h1>
                            </div>
                        </div>
                    </a>



                </div>
            </li>
            <li class="pro">
                <div class="one_itme" id="li_one">
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu.jpg">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1s">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu.jpg">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1s">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu.jpg">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1s">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu.jpg">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1s">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu.jpg">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1s">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu.jpg">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1s">小白免流</h1>
                            </div>
                        </div>
                    </a>
                </div>
            </li>
            <li class="pro">
                <div class="one_itme" id="li_nigth">
                    <a href="tel:#">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu1.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="tel:#">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu1.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1">小白免流</h1>
                            </div>
                        </div>
                    </a>
                    <a href="tel:#">
                        <div class="list_one">
                            <div class="list_one_pic">
                                <img class="banner_pic1" src="images/zhu1.png">
                            </div>
                            <div class="list_one_txt">
                                <h1 class="list_h1">小白免流</h1>
                            </div>
                        </div>
                    </a>
                </div>
            </li>
        </ul>
    </div>
</div>
<div class="footer clearfix">
    <a href="tel:10086"><i></i>电话咨询</a>
    <a href="http://wpa.qq.com/msgrd?v=3&uin=123456&site=qq&menu=yes"><i></i>QQ咨询</a>
</div>
<script>
    var mySwiper = new Swiper('.swiper-container', {
        pagination: '.points',
        loop: true,
        autoplay: 3000,
        grabCursor: true,
        paginationClickable: true
    });
    $('.arrow-left').on('click',
            function(e) {
                e.preventDefault();
                mySwiper.swipePrev()
            });
    $('.arrow-right').on('click',
            function(e) {
                e.preventDefault();
                mySwiper.swipeNext()
            });
    var mySwiper2 = new Swiper('#slides', {
        pagination: false,
        paginationClickable: true,
    });
    $('.prev').on('click',
            function(e) {
                e.preventDefault();
                mySwiper2.swipePrev()
            });
    $('.next').on('click',
            function(e) {
                e.preventDefault();
                mySwiper2.swipeNext()
            });
    //tab切换
    window.onload = function() {
        var a=$("#slides a");
        var b=$(".neir>li");
        var c='active';
        tab(a,b,c);
    };
    function tab(a,b,c){
        var len=$(a);
        len.bind("click",function(){
            var index = 0;
            $(this).addClass(c).siblings().removeClass(c);
            index = len.index(this);
            $(b).eq(index).show().siblings().hide();
            return false;
        }).eq(0).trigger("click");
    }
    $(function(){
        $(".newTit .moreLink>a").click(function(){
            if($(this).hasClass('on')){
                $(this).removeClass('on').next().hide();
            }else{
                $(this).addClass('on').next().show();
            }
        });
        $(".fixedBar a.aClick").click(function() {
            $(".fixedBar .SubLinks").toggle();
            return false;
        });
    });
    $(".neir .row a[data-new=new]").show();//默认显示最新的项目
    function tagsFilter(obja,type){//obja是当前的a标签，type是项目类型从0-6，all,new,all是所有项目，new是最新的
           var oText=obja.text();
           var newTit=$('.newTit h3').text(oText);
           $(".item_one").hide();
           if(typeof type === 'number'){
           $(".neir .row a[data-type="+type+"]").show();
           }else if(type === 'all'){
             $(".item_one").show();
           }else if(type==='new'){
             $(".neir .row a[data-new=new]").show();
           }
           $(".fixedBar .SubLinks").hide();
           $(".newTit .moreLink>a").removeClass('on').next().hide();
           $("html,body").stop().animate({scrollTop:$(".newTit").offset().top},1000);
    }
//    function tagsFilter(obja,data){
//        var oText=obja.text();
//        var newTit=$('.newTit h3').text(oText);
//        var tokenn='yicms';
//        $.ajax({
//            type:"post",
//            url:"ajax地址",
//            dataType:"json",
//            data:{
//                info:data
//            },
//            success:function(sta){
//                // alert(sta);
//                $(".row").html(sta)
//                $(".fixedBar .SubLinks").hide();
//                $(".newTit .moreLink>a").removeClass('on').next().hide();
//                $("html,body").stop().animate({scrollTop:$(".newTit").offset().top},1000);
//            }
//        })
//    }
    $(function(){
        var $this = $(".scrollNews");
        var t=null;
        $this.hover(function(){
            clearInterval(t);
        },function(){
            t = setInterval(function(){
                scrollNews( $this );
            }, 4000 );
        }).trigger("mouseleave");
    });
    function scrollNews(obj){
        var $self = obj.find(".yy");
        var lineHeight = $self.find(".tongzhi").eq(0).height();
        $self.animate({"marginTop": -lineHeight +"px"}, 600 , function(){
            $self.css({marginTop:0}).find(".tongzhi").eq(0).appendTo($self);
        })
    }
</script>

</body>
</html>
                


							</form>
						</tr>
					</table>
				</div>
				<p class="f_icomputer">
					
				</p>
				
				<div class="f_footheight"></div>
				<div class="f_ifixed clears"  style="display:none;">

				</div>
			</div>
		</div>
		<!-- 主体内容 end -->

		<!-- 右侧下拉菜单 -->
		<div class="lay-right">
			<div class="asideMenu">
				<div class="aCont">
					<div class="aHead">
						<span>
							<img id="userpic" src="http://q.qlogo.cn/headimg_dl?dst_uin=<?php echo $res['iuser'];?>&spec=640" />
							账号：<?php echo $res['iuser'];?><br>到期时间：<?php echo date('Y-m-d',$res['endtime']);?>
							<cite style="display:none;" id="logined"><font id="username"></font><i id="logout" class="f_tuichubg"></i></cite>
						</span>
					</div>
					<div class="aMenu">
						<ul>
                    <div class="tongzhi">
                <a href="<?php echo '?act=user_info&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="img/13.png" height="18" width="18" />
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            我的个人中心</font></a></a>
                        </p>
                    </div>
                </a>
				</div>
				          <div class="tongzhi">
                <a href="http://lovgr.com/app_api/api.php?act=Shop&username=<?php echo $res['iuser'];?>&password=<?php echo $res['pass'];?>&app_key=361cde25554019d7d9c14593009243b2">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="img/3.png" height="18" width="18" />
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            账号充值</font></a></a>
                        </p>
                    </div>
                </a>
				</div>
						          <div class="tongzhi">
                <a href="<?php echo '?act=theme&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="img/12.png" height="18" width="18" />
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            个性主题</font></a></a>
                        </p>
                    </div>
                </a>
				</div>
				          <div class="tongzhi">
                <a href="<?php echo '?act=info&app_key='.$_GET['app_key'].'&username='.$_GET['username'].'&password='.$_GET['password'];?>">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="img/10.png" height="18" width="18" />
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            使用记录</font></a></a>
                        </p>
                    </div>
                </a>
				</div>
											          <div class="tongzhi">
                <a href="html/help.html">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="img/4.png" height="18" width="18" />
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
                            使用帮助</font></a></a>
                        </p>
                    </div>
                </a>
				</div>
											          <div class="tongzhi">
                <a href="html/help.html">
                    <div class="tongzhi_pic">
                        <img class="tongzhi_pic1" src="img/11.png" height="18" width="18" />
                    </div>
                    <div class="tongzhi_txt">
                        <p class="tongzhi_h1">
							<a class="option" href="http://lovgr.com/app_api/user/mod.php?user=<?php echo $_GET["user"] ?>&p=pass<?php echo $_GET["pass"]?>">改密</a>
							           &nbsp&nbsp&nbsp|&nbsp&nbsp&nbsp&nbsp<a href="javascript:void(0)" onclick="window.myObj.goLogin()">换号</a>
                    </div>
                </a>
				</div>
                        
			</div>
		</div>
		<!-- 右侧下拉菜单 end -->
	</div>
</div>
<!-----最外层 end ---->

<!-- 返回顶部 -->
<div id="gotop" class="gotop">
	<a href="javascript:this.blur();" class="w_top"><img src="images/top.png"></a>
</div>

<!-- 统计 -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-48372285-1', 'fblife.com');
  ga('send', 'pageview');
</script>



<!---js控制打开app---->
<script>
(function() {
	function GetQueryString(name){
		 var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
		 var r = window.location.search.substr(1).match(reg);
		 if(r!=null) return unescape(r[2]); return null;
	}
	
	var myurl=GetQueryString("isopenapp");
	var isIos=navigator.userAgent.match(/iphone|ipod/ig);
	if(isIos){
		if(myurl=="1"){
			window.location = "m.fblife.com_3A//m.fblife.com?type=cmsindex";
			setTimeout( 
			function(){ 
				window.location="../https?itunes.apple.com/cn/app/yue-ye-yi-zu/id605673005?mt=8";
			}, 500);
		}else{
			$(".f_idownload").click(function(e){
				e.preventDefault();
				window.location = "m.fblife.com_3A//m.fblife.com?type=cmsindex";
				setTimeout( 
				function(){ 
					window.location="../https?itunes.apple.com/cn/app/yue-ye-yi-zu/id605673005?mt=8";
				}, 500);
			});
		}
	}
})(); 
</script>
<!---js控制打开app end---->

</body>
</html>